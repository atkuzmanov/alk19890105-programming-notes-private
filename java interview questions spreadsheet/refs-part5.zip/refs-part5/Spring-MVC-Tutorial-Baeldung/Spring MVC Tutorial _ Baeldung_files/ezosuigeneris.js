var ezosuigeneris = '090767ff40aa655580d0a593298db438';
__ez_func_ezosuigeneris = function() { if(typeof ezosuigeneris != "undefined") { var ezosuigenerisDate = new Date(); ezosuigenerisDate.setMonth(ezosuigenerisDate.getMonth() + 24); __ez.ck.setByCat("ezosuigeneris=" + window.ezosuigeneris + ";expires=" + ezosuigenerisDate.toUTCString() + ";domain="+window.ezdomain+";path=/",3); } };
__ez.queue.addFunc('__ez_func_ezosuigeneris', '__ez_func_ezosuigeneris', null, false, ['__ezf_ezosuigeneris'], true, false, false, false);

function callezosuigeneris() {
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.async = true;
    s.src = "//g.ezoic.net/ezosuigeneris.js";
    document.body.appendChild(s);
}
if (window.addEventListener) {
	window.addEventListener('load', callezosuigeneris, false);
} else if (window.attachEvent) {
	window.attachEvent('onload', callezosuigeneris);
}
