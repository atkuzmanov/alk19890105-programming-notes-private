var I18n = I18n || {};
I18n.translations = {"production":{"server_name":"findnerd.com", "qapoptime": "15000"}};