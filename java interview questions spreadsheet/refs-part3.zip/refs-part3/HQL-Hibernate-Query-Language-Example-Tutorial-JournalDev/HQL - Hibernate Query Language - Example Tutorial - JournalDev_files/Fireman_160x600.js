(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib.Fireman = function() {
	this.initialize(img.Fireman);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,550,500);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(255,0,0,0.498)","rgba(255,0,0,0)"],[0,1],0,0,0,0,0,64.7).s().p("AnGHGQi8i8AAkKQAAkJC8i9QC9i8EJAAQEKAAC8C8QC8C9ABEJQgBEKi8C8Qi8C8kKABQkJgBi9i8g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.2,-64.2,128.5,128.5);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Fireman();
	this.instance.parent = this;
	this.instance.setTransform(-275,-250);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-275,-250,550,500);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIBFQgDgDAAgGQAAgFADgDQADgDAFgBQAFABADADQAEADAAAFQAAAGgEADQgDACgFABQgFgBgDgCgAgIAgIgDhmIAXgBIgEBng");
	this.shape.setTransform(40.8,12.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgEgJAAgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgCgJIAAgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_1.setTransform(31.7,14);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_2.setTransform(17.4,13.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgFgJABgOIAAghIAAgTIgCgOIAVgCIABAQIAAATIAAAfQAAAMAFAHQAFAGAKAAQAEAAAFgDQAFgCADgEIAIgHIAAhJIAUAAIAABDIAAASIABASIgTAAIgBgJIAAgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEg");
	this.shape_3.setTransform(-1.9,14);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgEgJAAgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAFgEIAGgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgBgJIgBgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_4.setTransform(38.1,-8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgNAwQgMgHgHgLQgHgNAAgRQAAgRAHgMQAHgLAMgHQALgFAPAAIANABQAIAAAGADIAAAQIgLgDQgGgCgIAAQgPAAgKAKQgIAKgBARQABARAJALQAJAKAPAAQAIAAAHgCIAKgEIAAAQIgOAEIgNACQgOgBgMgFg");
	this.shape_5.setTransform(27.5,-8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgFgJABgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIACASIgUAAIgBgJIAAgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_6.setTransform(11.8,-8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgWBGQgLgDgFgJQgHgKAAgQIAAg/QABgUAKgLQALgLAWAAQAMAAAKAFQAJAEAEAJQAFAIAAALQAAAMgGAJQgGAIgNADQAPADAIAIQAIAJAAAQQAAAUgMALQgNALgVAAIgDAAQgKAAgIgEgAgZADIAAAgQAAAKAGAHQAGAHANAAQAMAAAGgHQAGgHABgOQAAgNgFgHQgGgGgKgCIgMgBIgRABgAgTg0QgFAGgBANIAAAXQAYACAKgGQALgGgBgPQABgMgGgGQgGgFgJAAQgMAAgGAGg");
	this.shape_7.setTransform(0.6,-10);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgEgGQgEgHgBgKQAAgMAGgHQAGgHAJgDQAJgDAMAAIALABIAMABIAAgKQgBgLgFgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAJADAEAIQAEAIABAPIAAAsIAAAMIABALIgTAAIAAgHIgBgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgQAIQgGAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgMAAgIAFg");
	this.shape_8.setTransform(-11,-8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgtgpIgBgOIgCgOIAUgBIABAOQAGgHAIgEQAJgDAJAAQAPgBAKAIQAJAIAFAMQAEAMABAPQgBAPgEALQgFALgKAIQgJAGgQABQgLgBgHgDQgHgCgDgEIAAAsIgVACgAgOgzQgHACgEAFIABA5IAEADIAHADIALABQAPAAAIgKQAHgJAAgRQAAgTgHgKQgIgKgNAAQgIAAgGAEg");
	this.shape_9.setTransform(-22,-6.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAZA1IgBgRIAAgTIAAgcQAAgNgGgGQgFgGgKAAQgEAAgFACQgEACgEAEIgHAIIAABJIgUAAIAAhGIgBgQIgCgRIATgCIACAKIAAAJQAGgIAJgGQAIgFAKAAQAJAAAIAEQAIADAEAJQAFAIAAAOIAAAfIAAAUIABAQg");
	this.shape_10.setTransform(-34,-8.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgFgGQgDgHAAgKQgBgMAGgHQAGgHAJgDQAJgDAMAAIAMABIALABIAAgKQAAgLgGgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAIADAFAIQAEAIAAAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgPAIQgHAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgNAAgGAFg");
	this.shape_11.setTransform(-45.5,-8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAgBGIAAg8IhAAAIAAA8IgUAAIAAiLIAUAAIAAA+IBAAAIAAg+IAWAAIAACLg");
	this.shape_12.setTransform(-58.2,-9.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.6,-23.8,118.6,50);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E70000").s().p("AkUEVQh0hyABijQgBiiB0hyQByh0CiABQCjgBByB0QB0BygBCiQABCjh0ByQhyB0ijgBQiiABhyh0g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.2,-39.2,78.5,78.5);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAJQgEgDAAgGQAAgFAEgDQADgDAFAAQAGAAADADQADADABAFQgBAGgDADQgDADgGAAQgFAAgDgDg");
	this.shape.setTransform(54.8,41.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_1.setTransform(42.9,37.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgaBBQgHgEgFgIQgFgJAAgOIAAghIAAgTIgBgOIAVgCIABAQIAAATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAFgCAEgEIAHgHIAAhJIAUAAIAABFIAAARIABARIgTAAIAAgJIgBgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEgAgOg1IgMgDIABgMIAMADIANABIANgBIAMgDIAAAMIgLADIgOABIgOgBg");
	this.shape_2.setTransform(28.5,36.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgEgGQgFgHAAgKQABgMAFgHQAGgHAJgDQAKgDAMAAIAKABIALABIAAgKQAAgLgEgFQgGgFgLAAIgMABIgOADIgLADIAAgRQAKgDAKgBIATgBQANgBAJAEQAIADAFAIQAFAIAAAPIAAAsIAAAMIACALIgUAAIAAgHIgBgIQgGAIgHAEQgJAFgKAAQgKAAgHgDgAgQAIQgGAEAAAKQAAAGADAEQADAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgLAAgIAFg");
	this.shape_3.setTransform(17.1,37.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAwQgMgHgGgLQgHgNAAgRQAAgRAHgMQAGgLAMgHQAMgFAOAAIAPABQAHAAAGADIgBARIgKgEQgGgCgIAAQgQAAgIAKQgJAKAAARQAAARAJALQAJAKAPAAQAIAAAGgCIALgEIAAARIgNADIgPABQgNAAgNgFg");
	this.shape_4.setTransform(7,37.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAGAxQgHgEgDgKIgIAIIgLAHQgGADgJAAQgOABgJgKQgIgJgBgVIAAgdIAAgVIgBgPIAVgCIABAQIAAATIAAAfQAAAMAEAGQAFAHAJAAQAHAAAFgDQAFgDAGgGIgBgHIgBgIIAAg+IATAAIAABBQABALAFAGQAEAHAIAAQAHAAAGgEQAFgDAFgFIAAhNIATAAIAABLIABAOIABAOIgTABIgBgIIAAgIIgHAHQgFAEgFADQgGACgGAAIgCABQgIAAgGgFg");
	this.shape_5.setTransform(-11.4,37.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgEgGQgFgHAAgKQABgMAFgHQAGgHAJgDQAKgDAMAAIAKABIALABIAAgKQAAgLgEgFQgGgFgLAAIgMABIgOADIgLADIAAgRQAKgDAKgBIATgBQANgBAJAEQAIADAFAIQAFAIAAAPIAAAsIAAAMIACALIgUAAIAAgHIgBgIQgGAIgIAEQgHAFgLAAQgKAAgIgDgAgQAIQgGAEAAAKQAAAGADAEQADAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgMAAgHAFg");
	this.shape_6.setTransform(-25.6,37.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAnA0IgBgPIAAgQIAAgNIAAgRIABgTIgBAAIgfBHIgPAAIgfhIIgBABIABASIAAASIAAAsIgUAAIAAhnIAcAAIAfBHIAghHIAaAAIAABJIABAQIABAOg");
	this.shape_7.setTransform(-38.2,37.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgFgJAAgOIAAghIAAgTIgBgOIAVgCIABAQIAAATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAFgCAEgEIAHgHIAAhJIAUAAIAABDIAAASIABASIgTAAIAAgJIgBgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEg");
	this.shape_8.setTransform(-51.6,37.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgEgJgBgOIAAghIAAgTIgBgOIAVgCIAAAQIABATIAAAfQAAAMAFAHQAFAGAKAAQAEAAAFgDQAFgCAEgEIAGgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgBgJIgBgJQgGAJgJAFQgIAFgJAAIgDABQgIAAgHgEg");
	this.shape_9.setTransform(47.2,13.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgOAvQgLgFgHgNQgHgLAAgSQAAgRAHgMQAHgMALgFQAMgHAOABIAPABQAHABAGACIAAAQIgLgDQgGgCgIAAQgPAAgKAKQgIAKgBARQABASAJAKQAJAKAPAAQAIAAAHgCIAKgEIAAAQIgNAFIgPABQgNAAgNgHg");
	this.shape_10.setTransform(36.6,13.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgEgGQgFgHAAgKQABgMAFgHQAGgHAJgDQAKgDAMAAIAKABIALABIAAgKQAAgLgEgFQgGgFgLAAIgMABIgOADIgLADIAAgRQAKgDAKgBIATgBQANgBAJAEQAIADAFAIQAFAIAAAPIAAAsIAAAMIACALIgUAAIAAgHIgBgIQgGAIgIAEQgIAFgKAAQgKAAgHgDgAgQAIQgGAEAAAKQAAAGADAEQADAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgLAAgIAFg");
	this.shape_11.setTransform(21.1,13.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgXBFQgKgCgJgEIAAgRIARAHQAKADAKAAQAIAAAHgDQAIgDAEgGQAEgGAAgKIAAgNQgFAHgIAEQgIAEgJAAQgLAAgJgFQgKgFgGgLQgGgLAAgRQAAgSAGgMQAGgLAKgFQAKgFAMAAQALAAAHADQAHAEAEAEIAAgKIAUgBIgBAZIAABIQAAAQgHAKQgGAKgLAEQgMAEgNAAQgKAAgKgCgAgSguQgIAJAAARQAAARAIAJQAHAJANAAQAGAAAFgCIAIgFIAGgFIAAgzIgEgCIgIgEQgEgBgHAAQgPAAgHAJg");
	this.shape_12.setTransform(9.7,15.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgZAvQgLgFgGgNQgGgLAAgSQAAgRAGgLQAGgMALgGQALgHAOABQAPgBALAHQALAGAGAMQAGALAAARQAAASgGALQgGANgLAFQgLAHgPAAQgOAAgLgHgAgUgbQgHAJAAASQAAATAHAJQAIAKAMAAQANAAAIgKQAHgJAAgTQAAgSgHgJQgIgKgNAAQgMAAgIAKg");
	this.shape_13.setTransform(-6.6,13.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAZA1IgBgRIAAgTIAAgcQAAgNgGgGQgFgGgKAAQgEAAgFACQgEACgEAEIgHAIIAABJIgUAAIAAhGIgBgQIgCgRIATgCIACAKIAAAJQAGgIAJgGQAIgFAKAAQAJAAAIAEQAIADAEAJQAFAIAAAOIAAAfIAAAUIABAQg");
	this.shape_14.setTransform(-18.2,13.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgIAxQgLgEgFgJQgGgJAAgOIAAgzIgcAAIAAgOIAwAAIAAAZIAHgFIAKgEIANgCQAKAAAJAFQAJAFAGAKQAFAKAAAPQAAAPgGALQgFAKgKAFQgLAFgOAAIgCAAQgLAAgIgEgAADgXQgDABgEADIgGADIAAAfQAAANAHAGQAFAGALAAQAMAAAGgIQAIgJAAgQQgBgPgGgJQgGgIgMAAQgGAAgFACg");
	this.shape_15.setTransform(-30.9,13.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAVBKIgYgsIgRAAIAAAsIgUAAIAAh0IgBgRIgBgMIAUgCIACAOIAAARIAAA4IAQAAIAZgqIAVAAIgfAxIAgA1g");
	this.shape_16.setTransform(-41.9,11.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgOAvQgMgFgGgNQgHgLAAgSQAAgRAHgMQAGgMAMgFQAMgHAOABIAPABQAHABAGACIgBAQIgKgDQgGgCgIAAQgQAAgIAKQgJAKAAARQAAASAJAKQAJAKAPAAQAIAAAGgCIALgEIAAAQIgNAFIgPABQgNAAgNgHg");
	this.shape_17.setTransform(-52.4,13.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgQQAAgPAGgNQAGgLAKgHQALgGAOgBQAOAAAKAHQAKAFAFALQAFALAAAPIgBAFIgBAGIhFgBQABARAJAIQAIAIAPAAIARgDQAJgCAHgDIAAAPQgHAEgJACQgJABgLAAQgQAAgLgGgAgQgdQgHAIgBAQIAzgBQAAgOgGgJQgGgIgMgBQgMAAgHAJg");
	this.shape_18.setTransform(27.3,-10.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgQQAAgPAGgNQAGgLAKgHQALgGAOgBQAOAAAKAHQAKAFAFALQAFALAAAPIgBAFIgBAGIhFgBQABARAJAIQAIAIAPAAIARgDQAJgCAHgDIAAAPQgHAEgJACQgJABgLAAQgQAAgLgGgAgQgdQgHAIgBAQIAzgBQAAgOgGgJQgGgIgMgBQgMAAgHAJg");
	this.shape_19.setTransform(11.3,-10.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_20.setTransform(-0.2,-10.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgQQAAgPAGgNQAGgLAKgHQALgGAOgBQAOAAAKAHQAKAFAFALQAFALAAAPIgBAFIgBAGIhFgBQABARAJAIQAIAIAPAAIARgDQAJgCAHgDIAAAPQgHAEgJACQgJABgLAAQgQAAgLgGgAgQgdQgHAIgBAQIAzgBQAAgOgGgJQgGgIgMgBQgMAAgHAJg");
	this.shape_21.setTransform(-16.4,-10.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAWA1IAAgoIgMAFQgIADgIAAQgKABgIgEQgHgDgEgIQgFgHgBgNIAAgRIAAgLIgBgJIAUgCIABAJIAAALIAAARQABALAFAEQAEAGALAAQAGAAAHgDIAJgDIAAgyIAUAAIAABng");
	this.shape_22.setTransform(-27.7,-10.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgQQAAgPAGgNQAGgLAKgHQALgGAOgBQAOAAAKAHQAKAFAFALQAFALAAAPIgBAFIgBAGIhFgBQABARAJAIQAIAIAPAAIARgDQAJgCAHgDIAAAPQgHAEgJACQgJABgLAAQgQAAgLgGgAgQgdQgHAIgBAQIAzgBQAAgOgGgJQgGgIgMgBQgMAAgHAJg");
	this.shape_23.setTransform(-38.4,-10.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgyBGIAAiLIA3AAQATAAALAJQALAKAAARQAAAKgEAGQgDAHgGAEQgFAEgFABQAGABAHADQAGAEAEAHQAFAIAAALQAAAMgGAIQgFAIgJAEQgJAFgMAAgAgdA2IAjAAQALAAAGgHQAHgGAAgLQAAgGgDgGQgCgFgFgDQgGgDgIAAIgjAAgAgdgIIAhAAQALAAAFgGQAGgGAAgKQAAgLgHgGQgGgGgKAAIggAAg");
	this.shape_24.setTransform(-50.3,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59.4,-26,119.7,76);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgFgGQgDgHAAgKQgBgMAGgHQAFgHAKgDQAKgDALAAIAMABIAKABIAAgKQABgLgGgFQgEgFgMAAIgMABIgNADIgMADIAAgRQAKgDAKgBIAUgBQAMgBAJAEQAIADAFAIQAFAIgBAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgHAEQgJAFgLAAQgJAAgHgDgAgPAIQgHAEAAAKQAAAGACAEQAEAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgMAAgGAFg");
	this.shape.setTransform(-10.2,49.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_1.setTransform(-21.4,49.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgPQAAgQAGgMQAGgMAKgHQALgGAOAAQAOgBAKAHQAKAFAFALQAFALAAAOIgBAHIgBAFIhFgBQABAQAJAJQAIAIAPAAIARgCQAJgDAHgEIAAARQgHADgJACQgJACgLAAQgQgBgLgGgAgQgeQgHAJgBAQIAzgBQAAgOgGgJQgGgJgMAAQgMAAgHAIg");
	this.shape_2.setTransform(-32.8,49.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAjBBIAAgYIgPABIgBgJIgBgIQgFAHgJAFQgHAFgMAAQgJABgIgEQgIgEgEgIQgFgJAAgOIAAgfIAAgUIgBgPIAUgCIABARIABASIAAAfQAAAMAFAHQAFAGAKAAQAFAAAEgCQAFgCADgDIAHgGIAAhMIAUAAIAABDIABALIAAALIAOAAIAAAmg");
	this.shape_3.setTransform(-43.9,50.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgFgGQgDgHAAgKQgBgMAGgHQAGgHAJgDQAJgDAMAAIAMABIALABIAAgKQAAgLgGgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAIADAFAIQAEAIABAPIAAAsIAAAMIABALIgTAAIgBgHIAAgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgPAIQgHAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgNAAgGAFg");
	this.shape_4.setTransform(48.1,25.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_5.setTransform(36.9,25.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgXBFQgKgCgJgEIAAgRIARAHQAKADAKAAQAIAAAHgDQAIgDAEgGQAEgGAAgKIAAgNQgFAHgIAEQgIAEgJAAQgLAAgJgFQgKgFgGgLQgGgLAAgRQAAgSAGgMQAGgLAKgFQAKgFAMAAQALAAAHADQAHAEAEAEIAAgKIAUgBIgBAZIAABIQAAAQgHAKQgGAKgLAEQgMAEgNAAQgKAAgKgCgAgSguQgIAJAAARQAAARAIAJQAHAJANAAQAGAAAFgCIAIgFIAGgFIAAgzIgEgCIgIgEQgEgBgHAAQgPAAgHAJg");
	this.shape_6.setTransform(25,27.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZAvQgLgGgGgMQgGgLAAgSQAAgRAGgLQAGgNALgFQALgHAOAAQAPAAALAHQALAFAGANQAGALAAARQAAASgGALQgGAMgLAGQgLAHgPgBQgOABgLgHgAgUgcQgHAKAAASQAAATAHAJQAIAKAMAAQANAAAIgKQAHgJAAgTQAAgSgHgKQgIgJgNAAQgMAAgIAJg");
	this.shape_7.setTransform(13.5,25.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSAzQgJgDgGgGQgFgHAAgKQAAgJAEgGQAFgGAHgEQAHgCAIgCIAMgFQAGgCADgEQADgEABgFQgBgIgFgDQgGgDgIAAQgGAAgHABIgLADIgHADIAAgPQAEgCAGgBIAMgDIAMgBQAKABAJACQAJADAFAHQAFAFAAALQAAALgFAFQgGAHgIABIgPAHQgJACgGAFQgGAEAAAHQAAAIAGACQAFAEAKAAQAHAAAGgCIANgEIAHgEIABAQQgGADgKADQgKADgMgBQgKAAgJgCg");
	this.shape_8.setTransform(2.8,25.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQBGIgNgCIgMgFIAAgRQAHAEAKADQAJADAJAAQANAAAHgHQAIgHAAgNQAAgMgIgHQgIgHgMAAIgPAAIAAgMIAPAAQANgBAGgGQAHgGgBgKQAAgLgGgGQgHgGgLgBIgNACIgLADIgHACIAAgPQAGgDAKgBQAJgCAKAAQASAAALAJQALAJAAAQQAAAOgHAIQgHAIgKADQAHACAGADQAGAEAEAHQAEAHAAALQAAAOgHAIQgGAJgLAFQgKAEgMAAIgMgBg");
	this.shape_9.setTransform(-7.1,27.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgFgJABgOIAAghIAAgTIgBgOIAUgCIABAQIAAATIAAAfQAAAMAFAHQAFAGAKAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIABASIgTAAIgBgJIAAgJQgGAJgIAFQgJAFgKAAIgCABQgIAAgGgEg");
	this.shape_10.setTransform(-17.1,25.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgFgGQgDgHAAgKQgBgMAGgHQAGgHAJgDQAJgDAMAAIAMABIALABIAAgKQAAgLgGgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAIADAFAIQAEAIAAAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgPAIQgHAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgNAAgGAFg");
	this.shape_11.setTransform(-33.4,25.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_12.setTransform(-44.5,25.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_13.setTransform(76.3,1.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgZBBQgIgEgFgIQgEgJAAgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABFIAAARIACARIgTAAIgCgJIAAgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEgAgOg1IgLgDIAAgMIAMADIANABIANgBIALgDIABAMIgMADIgNABIgOgBg");
	this.shape_14.setTransform(61.9,0.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgFgGQgDgHAAgKQgBgMAGgHQAGgHAJgDQAJgDAMAAIAMABIALABIAAgKQAAgLgGgFQgEgFgMAAIgMABIgNADIgMADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAIADAFAIQAEAIAAAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgHAEQgJAFgLAAQgJAAgIgDgAgPAIQgHAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgNAAgGAFg");
	this.shape_15.setTransform(50.4,1.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgNAwQgMgHgHgLQgHgNAAgRQAAgRAHgMQAHgLAMgHQALgFAPAAIANABQAIAAAGADIAAARIgLgEQgGgCgIAAQgPAAgKAKQgIAKgBARQABARAJALQAIAKAQAAQAIAAAHgCIAKgEIAAARIgOADIgNABQgOAAgMgFg");
	this.shape_16.setTransform(40.3,1.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_17.setTransform(22,1.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgFgGQgDgHAAgKQgBgMAGgHQAFgHAKgDQAKgDALAAIAMABIAKABIAAgKQABgLgGgFQgEgFgMAAIgMABIgNADIgMADIAAgRQAKgDAKgBIAUgBQAMgBAJAEQAIADAFAIQAFAIgBAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgHAEQgJAFgLAAQgJAAgHgDgAgPAIQgHAEAAAKQAAAGACAEQAEAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgIgBIgKgBQgMAAgGAFg");
	this.shape_18.setTransform(7.8,1.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAnA0IAAgPIAAgQIAAgNIAAgRIAAgTIAAAAIghBHIgNAAIgghIIgBABIAAASIAAASIAAAsIgTAAIAAhnIAcAAIAfBHIAghHIAaAAIAABJIAAAQIABAOg");
	this.shape_19.setTransform(-4.8,1.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgEgJAAgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgCgJIAAgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_20.setTransform(-18.2,1.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgFgJABgOIAAghIAAgTIgCgOIAVgCIABAQIAAATIAAAfQAAAMAFAHQAFAGAKAAQAEAAAFgDQAFgCADgEIAIgHIAAhJIAUAAIAABDIAAASIABASIgTAAIgBgJIAAgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEg");
	this.shape_21.setTransform(-34.7,1.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgOAwQgLgHgHgLQgHgNAAgRQAAgRAHgMQAHgLALgHQAMgFAOAAIAOABQAIAAAGADIgBARIgKgEQgHgCgGAAQgQAAgJAKQgJAKAAARQAAARAJALQAJAKAQAAQAHAAAGgCIALgEIAAARIgOADIgOABQgOAAgMgFg");
	this.shape_22.setTransform(-45.4,1.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgPQAAgQAGgMQAGgMAKgHQALgGAOAAQAOgBAKAHQAKAFAFALQAFALAAAOIgBAGIgBAGIhFgBQABAQAJAJQAIAIAPAAIARgCQAJgDAHgEIAAAQQgHAEgJACQgJACgLAAQgQgBgLgGgAgQgeQgHAJgBAQIAzgBQAAgOgGgJQgGgJgMAAQgMAAgHAIg");
	this.shape_23.setTransform(20.1,-22.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_24.setTransform(6,-22.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgEgJAAgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgCgJIAAgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_25.setTransform(-13.3,-22.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgZAvQgLgFgGgNQgGgLAAgSQAAgRAGgLQAGgMALgGQALgHAOABQAPgBALAHQALAGAGAMQAGALAAARQAAASgGALQgGANgLAFQgLAHgPAAQgOAAgLgHgAgUgbQgHAJAAASQAAATAHAJQAIAKAMAAQANAAAIgKQAHgJAAgTQAAgSgHgJQgIgKgNAAQgMAAgIAKg");
	this.shape_26.setTransform(-29.7,-22.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAgBGIAAg8IhAAAIAAA8IgUAAIAAiLIAUAAIAAA+IBAAAIAAg+IAWAAIAACLg");
	this.shape_27.setTransform(-43,-24);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.3,-38,144.2,100);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAJQgEgDAAgGQAAgFAEgDQADgDAFgBQAGABADADQADADABAFQgBAGgDADQgDADgGABQgFgBgDgDg");
	this.shape.setTransform(16.6,17.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgEgJAAgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgCgJIAAgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_1.setTransform(7.4,13.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_2.setTransform(-6.9,13.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgPQAAgQAGgMQAGgMAKgHQALgGAOAAQAOgBAKAHQAKAFAFALQAFALAAAOIgBAGIgBAGIhFgBQABAQAJAJQAIAIAPAAIARgCQAJgDAHgEIAAAQQgHAEgJACQgJACgLAAQgQgBgLgGgAgQgeQgHAJgBAQIAzgBQAAgOgGgJQgGgJgMAAQgMAAgHAIg");
	this.shape_3.setTransform(-21.1,13.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgFgGQgDgHAAgKQgBgMAGgHQAFgHAKgDQAKgDALAAIAMABIAKABIAAgKQABgLgGgFQgEgFgMAAIgMABIgNADIgMADIAAgRQAKgDAKgBIAUgBQAMgBAJAEQAIADAFAIQAFAIgBAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgHAEQgJAFgLAAQgJAAgHgDgAgPAIQgHAEAAAKQAAAGACAEQAEAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgMAAgGAFg");
	this.shape_4.setTransform(-32.3,13.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgQBGIgNgCIgMgFIAAgRQAHAEAKADQAJADAJAAQANAAAHgHQAIgHAAgNQAAgMgIgHQgIgHgMAAIgPAAIAAgMIAPAAQANgBAGgGQAHgGgBgKQAAgLgGgGQgHgGgLgBIgNACIgLADIgHACIAAgPQAGgDAKgBQAJgCAKAAQASAAALAJQALAJAAAQQAAAOgHAIQgHAIgKADQAHACAGADQAGAEAEAHQAEAHAAALQAAAOgHAIQgGAJgLAFQgKAEgMAAIgMgBg");
	this.shape_5.setTransform(-42.7,15.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgEgGQgFgHAAgKQABgMAFgHQAGgHAJgDQAKgDAMAAIAKABIALABIAAgKQAAgLgEgFQgGgFgLAAIgMABIgOADIgLADIAAgRQAKgDAKgBIATgBQANgBAJAEQAIADAFAIQAFAIAAAPIAAAsIAAAMIACALIgUAAIAAgHIgBgIQgGAIgIAEQgIAFgKAAQgKAAgHgDgAgQAIQgGAEAAAKQAAAGADAEQADAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgLAAgIAFg");
	this.shape_6.setTransform(36,-10.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOAvQgMgGgGgMQgHgLAAgSQAAgRAHgMQAGgMAMgFQAMgHAOAAIAPABQAHABAGADIgBARIgKgEQgGgCgIAAQgQAAgIAKQgJAKAAARQAAARAJALQAJAKAPAAQAIAAAGgCIALgEIAAARIgNADIgPABQgNABgNgHg");
	this.shape_7.setTransform(25.9,-10.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgZAvQgLgGgGgMQgGgLAAgSQAAgRAGgLQAGgNALgFQALgHAOAAQAPAAALAHQALAFAGANQAGALAAARQAAASgGALQgGAMgLAGQgLAHgPgBQgOABgLgHgAgUgcQgHAKAAASQAAATAHAJQAIAKAMAAQANAAAIgKQAHgJAAgTQAAgSgHgKQgIgJgNAAQgMAAgIAJg");
	this.shape_8.setTransform(10.3,-10.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgSAzQgJgDgGgGQgEgHgBgKQABgJADgGQAFgGAHgEQAHgCAIgCIAMgFQAFgCAEgEQADgEABgFQgBgIgFgDQgGgDgIAAQgGAAgHABIgLADIgHADIAAgPQAEgCAGgBIAMgDIAMgBQALABAIACQAJADAFAHQAFAFAAALQAAALgFAFQgGAHgIABIgQAHQgIACgGAFQgGAEAAAHQAAAIAGACQAFAEAJAAQAHAAAIgCIAMgEIAHgEIABAQQgGADgKADQgKADgMgBQgKAAgJgCg");
	this.shape_9.setTransform(-0.5,-10.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgZAvQgLgGgGgMQgGgLAAgSQAAgRAGgLQAGgNALgFQALgHAOAAQAPAAALAHQALAFAGANQAGALAAARQAAASgGALQgGAMgLAGQgLAHgPgBQgOABgLgHgAgUgcQgHAKAAASQAAATAHAJQAIAKAMAAQANAAAIgKQAHgJAAgTQAAgSgHgKQgIgJgNAAQgMAAgIAJg");
	this.shape_10.setTransform(-11,-10.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_11.setTransform(-22.7,-10.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAyBGIAAhJIABgpIgpBjIgTAAIgqhjIAAAAIABApIAABJIgUAAIAAiLIAeAAIApBjIAphjIAeAAIAACLg");
	this.shape_12.setTransform(-37.7,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.8,-26,97.5,52);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAtQgEgDABgGQgBgGAEgDQADgDAFgBQAFABAEADQADADAAAGQAAAGgDADQgEADgFAAQgFAAgDgDgAgIgaQgEgDABgGQgBgGAEgDQADgDAFAAQAFAAAEADQADADAAAGQAAAGgDADQgEADgFAAQgFAAgDgDg");
	this.shape.setTransform(27.5,14.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgPQAAgQAGgMQAGgMAKgHQALgGAOAAQAOgBAKAHQAKAFAFALQAFALAAAOIgBAGIgBAGIhFgBQABAQAJAJQAIAIAPAAIARgCQAJgDAHgEIAAAQQgHAEgJACQgJACgLAAQgQgBgLgGgAgQgeQgHAJgBAQIAzgBQAAgOgGgJQgGgJgMAAQgMAAgHAIg");
	this.shape_1.setTransform(18.8,13.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_2.setTransform(4.7,13.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgFgJAAgOIAAghIAAgTIgBgOIAVgCIABAQIAAATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAFgCAEgEIAHgHIAAhJIAUAAIAABDIAAASIABASIgTAAIAAgJIgBgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEg");
	this.shape_3.setTransform(-9.7,13.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgtgqIgBgMIgBgPIATgBIABAPQAGgHAJgFQAIgDAKAAQAOAAAKAHQAJAIAFAMQAFAMAAAPQAAAOgFAMQgFALgKAHQgKAIgPAAQgLAAgHgEQgHgCgEgEIAAAsIgUACgAgOg0QgGADgFAFIAAA5IAFADIAIADIAKABQAPAAAIgKQAHgJAAgRQAAgTgHgKQgIgKgNAAQgIAAgGADg");
	this.shape_4.setTransform(-21.3,15.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgFgGQgDgHAAgKQgBgMAGgHQAFgHAKgDQAKgDALAAIAMABIAKABIAAgKQABgLgGgFQgEgFgMAAIgMABIgNADIgMADIAAgRQAKgDAKgBIAUgBQAMgBAJAEQAIADAFAIQAFAIgBAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgHAEQgJAFgLAAQgJAAgHgDgAgPAIQgHAEAAAKQAAAGACAEQAEAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgMAAgGAFg");
	this.shape_5.setTransform(-33.2,13.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAVBKIgYgsIgRAAIAAAsIgUAAIAAh0IgBgRIgBgMIAVgCIABAOIAAARIAAA4IARAAIAYgqIAVAAIgfAxIAgA1g");
	this.shape_6.setTransform(-43.1,11.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgfAHIAAgNIA/AAIAAANg");
	this.shape_7.setTransform(44,-10.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgEgJgBgOIAAghIAAgTIgBgOIAVgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAFgEIAHgHIAAhJIAUAAIAABDIAAASIABASIgSAAIgBgJIgBgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEg");
	this.shape_8.setTransform(33.4,-10.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_9.setTransform(21.7,-10.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgtgqIAAgNIgCgOIATgCIABAQQAGgIAJgDQAIgFAKAAQAOAAAJAIQAKAHAFAMQAFAMAAAPQAAAPgFALQgFANgKAGQgKAIgPgBQgLAAgHgCQgHgDgEgEIAAAsIgUABgAgOg0QgGAEgFADIAAA6IAFADIAIADIALABQAOAAAHgKQAIgJAAgSQAAgSgIgKQgGgKgOAAQgIAAgGADg");
	this.shape_10.setTransform(10.1,-8.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgFgGQgDgHAAgKQgBgMAGgHQAGgHAJgDQAJgDAMAAIAMABIALABIAAgKQAAgLgGgFQgEgFgMAAIgMABIgNADIgMADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAIADAFAIQAEAIAAAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgHAEQgJAFgLAAQgJAAgIgDgAgPAIQgHAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgNAAgGAFg");
	this.shape_11.setTransform(-1.8,-10.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AA0BKIgWgtIgUAAIAAAtIgTAAIAAgtIgUAAIgVAtIgXAAIAdg1IgcgyIAWAAIAWArIATAAIAAg7IgBgPIgBgMIATgBIACAPIAAASIAAA2IATAAIAXgrIAVAAIgbAyIAcA1g");
	this.shape_12.setTransform(-14.8,-12.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgZAvQgLgGgGgMQgGgLAAgSQAAgRAGgLQAGgNALgFQALgHAOAAQAPAAALAHQALAFAGANQAGALAAARQAAASgGALQgGAMgLAGQgLAHgPgBQgOABgLgHgAgUgcQgHAKAAASQAAATAHAJQAIAKAMAAQANAAAIgKQAHgJAAgTQAAgSgHgKQgIgJgNAAQgMAAgIAJg");
	this.shape_13.setTransform(-28.4,-10.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAgBGIAAh7Ig/AAIAAB7IgVAAIAAiLIBpAAIAACLg");
	this.shape_14.setTransform(-41.5,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.8,-26,101.9,52);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AIZAiQgMgLAAgWQAAgVAMgLQAMgMAVAAQAOAAAMAEIAAASQgNgFgKAAQgZAAgBAbQABAaAVAAIALgCIAAgQIgQAAIAAgNIAiAAIAAAqQgOAGgQAAQgTAAgMgKgAE8AiQgNgLAAgWQABgVALgLQANgMAUAAQAOAAAMAEIAAASQgMgFgLAAQgZAAAAAbQAAAaAVAAIALgCIAAgQIgQAAIAAgNIAhAAIAAAqQgOAGgPAAQgTAAgLgKgAhMAgQgKgMAAgUQAAgTAKgMQAKgMAUAAQAUAAAJAMQALAMAAATQAAAUgLAMQgJAMgUAAQgUAAgKgMgAhAAAQAAAbASAAQARAAAAgbQAAgagRAAQgSAAAAAagAn7AjQgIgIgBgPIgBg1IAWgBIAAA2QAAAPAOAAQANAAAAgPIAAg1IAVAAIAAA1QgBAPgIAIQgKAJgPAAQgRAAgJgJgAGNAfQAAgLAMAAQAMAAAAALQAAAMgMAAQgMAAAAgMgAAJAlIAAgTQAPAIAOAAQAMAAAAgHQAAgEgEgCIgMgEQgLgDgHgFQgHgGAAgLQAAgbAfAAQAQAAANAGIAAASQgPgHgMAAQgLAAAAAHQAAAFAEACIALAEQANAEAGAEQAGAGAAALQABAaghAAQgRAAgNgGgApVAlIAAgTQAQAIAOAAQAMAAAAgHQgBgEgEgCIgKgEQgNgDgFgFQgJgGAAgLQAAgbAfAAQASAAAMAGIAAASQgOgHgNAAQgMAAAAAHQAAAFAFACIALAEQAMAEAGAEQAHAGAAALQAAAaghAAQgQAAgOgGgAG8AqIgBhTIAmAAQAbAAAAAWQAAANgOAGQAQACAAARQAAALgHAGQgHAGgMAAgAHQAaIAQAAQAKAAAAgKQAAgJgJAAIgRAAgAHQgHIAPAAQAIAAABgJQgBgJgIAAIgPAAgAEHAqIgegxIAAAxIgUAAIgBhTIAWAAIAeAwIAAgwIAUAAIAABTgACoAqIgBhTIAWgBIAABUgABqAqIAAhDIgWAAIAAgQIBDAAIAAAQIgXAAIAABDgAh/AqIAAggIgcAAIAAAgIgVAAIgBhTIAWgBIAAAjIAcAAIAAgiIAWAAIAABTgAjbAqIgKgeIgNAAIAAAeIgVAAIgBhTIAoAAQAOAAAIAIQAHAHAAAMQAAARgPAHIANAggAjygDIAOAAQALAAAAgLQAAgLgLAAIgOAAgAlVAqIgBhTIA7AAIAAARIgkAAIAAASIAfAAIgBAPIgeAAIAAAQIAlAAIAAARgAmpAqIgBhTIAnAAQAOAAAHAIQAIAIgBANQABAMgIAHQgIAIgOAAIgQAAIAAAbgAmUAAIALAAQANAAAAgMQAAgNgNAAIgLAAg");
	this.shape.setTransform(59.8,4.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,119.5,8.8);


(lib.Call = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_10 = new cjs.Graphics().p("AFlGGIyAAAIAAsNISZAAIAVgBQCjAABzB0QBzByAACiQAACihzB0QhzByijAAQgXAAgXgCg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_graphics_10,x:120.2,y:-214.4}).wait(10).to({graphics:null,x:0,y:0}).wait(60));

	// Layer 4
	this.instance = new lib.Tween6("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(242,-214.4);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).to({x:137},7).to({x:142},3).to({startPosition:0},51).to({x:162,alpha:0},8).wait(1));

	// Layer 5
	this.instance_1 = new lib.Tween5("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160.5,-214.4,0.051,0.051);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.11,scaleY:1.11},6).to({scaleX:1,scaleY:1},4).to({startPosition:0},27).to({startPosition:0},34).to({scaleX:0.11,scaleY:0.11},8).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(158.5,-216.4,4,4);


(lib.смоке = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween8("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-64.7,231.2,0.074,0.074);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,scaleX:1.64,scaleY:1.64,x:-187.5,y:89.2,alpha:0},94).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.4,226.5,9.5,9.5);


// stage content:
(lib.Fireman_160x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_184 = function() {
		if(!this.alreadyExecuted){
		
		this.alreadyExecuted=true;
		
		this.loopNum=1;
		
		} else {
		
		this.loopNum++;
		
		if(this.loopNum==3){
		
		this.stop();
		
		}
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(184).call(this.frame_184).wait(62));

	// Logo
	this.instance = new lib.Symbol1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(78.6,578.1,1,1,0,0,0,59.8,4.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(246));

	// BUTT
	this.instance_1 = new lib.Call("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(108.5,527,1,1,0,0,0,163.1,-214.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(166).to({_off:false},0).wait(80));

	// txt3
	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(79.9,36.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(158).to({_off:false},0).to({x:74.9,alpha:1},8).to({startPosition:0},71).to({x:69.9,alpha:0},8).wait(1));

	// txt2
	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(72.9,49.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(74).to({_off:false},0).to({x:67.9,alpha:1},8).to({startPosition:0},9).to({startPosition:0},63).to({x:62.9,alpha:0},8).to({_off:true},1).wait(83));

	// txt1b
	this.instance_4 = new lib.Tween2("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(72.4,87.6);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({_off:false},0).to({x:67.4,alpha:1},8).to({startPosition:0},50).to({x:-52.6,alpha:0},8).to({_off:true},1).wait(167));

	// txt1
	this.instance_5 = new lib.Tween1("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(74.4,37);
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:69.4,alpha:1},8).to({startPosition:0},62).to({x:-50.6,alpha:0},8).to({_off:true},1).wait(167));

	// People
	this.instance_6 = new lib.Tween7("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(75,351);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({regX:0.1,regY:0.1,scaleX:0.96,scaleY:0.96,x:61.7,y:361.1},123).to({regX:0,regY:0,scaleX:1,scaleY:1,x:75,y:351},61).to({startPosition:0},61).wait(1));

	// smoke
	this.instance_7 = new lib.смоке("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(294,252.5,1,1,0,0,0,-64.7,231.2);

	this.instance_8 = new lib.смоке("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(269,258,1,1,0,0,0,-64.7,231.2);

	this.instance_9 = new lib.смоке("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(225.1,272.3,1,1,0,0,0,-64.7,231.2);

	this.instance_10 = new lib.смоке("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(332.1,268.5,1,1,0,0,0,-64.7,231.2);

	this.instance_11 = new lib.смоке("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(210.5,255.5,1,1,0,0,0,-64.7,231.2);

	this.instance_12 = new lib.смоке("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(185.5,275.5,1,1,0,0,0,-64.7,231.2);

	this.instance_13 = new lib.смоке("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(185.5,250.5,1,1,0,0,0,-64.7,231.2);

	this.instance_14 = new lib.смоке("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(117.1,258,1,1,0,0,0,-64.7,231.2);

	this.instance_15 = new lib.смоке("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(294,282.5,1,1,0,0,0,-64.7,231.2);

	this.instance_16 = new lib.смоке("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(269,288,1,1,0,0,0,-64.7,231.2);

	this.instance_17 = new lib.смоке("synched",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(250.1,282.5,1,1,0,0,0,-64.7,231.2);

	this.instance_18 = new lib.смоке("synched",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(332.1,298.5,1,1,0,0,0,-64.7,231.2);

	this.instance_19 = new lib.смоке("synched",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(235.5,265.7,1,1,0,0,0,-64.7,231.2);

	this.instance_20 = new lib.смоке("synched",0);
	this.instance_20.parent = this;
	this.instance_20.setTransform(210.5,285.7,1,1,0,0,0,-64.7,231.2);

	this.instance_21 = new lib.смоке("synched",0);
	this.instance_21.parent = this;
	this.instance_21.setTransform(210.5,260.7,1,1,0,0,0,-64.7,231.2);

	this.instance_22 = new lib.смоке("synched",0);
	this.instance_22.parent = this;
	this.instance_22.setTransform(273.6,296.3,1,1,0,0,0,-64.7,231.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7}]},53).to({state:[]},191).wait(2));

	// smoke
	this.instance_23 = new lib.смоке("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(294,252.5,1,1,0,0,0,-64.7,231.2);

	this.instance_24 = new lib.смоке("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(269,258,1,1,0,0,0,-64.7,231.2);

	this.instance_25 = new lib.смоке("synched",0);
	this.instance_25.parent = this;
	this.instance_25.setTransform(225.1,272.3,1,1,0,0,0,-64.7,231.2);

	this.instance_26 = new lib.смоке("synched",0);
	this.instance_26.parent = this;
	this.instance_26.setTransform(332.1,268.5,1,1,0,0,0,-64.7,231.2);

	this.instance_27 = new lib.смоке("synched",0);
	this.instance_27.parent = this;
	this.instance_27.setTransform(210.5,255.5,1,1,0,0,0,-64.7,231.2);

	this.instance_28 = new lib.смоке("synched",0);
	this.instance_28.parent = this;
	this.instance_28.setTransform(185.5,275.5,1,1,0,0,0,-64.7,231.2);

	this.instance_29 = new lib.смоке("synched",0);
	this.instance_29.parent = this;
	this.instance_29.setTransform(185.5,250.5,1,1,0,0,0,-64.7,231.2);

	this.instance_30 = new lib.смоке("synched",0);
	this.instance_30.parent = this;
	this.instance_30.setTransform(117.1,258,1,1,0,0,0,-64.7,231.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23}]},28).to({state:[]},190).wait(28));

	// smoke
	this.instance_31 = new lib.смоке("synched",0);
	this.instance_31.parent = this;
	this.instance_31.setTransform(184,212.5,1,1,0,0,0,-64.7,231.2);

	this.instance_32 = new lib.смоке("synched",0);
	this.instance_32.parent = this;
	this.instance_32.setTransform(159,218,1,1,0,0,0,-64.7,231.2);

	this.instance_33 = new lib.смоке("synched",0);
	this.instance_33.parent = this;
	this.instance_33.setTransform(140.1,212.5,1,1,0,0,0,-64.7,231.2);

	this.instance_34 = new lib.смоке("synched",0);
	this.instance_34.parent = this;
	this.instance_34.setTransform(222.1,228.5,1,1,0,0,0,-64.7,231.2);

	this.instance_35 = new lib.смоке("synched",0);
	this.instance_35.parent = this;
	this.instance_35.setTransform(125.5,195.7,1,1,0,0,0,-64.7,231.2);

	this.instance_36 = new lib.смоке("synched",0);
	this.instance_36.parent = this;
	this.instance_36.setTransform(100.5,215.7,1,1,0,0,0,-64.7,231.2);

	this.instance_37 = new lib.смоке("synched",0);
	this.instance_37.parent = this;
	this.instance_37.setTransform(100.5,190.7,1,1,0,0,0,-64.7,231.2);

	this.instance_38 = new lib.смоке("synched",0);
	this.instance_38.parent = this;
	this.instance_38.setTransform(163.6,226.3,1,1,0,0,0,-64.7,231.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31}]}).to({state:[]},190).wait(56));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FF3333","#660000"],[0,0.651],-116,-285.2,28,53.5).s().p("EgMpAvCMAAAheDIZTAAMAAABeDg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(246));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,299,550,602);
// library properties:
lib.properties = {
	width: 160,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Fireman.png?1574169621859", id:"Fireman"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;