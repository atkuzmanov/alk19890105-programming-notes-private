var increaserev = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
if(increaserev>=568)
    {
document.write('<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
document.write('<div class="InMargin_Top" style="position:relative; text-align:center; margin:5px 0px 5px 0px;background-color:transparent!important;">');
document.write('<ins class="adsbygoogle" style="display:inline-block;min-width:250px;max-width:420px;width:100%;height:280px;" ');
document.write('data-ad-client="ca-pub-7002491002409919" '); 
document.write('data-ad-slot="5412947508/8366363268" '); 
document.write('data-full-width-responsive="true"></ins>');
(adsbygoogle = window.adsbygoogle || []).push({});
document.write('</div>');
} else  {
document.write('<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
document.write('<div class="InMargin_Top" style="position:relative; text-align:center; margin:5px 0px 5px 0px;background-color:transparent!important;">');
document.write('<ins class="adsbygoogle" style="display:inline-block;min-width:250px;max-width:420px;width:100%;height:280px;" ');
document.write('data-ad-client="ca-pub-7002491002409919" '); 
document.write('data-ad-slot="5412947508/8366363268" '); 
document.write('data-full-width-responsive="true"></ins>');
(adsbygoogle = window.adsbygoogle || []).push({});
document.write('</div>');
}