
// Copyright 2012 Google Inc. All rights reserved.
(function(w,g){w[g]=w[g]||{};w[g].e=function(s){return eval(s);};})(window,'google_tag_manager');(function(){

var data = {
"resource": {
  "version":"667",
  
  "macros":[{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return window.location.pathname+window.location.search+window.location.hash})();"]
    },{
      "function":"__k",
      "vtp_decodeCookie":true,
      "vtp_name":"actualOptanonConsent"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"OnetrustActiveGroups"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b=",["escape",["macro",1],8,16],",a=",["escape",["macro",2],8,16],";if(void 0!=a\u0026\u0026void 0==b)return 0\u003C=a.indexOf(\",2,\")?!0:!1;if(void 0==a\u0026\u0026void 0!=b)return 0\u003C=b.indexOf(\",2,\")?!0:!1;if(void 0!=a\u0026\u0026void 0!=b)return 0\u003C=a.indexOf(\",2,\")?!0:!1;if(void 0==a\u0026\u0026void 0==b)return!0})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b=",["escape",["macro",1],8,16],",a=",["escape",["macro",2],8,16],";if(void 0!=a\u0026\u0026void 0==b)return 0\u003C=a.indexOf(\",3,\")?!0:!1;if(void 0==a\u0026\u0026void 0!=b)return 0\u003C=b.indexOf(\",3,\")?!0:!1;if(void 0!=a\u0026\u0026void 0!=b)return 0\u003C=a.indexOf(\",3,\")?!0:!1;if(void 0==a\u0026\u0026void 0==b)return!0})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b=",["escape",["macro",1],8,16],",a=",["escape",["macro",2],8,16],";if(void 0!=a\u0026\u0026void 0==b)return 0\u003C=a.indexOf(\",4,\")?!0:!1;if(void 0==a\u0026\u0026void 0!=b)return 0\u003C=b.indexOf(\",4,\")?!0:!1;if(void 0!=a\u0026\u0026void 0!=b)return 0\u003C=a.indexOf(\",4,\")?!0:!1;if(void 0==a\u0026\u0026void 0==b)return!0})();"]
    },{
      "function":"__e"
    },{
      "function":"__u",
      "vtp_component":"URL",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__u",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__aev",
      "vtp_varType":"TEXT"
    },{
      "function":"__v",
      "vtp_name":"gtm.elementUrl",
      "vtp_dataLayerVersion":1
    },{
      "function":"__u",
      "vtp_stripWww":false,
      "vtp_component":"HOST",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__v",
      "vtp_name":"gtm.triggers",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":""
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-605632-11",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false
    },{
      "function":"__u",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-605632-12",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-605632-25",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-605632-29",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false
    },{
      "function":"__u",
      "vtp_component":"HOST",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"clearbit-company.category.subIndustry"
    },{
      "function":"__remm",
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",19],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","^Automotive$","value","Automotive"],["map","key","^Education Services$|^Education$","value","Education"],["map","key","^Oil \u0026 Gas$|^Renewable Energy$|^Energy$|^Utilities$","value","Energy \u0026 Utilities"],["map","key","^Banking \u0026 Mortgages$|^Accounting$|^Finance$|^Financial Services$|^Asset Management \u0026 Custody Banks$|^Diversified Capital Markets$|^Fundraising$|^Investment Banking \u0026 Brokerage$|^Payments$|^Real Estate$","value","Financial Services"],["map","key","^Eyewear$|^Health \u0026 Wellness$|^Health Care$|^Health Care Services$|^Biotechnology$|^Life Sciences Tools \u0026 Services$|^Pharmaceuticals$","value","Healthcare \u0026 Life Sciences"],["map","key","^Semiconductors$|^Cloud Services$|^Internet$|^Internet Software \u0026 Services$|^Data Processing \u0026 Outsourced Services$|^Graphic Design$|^Communications$|^Computer Networking$|^Nanotechnology$|^Computer Hardware$|^Technology Hardware, Storage \u0026 Peripherals$","value","High Tech"],["map","key","^Insurance$","value","Insurance"],["map","key","^Aerospace \u0026 Defense$|^Capital Goods$|^Commercial Printing$|^Civil Engineering$|^Construction$|^Construction \u0026 Engineering$|^Mechanical Engineering$|^Electrical$|^Electrical Equipment$|^Industrials \u0026 Manufacturing$|^Industrial Machinery$|^Machinery$|^Trading Companies \u0026 Distributors$|^Industrials$|^Building Materials$|^Chemicals$|^Commodity Chemicals$|^Containers \u0026 Packaging$|^Gold$|^Metals \u0026 Mining$|^Paper Products$","value","Manufacturing"],["map","key","^Advertising$|^Broadcasting$|^Media$|^Movies \u0026 Entertainment$|^Public Relations$|^Publishing$","value","Media"],["map","key","^Consumer Discretionary$|^Consumer Goods$|^Consumer Electronics$|^Household Appliances$|^Photography$|^Leisure Facilities$|^Sporting Goods$|^Apparel, Accessories \u0026 Luxury Goods$|^Textiles$|^Textiles, Apparel \u0026 Luxury Goods$|^Distributors$|^Retailing$|^Home Improvement Retail$|^Homefurnishing Retail$|^Specialty Retail$|^Consumer Staples$|^Food Retail$|^Beverages$|^Agricultural Products$|^Food$|^Food Production$|^Packaged Foods \u0026 Meats$|^Tobacco$|^Cosmetics$","value","Retail \u0026 Consumer Goods"],["map","key","^Integrated Telecommunication Services$|^Wireless Telecommunication Services$","value","Telecommunications"],["map","key","^Shipping \u0026 Logistics$|^Airlines$|^Marine$|^Ground Transportation$|^Transportation$","value","Transportation \u0026 Logistics"],["map","key","^Consumer Services$|^Specialized Consumer Services$|^Casinos \u0026 Gaming$|^Hotels, Restaurants \u0026 Leisure$|^Leisure Facilities$|^Restaurants$|^Family Services$|^Legal Services$|^Business Supplies$|^Commercial Printing$|^Corporate \u0026 Business$|^Architecture$|^Automation$|^Consulting$|^Design$|^Human Resource \u0026 Employment Services$|^Professional Services$|^Research \u0026 Consulting Services$","value","Services"]]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mkto.form.values.Industry"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mkto.form.values.Company"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mkto.form.values.Job_Role__c"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"gaInsighteraEventCatagory"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"gaInsighteraEventAction"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"gaInsighteraEventLabel"
    },{
      "function":"__remm",
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",23],
      "vtp_fullMatch":false,
      "vtp_replaceAfterMatch":false,
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","cxo|^it|architect|engineer|developer","value","itRole"],["map","key","sales|marketing|finance|procurement|hr","value","business"],["map","key","Other","value","other"]]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"rtp-results.org"
    },{
      "function":"__v",
      "vtp_name":"gtm.elementClasses",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"clearbit-company.metrics.estimatedAnnualRevenue"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"optanonAction"
    },{
      "function":"__v",
      "vtp_name":"gtm.element",
      "vtp_dataLayerVersion":1
    },{
      "function":"__f",
      "vtp_component":"URL"
    },{
      "function":"__e"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"virtualPageTitle"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"virtualPageURL"
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-44483523-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"clearbit-company.name"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"clearbit-company.tags"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"clearbit-company.metrics"
    },{
      "function":"__j",
      "vtp_name":"tagName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"clearbit-company.metrics.annualRevenue"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"clearbit-company.category"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"clearbit-company.type"
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",44],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_ignoreCase":true,
      "vtp_defaultValue":"False",
      "vtp_map":["list",["map","key","Government","value","True"]]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"clearbit-type"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mkto.form.values.Title"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"rtp-results.industries"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"rtp-results.category"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"consentData"
    },{
      "function":"__u",
      "vtp_component":"PATH",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__f",
      "vtp_component":"URL"
    },{
      "function":"__e"
    },{
      "function":"__v",
      "vtp_name":"gtm.elementId",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.elementTarget",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.newUrlFragment",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.historyChangeSource",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.videoProvider",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.videoUrl",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.videoTitle",
      "vtp_dataLayerVersion":1
    }],
  "tags":[{
      "function":"__html",
      "priority":2000,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.AcquiaLift={account_id:\"MULESOFT\",liftAssetsURL:\"https:\/\/builder.lift.acquia.com\",liftDecisionAPIURL:\"https:\/\/us-east-1-decisionapi.lift.acquia.com\",authEndpoint:\"https:\/\/us-east-1-oauth2.lift.acquia.com\",contentReplacementMode:\"trusted\",site_id:\"msD8_prod\"};\u003C\/script\u003E\n\n\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/builder.lift.acquia.com\/lift.js\"\u003E\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":232
    },{
      "function":"__html",
      "priority":1000,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"\/\/cdn.freshmarketer.com\/160000\/407613.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":250
    },{
      "function":"__html",
      "priority":1000,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\u003Cstyle\u003E\n  .lift-in .ms-com-content-header-with-banner:not(.closed):not(.scrolled) .lift-localized-promobanner ~ header.ms-com-header .header-wrapper {\n    top: 58px;\n}\n\u003C\/style\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.AcquiaLift={account_id:\"MULESOFT\",liftAssetsURL:\"https:\/\/builder.lift.acquia.com\",liftDecisionAPIURL:\"https:\/\/us-east-1-decisionapi.lift.acquia.com\",authEndpoint:\"https:\/\/us-east-1-oauth2.lift.acquia.com\",contentReplacementMode:\"trusted\",site_id:\"msD8_prod_3\"};\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/builder.lift.acquia.com\/lift.js\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.addEventListener(\"acquiaLiftDecision\",function(c){document.querySelector(\".ms-com-content.ms-com-content-header\").classList.add(\"ms-com-content-header-with-banner\");document.querySelector(\"body\").classList.add(\"lift-in\");activePromoBanner()});\nfunction activePromoBanner(){function c(){var c=768\u003Cwindow.innerWidth?58:135,b=a.scrollTop;b=e.classList.contains(\"active\")?b:window.pageYOffset;b\u003Ec?(d.classList.add(\"header-scrolled\"),a.classList.add(\"scrolled\")):(d.classList.remove(\"header-scrolled\"),a.classList.remove(\"scrolled\"))}var d=document.querySelector(\"body\"),a=d.querySelector(\".ms-com-content.ms-com-content-header-with-banner\"),e=d.querySelector(\".mobile-header\");if(a){sessionStorage.getItem(\"ms-com-promo-banner\")?a.classList.add(\"closed\"):\na.classList.remove(\"closed\");var b=a.querySelector(\".field-block-content--field-cta a\");b\u0026\u0026b.addEventListener(\"click\",function(){ga(\"send\",\"event\",\"CTA\",\"Click\",\"TBD\")});b=a.querySelector(\".cross\");c();window.addEventListener(\"scroll\",c);window.addEventListener(\"resize\",c);a.addEventListener(\"scroll\",c);b.addEventListener(\"click\",function(){a.classList.add(\"closed\");d.classList.add(\"header-promo-closed\");sessionStorage.setItem(\"ms-com-promo-banner\",\"on\")})}};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":313
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.AcquiaLift={account_id:\"MULESOFT\",liftAssetsURL:\"https:\/\/builder.lift.acquia.com\",liftDecisionAPIURL:\"https:\/\/us-east-1-decisionapi.lift.acquia.com\",authEndpoint:\"https:\/\/us-east-1-oauth2.lift.acquia.com\",contentReplacementMode:\"trusted\",site_id:\"meetups_prod\"};\u003C\/script\u003E\n\n\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/builder.lift.acquia.com\/lift.js\"\u003E\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":231
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E(function(a,e,f,g,b,c,d){a.GoogleAnalyticsObject=b;a[b]=a[b]||function(){(a[b].q=a[b].q||[]).push(arguments)};a[b].l=1*new Date;c=e.createElement(f);d=e.getElementsByTagName(f)[0];c.async=1;c.src=g;d.parentNode.insertBefore(c,d)})(window,document,\"script\",\"\/\/www.google-analytics.com\/analytics.js\",\"ga\");ga(\"create\",\"UA-605632-12\",{siteSpeedSampleRate:10});ga(\"send\",\"pageview\");\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":266
    },{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function b(){!1===c\u0026\u0026(c=!0,Munchkin.init(\"564-SZS-136\"))}var c=!1,a=document.createElement(\"script\");a.type=\"text\/javascript\";a.async=!0;a.src=document.location.protocol+\"\/\/munchkin.marketo.net\/munchkin.js\";a.onreadystatechange=function(){\"complete\"!=this.readyState\u0026\u0026\"loaded\"!=this.readyState||b()};a.onload=b;document.getElementsByTagName(\"head\")[0].appendChild(a)})();\u003C\/script\u003E\n\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":279
    },{
      "function":"__paused",
      "vtp_originalTagType":"ua",
      "tag_id":203
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":222
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":235
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Outbound Links",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",13],
      "vtp_eventAction":["macro",7],
      "vtp_eventLabel":["macro",10],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":238
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":239
    },{
      "function":"__paused",
      "vtp_originalTagType":"ua",
      "tag_id":240
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":242
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":245
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":248
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":252
    },{
      "function":"__awct",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_enableConversionLinker":true,
      "vtp_enableProductReporting":false,
      "vtp_conversionValue":"0",
      "vtp_conversionCookiePrefix":"_gcl",
      "vtp_conversionId":"1064869428",
      "vtp_conversionLabel":"hjT4CN72ahC0vOL7Aw",
      "vtp_url":["macro",14],
      "vtp_enableProductReportingCheckbox":true,
      "vtp_enableNewCustomerReportingCheckbox":false,
      "vtp_enableEnhancedConversionsCheckbox":false,
      "vtp_enableRdpCheckbox":false,
      "tag_id":253
    },{
      "function":"__awct",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_enableConversionLinker":true,
      "vtp_enableProductReporting":false,
      "vtp_conversionCookiePrefix":"_gcl",
      "vtp_conversionId":"1064869428",
      "vtp_conversionLabel":"YXpaCNyj9XUQtLzi-wM",
      "vtp_url":["macro",14],
      "vtp_enableProductReportingCheckbox":true,
      "vtp_enableNewCustomerReportingCheckbox":false,
      "vtp_enableEnhancedConversionsCheckbox":false,
      "vtp_enableRdpCheckbox":false,
      "tag_id":254
    },{
      "function":"__sp",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_enableDynamicRemarketing":false,
      "vtp_conversionId":"1064869428",
      "vtp_customParamsFormat":"USER_SPECIFIED",
      "vtp_conversionLabel":"se6XCPzUjwMQtLzi-wM",
      "vtp_enableOgtRmktParams":true,
      "vtp_url":["macro",14],
      "vtp_enableRdpCheckbox":false,
      "tag_id":255
    },{
      "function":"__gclidw",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_enableCrossDomain":false,
      "vtp_enableCookieOverrides":false,
      "vtp_enableCrossDomainFeature":true,
      "vtp_enableCookieUpdateFeature":false,
      "tag_id":256
    },{
      "function":"__awct",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_enableConversionLinker":true,
      "vtp_enableProductReporting":false,
      "vtp_conversionCookiePrefix":"_gcl",
      "vtp_conversionId":"820228151",
      "vtp_conversionLabel":"lkWwCPX7xHsQt-COhwM",
      "vtp_url":["macro",14],
      "vtp_enableProductReportingCheckbox":true,
      "vtp_enableNewCustomerReportingCheckbox":false,
      "vtp_enableEnhancedConversionsCheckbox":false,
      "vtp_enableRdpCheckbox":false,
      "tag_id":257
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_overrideGaSettings":true,
      "vtp_fieldsToSet":["list",["map","fieldName","page","value",["macro",0]]],
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_gaSettings":["macro",16],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":268
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-605632-27",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":269
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_overrideGaSettings":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_gaSettings":["macro",17],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":270
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Demandbase",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",15],
      "vtp_eventAction":"sub_industry",
      "vtp_eventLabel":["macro",20],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":271
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":274
    },{
      "function":"__bzi",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_id":"6754",
      "tag_id":277
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":278
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":true,
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",15],
      "vtp_dimension":["list",["map","index","8","dimension",["macro",21]],["map","index","16","dimension",["macro",22]],["map","index","17","dimension",["macro",23]]],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":280
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":283
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":284
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":285
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":286
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":291
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":293
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":294
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":295
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":298
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":301
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Asset Downloads",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",17],
      "vtp_eventAction":["macro",7],
      "vtp_eventLabel":["macro",10],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":304
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Asset Downloads",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",17],
      "vtp_eventAction":["macro",7],
      "vtp_eventLabel":"WATCH NOW",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":305
    },{
      "function":"__twitter_website_tag",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_event_type":"PageView",
      "vtp_twitter_pixel_id":"nuq81",
      "vtp_event_parameters":["list",["map","param_table_key_column","content_category","param_table_value_column",["macro",20]]],
      "tag_id":308
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":315
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"63355_595",
      "tag_id":319
    },{
      "function":"__cl",
      "tag_id":320
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"63355_601",
      "tag_id":321
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"63355_602",
      "tag_id":322
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"63355_603",
      "tag_id":323
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"63355_604",
      "tag_id":324
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"63355_605",
      "tag_id":325
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"63355_606",
      "tag_id":326
    },{
      "function":"__hl",
      "tag_id":327
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"1500",
      "vtp_uniqueTriggerId":"63355_620",
      "tag_id":328
    },{
      "function":"__cl",
      "tag_id":329
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"63355_633",
      "tag_id":330
    },{
      "function":"__tl",
      "vtp_eventName":"gtm.timer",
      "vtp_interval":"500",
      "vtp_limit":"1",
      "vtp_uniqueTriggerId":"63355_645",
      "tag_id":331
    },{
      "function":"__tl",
      "vtp_eventName":"gtm.timer",
      "vtp_interval":"500",
      "vtp_limit":"1",
      "vtp_uniqueTriggerId":"63355_646",
      "tag_id":332
    },{
      "function":"__cl",
      "tag_id":333
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"63355_648",
      "tag_id":334
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003Evar timestamp=(new Date).toString(),userAgent=navigator.userAgent;\nfunction check_ga(){if(!0===",["escape",["macro",3],8,16],")if(\"function\"===typeof ga\u0026\u0026\"function\"===typeof ga.getAll){var a=ga.getAll()[0].get(\"clientId\");window.dataLayer.push({event:\"consentDataForTheRecord\",consentData:\"Consent groups: \"+",["escape",["macro",1],8,16],"+\"; \"+timestamp+\"; \"+a+\"; \"+userAgent})}else setTimeout(check_ga,500);else window.dataLayer.push({event:\"consentDataForTheRecord\",consentData:\"Consent groups: \"+",["escape",["macro",1],8,16],"+\"; \"+timestamp+\"; clientId is unavailable; \"+userAgent})}check_ga();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":205
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003Evar cookieName=\"actualOptanonConsent\",cookieValue=encodeURIComponent(",["escape",["macro",2],8,16],"),expirationTime=31536E3;expirationTime*=1E3;var date=new Date,dateTimeNow=date.getTime();date.setTime(dateTimeNow+expirationTime);expirationTime=date.toUTCString();document.cookie=cookieName+\"\\x3d\"+cookieValue+\"; expires\\x3d\"+expirationTime+\"; path\\x3d\/; domain\\x3d.\"+location.hostname.replace(\/^www\\.\/i,\"\");\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":207
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.AcquiaLift={account_id:\"MULESOFT\",liftAssetsURL:\"https:\/\/builder.lift.acquia.com\",liftDecisionAPIURL:\"https:\/\/us-east-1-decisionapi.lift.acquia.com\",authEndpoint:\"https:\/\/us-east-1-oauth2.lift.acquia.com\",contentReplacementMode:\"trusted\",site_id:\"blogs_prod\"};\u003C\/script\u003E\n\n\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/builder.lift.acquia.com\/lift.js\"\u003E\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":219
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.AcquiaLift={account_id:\"MULESOFT\",liftAssetsURL:\"https:\/\/builder.lift.acquia.com\",liftDecisionAPIURL:\"https:\/\/us-east-1-decisionapi.lift.acquia.com\",authEndpoint:\"https:\/\/us-east-1-oauth2.lift.acquia.com\",contentReplacementMode:\"trusted\",site_id:\"ms_connect_prod\"};\u003C\/script\u003E\n\n\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/builder.lift.acquia.com\/lift.js\"\u003E\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":220
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.AcquiaLift={account_id:\"MULESOFT\",liftAssetsURL:\"https:\/\/lift3assets.lift.acquia.com\/stable\",liftDecisionAPIURL:\"https:\/\/us-east-1-decisionapi.lift.acquia.com\",authEndpoint:\"https:\/\/us-east-1-oauth2.lift.acquia.com\",contentReplacementMode:\"trusted\",site_id:\"cvent\"};\u003C\/script\u003E\n\n\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/lift3assets.lift.acquia.com\/stable\/lift.js\"\u003E\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":221
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.AcquiaLift={account_id:\"MULESOFT\",liftAssetsURL:\"https:\/\/builder.lift.acquia.com\",liftDecisionAPIURL:\"https:\/\/us-east-1-decisionapi.lift.acquia.com\",authEndpoint:\"https:\/\/us-east-1-oauth2.lift.acquia.com\",contentReplacementMode:\"trusted\",site_id:\"mulesoft_dmc_prod\"};\u003C\/script\u003E\n\n\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/builder.lift.acquia.com\/lift.js\"\u003E\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":223
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.AcquiaLift={account_id:\"MULESOFT\",liftAssetsURL:\"https:\/\/builder.lift.acquia.com\",liftDecisionAPIURL:\"https:\/\/us-east-1-decisionapi.lift.acquia.com\",authEndpoint:\"https:\/\/us-east-1-oauth2.lift.acquia.com\",contentReplacementMode:\"trusted\",site_id:\"docs_prod\"};\u003C\/script\u003E\n\n\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/builder.lift.acquia.com\/lift.js\"\u003E\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":224
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.AcquiaLift={account_id:\"MULESOFT\",liftAssetsURL:\"https:\/\/builder.lift.acquia.com\",liftDecisionAPIURL:\"https:\/\/us-east-1-decisionapi.lift.acquia.com\",authEndpoint:\"https:\/\/us-east-1-oauth2.lift.acquia.com\",contentReplacementMode:\"trusted\",site_id:\"help-prod\"};\u003C\/script\u003E\n\n\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/builder.lift.acquia.com\/lift.js\"\u003E\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":225
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.AcquiaLift={account_id:\"MULESOFT\",liftAssetsURL:\"https:\/\/builder.lift.acquia.com\",liftDecisionAPIURL:\"https:\/\/us-east-1-decisionapi.lift.acquia.com\",authEndpoint:\"https:\/\/us-east-1-oauth2.lift.acquia.com\",contentReplacementMode:\"trusted\",site_id:\"training_prod\"};\u003C\/script\u003E\n\n\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/builder.lift.acquia.com\/lift.js\"\u003E\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":226
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E_tcaq.push([\"capture\",\"home-promobanner-london-cta\"]);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":227
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E_tcaq.push([\"capture\",\"connect-london-cta-nav\"]);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":228
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E_tcaq.push([\"capture\",\"connect-london-cta-body\"]);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":229
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E_tcaq.push([\"capture\",\"connect-london-cta-bottom\"]);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":230
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Econsole.log(\"Cookie Preferences updated\");\u003C\/script\u003E  ",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":243
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efunction processForm(a){a=document.querySelector(\".mktoForm #Email\").value;_tcaq.push([\"captureIdentity\",a,\"email\"])}document.addEventListener(\"DOMContentLoaded\",function(a){(a=document.querySelector(\".mktoForm\"))\u0026\u0026(a.attachEvent?a.attachEvent(\"submit\",processForm):a.addEventListener(\"submit\",processForm))});\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":244
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Ewindow._fs_debug=!1;window._fs_host=\"fullstory.com\";window._fs_org=\"B7VWZ\";window._fs_namespace=\"FS\";\n(function(f,h,k,l,g,d,a,e){k in f?f.console\u0026\u0026f.console.log\u0026\u0026f.console.log('FullStory namespace conflict. Please set window[\"_fs_namespace\"].'):(a=f[k]=function(c,b){a.q?a.q.push([c,b]):a._api(c,b)},a.q=[],d=h.createElement(l),d.async=1,d.src=\"https:\/\/\"+_fs_host+\"\/s\/fs.js\",e=h.getElementsByTagName(l)[0],e.parentNode.insertBefore(d,e),a.identify=function(c,b){a(g,{uid:c});b\u0026\u0026a(g,b)},a.setUserVars=function(c){a(g,c)},e=\"rec\",a.shutdown=function(c,b){a(e,!1)},a.restart=function(c,b){a(e,!0)},a.identifyAccount=\nfunction(c,b){d=\"account\";b=b||{};b.acctId=c;a(d,b)},a.clearUserCookie=function(){})})(window,document,window._fs_namespace,\"script\",\"user\");\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":251
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n  \u003Cscript async data-gtmsrc=\"https:\/\/www.googletagmanager.com\/gtag\/js?id=AW-CONVERSION_ID\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n  \u003Cscript type=\"text\/gtmscript\"\u003Ewindow.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag(\"set\",\"allow_ad_personalization_signals\",!1);gtag(\"js\",new Date);gtag(\"config\",\"AW-1064869428\");gtag(\"config\",\"AW-820228151\");\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":258
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E(function(a,e,f,g,b,c,d){a.GoogleAnalyticsObject=b;a[b]=a[b]||function(){(a[b].q=a[b].q||[]).push(arguments)};a[b].l=1*new Date;c=e.createElement(f);d=e.getElementsByTagName(f)[0];c.async=1;c.src=g;d.parentNode.insertBefore(c,d)})(window,document,\"script\",\"https:\/\/www.google-analytics.com\/analytics.js\",\"ga\");ga(\"create\",\"UA-44483523-1\",{siteSpeedSampleRate:100});ga(\"send\",\"pageview\");\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":263
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript async data-gtmsrc=\"https:\/\/www.googletagmanager.com\/gtag\/js?id=UA-605632-11\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag(\"js\",new Date);gtag(\"config\",\"UA-605632-11\",{siteSpeedSampleRate:100});\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":265
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E_tcaq.push([\"capture\",\"anypoint_trial\"]);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":276
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cstyle\u003E\n  [tabindex=\"0\"]:focus {\n    outline: none;\n  }\n  .ot-sdk-show-settings {\n\tdisplay: inline-block !important;\n  }\n\u003C\/style\u003E\n\n\u003Cscript data-gtmsrc=\"https:\/\/www.mulesoft.com\/www\/prod\/oneTrust\/fc594183-7384-4f03-8c43-1f81571521b7.js\" type=\"text\/gtmscript\" charset=\"UTF-8\"\u003E\u003C\/script\u003E  \n\u003Cscript type=\"text\/gtmscript\"\u003Efunction OptanonWrapper(){localStorage.setItem(\"otsettings\",OptanonActiveGroups)};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":281
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":" \n\u003Cscript type=\"text\/gtmscript\"\u003E(function(a,b,c,f,e){a[c]=a[c]||function(){(a[c].q=a[c].q||[]).push(arguments)};a[c].a=e;var d=b.createElement(\"script\");d.async=!0;d.type=\"text\/javascript\";d.src=f+\"?aid\\x3d\"+e;b=b.getElementsByTagName(\"script\")[0];b.parentNode.insertBefore(d,b)})(window,document,\"rtp\",\"\/\/sjrtp5-cdn.marketo.com\/rtp-api\/v1\/rtp.js\",\"mulesoft\");rtp(\"send\",\"view\");rtp(\"get\",\"campaign\",!0);\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":288
    },{
      "function":"__html",
      "metadata":["map"],
      "setup_tags":["list",["tag",80,0]],
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efunction callbackFunction(a){var b=a.results;a=a.results.isp;b\u0026\u0026!a\u0026\u0026dataLayer.push({\"rtp-results\":b})}rtp(\"get\",\"visitor\",callbackFunction);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":289
    },{
      "function":"__html",
      "metadata":["map"],
      "setup_tags":["list",["tag",80,0]],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efunction msie(){var a=window.navigator.userAgent;a=a.indexOf(\"MSIE \");return 0\u003Ca||!!navigator.userAgent.match(\/Trident.*rv:11\\.\/)}!1;rtp(\"send\",\"view\");rtp(\"get\",\"campaign\",!0);rtp(\"set\",\"rcmd\",\"richmedia\",{template2:{\"rcmd.title.text\":\"\",\"rcmd.cta.text\":\"Learn more\"}});rtp(\"get\",\"rcmd\",\"richmedia\");msie();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":292
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E(function(){var a=document.createElement(\"script\");a.type=\"text\/javascript\";a.async=!0;a.src=\"\/\/siteimproveanalytics.com\/js\/siteanalyze_6035448.js\";var b=document.getElementsByTagName(\"script\")[0];b.parentNode.insertBefore(a,b)})();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":297
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E_tcaq.push([\"capture\",\"anypoint_studio_download\"]);\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":300
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n\t\u003Cscript type=\"text\/gtmscript\"\u003Efunction trafficSourceHelper(){this.createCookies=function(){var a=new Date;a.setTime(a.getTime()+8639136E5);var b=\";expires\\x3d\"+a.toGMTString();a=this.parseQueryString();var d=\".google. .bing. .yahoo. .baidu. .yandex. .ask. .babylon. .so. .msn. .aol. .lycos. .ask. .netscape. .cnn. .about. .duam. .eniro. .search. .terra.\".split(\" \");a.utm_medium?(this.delete_cookie(\"utm_medium\"),this.setCookie(\"utm_medium\",a.utm_medium,b)):null===getCookieForMarketo(\"utm_medium\")\u0026\u0026(\"\"==document.referrer?this.setCookie(\"utm_medium\",\n\"direct\",b):(d.forEach(function(a,d){-1!=document.referrer.indexOf(a)\u0026\u0026this.setCookie(\"utm_medium\",\"organic\",b)}.bind(this)),null===getCookieForMarketo(\"utm_medium\")\u0026\u0026this.setCookie(\"utm_medium\",\"referral\",b)));null===getCookieForMarketo(\"gclid\")\u0026\u0026void 0!=a.gclid\u0026\u0026this.setCookie(\"gclid\",a.gclid,b);void 0!=a.utm_source\u0026\u0026this.setCookie(\"utm_source\",a.utm_source,b)};this.setCookie=function(a,b,d){document.cookie=a+\"\\x3d\"+b+d+\";path\\x3d\/\"};this.parseQueryString=function(){var a={},b=window.location.search.substring(1);\nb=b.split(\"\\x26\");for(var d=0;d\u003Cb.length;d++){var c=b[d].split(\"\\x3d\");if(\"undefined\"===typeof a[c[0]])a[c[0]]=decodeURIComponent(c[1]);else if(\"string\"===typeof a[c[0]]){var e=[a[c[0]],decodeURIComponent(c[1])];a[c[0]]=e}else a[c[0]].push(decodeURIComponent(c[1]))}return a};this.delete_cookie=function(a){document.cookie=a+\"\\x3d ; expires \\x3d Thu, 01 Jan 1970 00:00:00 GMT;\"}}\ngetCookieForMarketo=function(a){if(0!==arguments.length||\"string\"===typeof opts){var b=document.cookie.match(\"(?:^|; )\"+a+\"\\x3d([^;]+)\");return b?b[1]:null}};tsh=new trafficSourceHelper;tsh.createCookies();\nwindow.addEventListener(\"load\",function(){\"object\"===typeof MktoForms2\u0026\u0026MktoForms2.whenReady(function(a){a.addHiddenFields({Web_Campaign__c:getCookieForMarketo(\"utm_campaign\"),Web_Source__c:getCookieForMarketo(\"utm_source\"),Webmeduim__c:getCookieForMarketo(\"utm_medium\"),Web_Keyword__c:getCookieForMarketo(\"utm_term\"),Web_Content__c:getCookieForMarketo(\"utm_content\"),GCLID__c:getCookieForMarketo(\"gclid\")})})});\u003C\/script\u003E\n\t",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":303
    },{
      "function":"__html",
      "metadata":["map"],
      "vtp_html":"\n\u003Cscript data-gtmsrc=\"\/\/platform.twitter.com\/oct.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Etwttr.conversion.trackPid(\"l47ev\");\u003C\/script\u003E\n\u003Cnoscript\u003E\n\u003Cimg height=\"1\" width=\"1\" style=\"display:none;\" alt=\"\" src=\"https:\/\/analytics.twitter.com\/i\/adsct?txn_id=l47ev\u0026amp;p_id=Twitter\"\u003E\n\u003C\/noscript\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":306
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript data-gtmsrc=\"\/\/platform.twitter.com\/oct.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Etwttr.conversion.trackPid(\"nue0l\",{tw_sale_amount:0,tw_order_quantity:0});\u003C\/script\u003E\n\u003Cnoscript\u003E\n\u003Cimg height=\"1\" width=\"1\" style=\"display:none;\" alt=\"\" src=\"https:\/\/analytics.twitter.com\/i\/adsct?txn_id=nue0l\u0026amp;p_id=Twitter\u0026amp;tw_sale_amount=0\u0026amp;tw_order_quantity=0\"\u003E\n\u003Cimg height=\"1\" width=\"1\" style=\"display:none;\" alt=\"\" src=\"\/\/t.co\/i\/adsct?txn_id=nue0l\u0026amp;p_id=Twitter\u0026amp;tw_sale_amount=0\u0026amp;tw_order_quantity=0\"\u003E\n\u003C\/noscript\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":307
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript data-gtmsrc=\"https:\/\/cdn.cookielaw.org\/consent\/1e1023fa-0dcf-4e7f-bd2b-70ec1c636d0f-test.js\" type=\"text\/gtmscript\" charset=\"UTF-8\"\u003E\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Efunction OptanonWrapper(){};\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":310
    },{
      "function":"__html",
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003EsetTimeout(function(){window.dataLayer.push({event:\"optanonConsentUpdated\"})},1E3);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":311
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E(function(c){function d(){var a;if(a=document.querySelector(\".mktoErrorMsg\")){var e=a.textContent||a.innerText;a=document.querySelector(\"input.mktoInvalid, .mktoInvalid input\");window.dataLayer.push({event:\"mkto.form.error\",\"mkto.form.error.message\":e,\"gtm.element\":a,\"gtm.elementClasses\":a\u0026\u0026a.className||\"\",\"gtm.elementId\":a\u0026\u0026a.id||\"\",\"gtm.elementName\":a\u0026\u0026a.name||\"\",\"gtm.elementTarget\":a\u0026\u0026a.target||\"\"})}}c\u0026\u0026(c.whenReady(function(a){window.dataLayer.push({event:\"mkto.form.ready\",\"mkto.form.id\":a.getId(),\n\"mkto.form.submittable\":a.submittable(),\"mkto.form.allFieldsFilled\":a.allFieldsFilled(),\"mkto.form.values\":a.getValues()});a.onValidate(function(a){window.dataLayer.push({event:\"mkto.form.validate\",\"mkto.form.valid\":a});setTimeout(d,0)});a.onSubmit(function(a){var b=a.getFormElem().find('button[type\\x3d\"submit\"]');window.dataLayer.push({event:\"mkto.form.submit\",\"mkto.form.id\":a.getId(),\"mkto.form.submittable\":a.submittable(),\"mkto.form.allFieldsFilled\":a.allFieldsFilled(),\"mkto.form.values\":a.getValues(),\n\"mkto.form.button\":{classes:b.attr(\"class\"),text:b.text(),type:\"submit\"}})});a.onSuccess(function(a,b){window.dataLayer.push({event:\"mkto.form.success\",\"mkto.form.values\":a,\"mkto.form.followUpUrl\":b})})}),c.whenRendered(function(a){window.dataLayer.push({event:\"mkto.form.rendered\",\"mkto.form.id\":a.getId(),\"mkto.form.submittable\":a.submittable(),\"mkto.form.allFieldsFilled\":a.allFieldsFilled(),\"mkto.form.values\":a.getValues()})}))})(window.MktoForms2);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":312
    },{
      "function":"__html",
      "metadata":["map"],
      "setup_tags":["list",["tag",0,0]],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Evar lftId=(location.search.split(\"lft\\x3d\")[1]||\"\").split(\"\\x26\")[0];_tcaq.push([\"captureIdentity\",lftId,\"account\"]);\u003C\/script\u003E  ",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":314
    },{
      "function":"__html",
      "metadata":["map"],
      "setup_tags":["list",["tag",79,0]],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Evar otsettings=localStorage.getItem(\"otsettings\");\nif(otsettings\u0026\u0026!otsettings.includes(\"3\")){blockMarketoScripts();var marketoForms=document.querySelectorAll('form[id*\\x3d\"mktoForm\"]');for(i=0;i\u003CmarketoForms.length;i++)marketoForms[i].innerHTML='\\x3clabel\\x3eFunctional cookies are turned off. You can enable them back \\x3ca href\\x3d\"#\" onclick\\x3d\"document.getElementById(\\'ot-sdk-btn\\').click();return false;\"\\x3ehere\\x3c\/a\\x3e\\x3c\/label\\x3e',marketoForms[i].setAttribute(\"id\",\"removed\"),marketoForms[i].style.background=\"#F4FCFF\",marketoForms[i].style.padding=\n\"30px\",marketoForms[i].style.maxWidth=\"370px\",marketoForms[i].style[\"float\"]=\"left\",console.log(\"Remove Marketo Form\")}function blockMarketoScripts(){for(var b=document.querySelectorAll('script[src*\\x3d\"forms2\"]'),a=0;a\u003Cb.length;a++)b[a].remove()};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":317
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cstyle\u003E\n  [tabindex=\"0\"]:focus {\n    outline: none;\n  }\n  .ot-sdk-show-settings {\n\tdisplay: inline-block !important;\n  }\n\u003C\/style\u003E\n\n\u003Cscript data-gtmsrc=\"https:\/\/www.mulesoft.com\/www\/prod\/oneTrust\/fc594183-7384-4f03-8c43-1f81571521b7.js\" type=\"text\/gtmscript\" charset=\"UTF-8\"\u003E\u003C\/script\u003E  \n\u003Cscript type=\"text\/gtmscript\"\u003Efunction OptanonWrapper(){localStorage.setItem(\"otsettings\",OptanonActiveGroups)};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":318
    }],
  "predicates":[{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"consentDataForTheRecord"
    },{
      "function":"_eq",
      "arg0":["macro",4],
      "arg1":"false"
    },{
      "function":"_eq",
      "arg0":["macro",5],
      "arg1":"false"
    },{
      "function":"_eq",
      "arg0":["macro",3],
      "arg1":"false"
    },{
      "function":"_re",
      "arg0":["macro",6],
      "arg1":".*"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"https:\/\/dev-mulesoftd8.www.msit.io"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"gtm.js"
    },{
      "function":"_eq",
      "arg0":["macro",2],
      "arg1":"false"
    },{
      "function":"_re",
      "arg0":["macro",8],
      "arg1":"\/ty|\/guides\/quick-start\/designing-your-first-api|PathFactory-ty"
    },{
      "function":"_re",
      "arg0":["macro",8],
      "arg1":"vents\/Registrations\/MyRegistration"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"flow\/checkout-flow"
    },{
      "function":"_eq",
      "arg0":["macro",9],
      "arg1":"Confirm Order"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"gtm.click"
    },{
      "function":"_cn",
      "arg0":["macro",10],
      "arg1":"mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",11],
      "arg1":"blogs.mulesoft.com"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"gtm.linkClick"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"(^$|((^|,)63355_595($|,)))"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"blogs.mulesoft.com"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"gtm.load"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"developer.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"www.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"\/cn\/"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"\/de\/"
    },{
      "function":"_re",
      "arg0":["macro",8],
      "arg1":".*"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"\/careers"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"investors.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"life-at-mulesoft\/"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"help.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"content\/vidyard-generic-contact-us"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"\/ty\/contact"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"\/ty\/dl\/studio"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"\/Events\/Registrations\/MyRegistration.aspx"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"connect.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"\/tcat\/"
    },{
      "function":"_cn",
      "arg0":["macro",11],
      "arg1":"transformwithapis.com"
    },{
      "function":"_cn",
      "arg0":["macro",11],
      "arg1":"mulesoft.staging.mulesoft.com"
    },{
      "function":"_re",
      "arg0":["macro",11],
      "arg1":"cvent\\.com|mulesoftevents\\.com"
    },{
      "function":"_re",
      "arg0":["macro",18],
      "arg1":"www|developer"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"Demandbase_Loaded"
    },{
      "function":"_re",
      "arg0":["macro",11],
      "arg1":"docs\\."
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"\/press-center\/"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"\/integration-partner\/"
    },{
      "function":"_re",
      "arg0":["macro",8],
      "arg1":"\/legal\/|\/privacy-policy"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"\/event"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"optanonConsentUpdated"
    },{
      "function":"_eq",
      "arg0":["macro",5],
      "arg1":"true"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"mkto.form.rendered"
    },{
      "function":"_cn",
      "arg0":["macro",18],
      "arg1":"beta.docs.stgx.mulesoft.com"
    },{
      "function":"_re",
      "arg0":["macro",11],
      "arg1":"developer.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"training.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",11],
      "arg1":"help.mulesoft.com"
    },{
      "function":"_eq",
      "arg0":["macro",27],
      "arg1":"undefined"
    },{
      "function":"_re",
      "arg0":["macro",6],
      "arg1":"mkto.form.rendered"
    },{
      "function":"_re",
      "arg0":["macro",22],
      "arg1":"city.of.dallas|credit.europe.bank|cec.entertainment|schroders.plc|hager.electro.gmbh.co.kg|queensland.department.of.justice.attorney.general|panasonic.avionics.corporation|data.3|m.lnlycke.health.care|janney.montgomery.scott.llc|puget.energy.inc.|lutron.electronics.co.inc.|mellanox.technologies|sanmina.sci.systems.canada.inc|premier.tech.lt.e|methanex.corporation|fraser.health.authority|wilton.brands.inc.|titan.machinery.inc.|rdo.equipment.co.|optionsxpress.holdings.inc.|bremer.financial.corporation|jerry.s.enterprises.inc.|lund.food.holdings.inc.|osi.group|trw.automotive.holdings.corp.|mnp.llp|tolko.industries.ltd.|canadian.nuclear.laboratories.ltd.|university.of.victoria|manitoba.agricultural.services.corporation|ws.packaging.group.inc.|certco|pomp.s.tire.service|hydrite.chemical.co.|piggly.wiggly.midwest.llc|gtcr.golder.rauner.l.l.c.|gardaworld|astellas.pharma.us.inc.|kapstone.paper.and.packaging.corporation|heartland.financial.usa.inc.|inteva.products|ftd.companies.inc.|akorn.inc.|beam.inc.suntory.japan.is.parent.|modine.manufacturing.company.inc|national.energy.board|aldo.group.inc.|rexel.am.rique.du.nord.inc|dvb.bank|chamberlain.group.inc.|cooper.tire.rubber|great.lakes.cheese.company.inc.|rosen.s.diversified|api.group|donaldson.company.inc.|standard.textile.co.inc.|wasserstrom.company|mclaren.health.care|water.street.healthcare.partners.llc|taylor.wimpey.plc|zs.associates|steel.dynamics.inc.|nisource.inc.|deutsche.kreditbank.ag.dkb.|sierra.wireless.inc.|winnipeg.regional.health.authority|ansell.limited|sasktel|isala.ziekenhuis|honda.of.america.mfg.inc.|dealer.tire.llc|healthpartners|compass.group.canada.ltd|contrans.corp|old.national.bancorp.|olympic.steel.inc.|bendix.commercial.vehicle.systems.llc|davey.tree.expert.company|american.mortgage.service.company|bluestem.brands|cedar.fair.l.p.|sapp.bros|community.choice.financial.inc.|kehe.distributors.llc|hydro.ottawa.limited|buckle.inc.|manitowoc.company|skyline.corporation|coborn.s.inc.|select.comfort.corporation|starkey.hearing.technologies.starkey.laboratories.inc.|emera.incorporated|true.value.company|world.kitchen.llc|horace.mann.educators.corporation|quill.corporation|aecon|citywide.home.loans|varex.imaging.corporation|vectren.corporation|finish.line.inc.|eby.brown|johnson.bank|staples.canada|constellation.software.inc|masonite.international.corporation|fairmont.raffles.hotels.international|greater.toronto.airports.authority|omnisource.corporation|volksbank.mittelhessen.eg|canadian.standards.association|andersons.inc.|littelfuse.inc.|equity.lifestyle.properties|midland.paper.company|trillium.health.partners|la.capitale.assureur.de.l.administration.publique.inc|hendrickson.usa|direct.supply|transport.accident.commission|poet.llc|phoenix.contact|stonegate.pub.co.ltd.|erste.abwicklungsanstalt|s.oliver.bernd.freier.gmbh.co.kg|marc.o.polo.ag|the.bank.of.east.asia|cma.cgm|john.clark.holdings.ltd.|systeme.u.centrale.nationale|deichmann.se|arvato.digital.services.llc|bpifrance|praktikertj.nst.ab|legacy.texas.bank|rensa.groep.b.v.|paul.hartmann.ag|great.west.life.co|scalzo.foods|progrexion|global.brands.group|extron.electronics|steadfast.companies|county.of.santa.barbara.ca|amex.gbt|intertek.group.plc|merrick.bank.corporation|pcl.construction.enterprises.inc.|famous.brands.international|craftworks.restaurants.breweries.inc.|1.800.flowers.com.inc.|washington.department.of.transportation|nhs.digital|helm.ag|kfw.group|flow.traders.nv|la.maison.simons|apoteket.ab|villeroy.boch|compugroup.medical.se|gerry.weber.international.ag|rehau.ag.co|pension.insurance.corporation.group.ltd.|city.of.fort.collins|master.empower.retirement.root.|xl.catlin|ceva.sante.animale|stearns.lending|l.a.fitness.international.llc|quest.software|gerdau.ameristeel.us.inc|eurobaustoff.handelsgesellschaft.mbh.co.kg|larry.h.miller.group|monster.beverage.corporation|kemper.corporation|pimco.sub.of.allianz.operates.independently.|keck.hospital.of.usc|united.internet.ag|aurora.capital.group|cedars.sinai.medical.center|primary.residential.mortgage|merit.medical.systems|nicholas.company|colorado.pera.state|leidos|flexigroup.limited|m.g|merz.usa|reliance.steel.aluminum|xerox.uk|carter.s|hmv|apria.healthcare.group|skatteverket|vidant.health|choctaw.nation.of.oklahoma|southside.bank|accident.fund.ins.|lagardere.travel|the.kraft.heinz.company.chicago.hq.|telent.technology.services.ltd|tt.electronics.plc|chassix|city.of.greater.geelong|j.d.williams|fonds.de.solidarit.du.ftq|regie.autonome.des.transports.parisiens|deckers.brands.emea|olympus.europa.se.co.kg|valeo|iag.new.zealand|the.good.guys|fis.uk|northern.sydney.local.health.district|mec.global.uk.|blue.care|brightstar|mutual.of.omaha.bank|balfour.beatty.europe|coke.one.north.america|vivint|atb.financial|msci|british.sugar|u.s.patent.and.trademark.office|grafton.group|air.force|brault.martineau|schibsted.enterprise.technology.ab|loyaltyone.co.|delta.dental.of.minnesota|altisource|medical.university.of.south.carolina|dentons|kik.custom.products.inc.|cabot.financial.limited|united.cooperative|first.citizens.bank|brinker.international.inc.|william.hill.plc|agf.management.limited|central.coast.local.health.district|athenahealth.inc.|transport.for.london|chicago.bridge.iron.company|bny.mellon.europe|lenovo.holding.company.inc.|sallie.mae|metal.management.inc.|postnord|illawarra.shoalhaven.local.health.district|lv.general.insurance.group|metlife|simplot.australia.pty.ltd|nintendo.of.america|blue.cross.and.blue.shield.of.massachusetts.inc.main.account.page.|rei|drybar.holdings.llc|ngl.energy.partners.lp|petsmart.inc.|eneco|university.of.connecticut|lansforsakringar.publ.ab|kruger.inc.|tchibo.gmbh|euromoney.institutional.investor.plc|nsw.department.of.premier.and.cabinet.dpc.|nt.department.of.health|new.american.funding|compass.group.uk|charles.taylor.plc|tower.hamlets.council|patrick.industries|state.of.idaho|cognizant.technology.solutions.u.s.corporation|paramount.pictures|ardagh.group.north.america|the.north.west.company|fair.work.ombudsman|rsm.uk|department.of.education.tasmania|abm|cit.group|columbia.university.medical.center|f5.networks|pan.american.life.insurance.group.inc.|state.of.north.dakota|williams.companies.inc.|city.of.winnipeg.the|opko.health|deckers.outdoor.corporation|cushman.wakefield|rochester.public.utilities|city.of.ballarat|royal.canadian.mounted.police|graybar.electric.company|melbourne.health|db.schenker.inc.|kci.usa.inc.|ig.index.plc|gsk.australia|sandvik|freshdirect.llc|polisen.rps.|station.casinos|the.dun.bradstreet.corporation|nihon.kohden.america|boston.medical.center|first.command.financial.services|health.partners.plans|henry.schein.nl|shoe.show|hightower.advisors.llc|interface|allied.electronics|qantas.airways.limited|camelot.group.limited|chesapeake.energy|ultimate.software|vicsuper|realty.income|warburtons|department.of.commerce.national.institute.of.standards.and.technology|commonwealth.of.massachusetts|carrier.enterprise|mn|b.m.retail|health.canada|state.of.texas.texas.higher.education.coordinating.board|tokio.marine.kiln|rbs.invoice.finance|mtd.products|el.camino.hospital|brisbane.city.council|infosys.australia|kbr|jewson.limited|world.wide.technology|rackspace.us.inc.|oncology.nursing.society|mindshare.uk.|aptean|lombard.odier.north.america|manitoba.liquor.and.lotteries.corporation|worldpay|caliber.home.loans.inc.|sodexo.sweden|global.exchange.services.opentext.|hungry.jacks|cbh.group|state.of.maine|officemax|southwire|beckman.coulter|miller.insurance|atradius|payments.canada|udg.healthcare|leeds.building.society|irs|sainsburys.bank|united.states.nuclear.regulatory.commission|alcoa.inc.|thunderbird.asu|mars.information.services.australia.|airservices.australia|state.of.ohio.ohio.department.of.job.and.family.services|nandos|hyland.software|healthscope|australian.unity.limited|arizona.department.of.child.safety|ochsner.health.system|community.healthcare.system|premier.farnell|bombardier.uk|perkinelmer|tuesday.morning|university.of.washington|espn.inc.|akademiska.sjukhuset|nepean.blue.mountials.local.health.district|rijkswaterstaat|copart.inc.|alstom.grid|blackbaud.inc|intertek|texas.mutual.insurance.company|hertz.nordic|deloitte.united.kingdom|j.m.smith.corporation|rentokil.initial.1927.plc|at.t.partner.solutions|novae.group|bear.river.associates|allegheny.health.network.hospital.provider.network.|assistrx|sammons.financial.group.member.companies|acco.brands|parkland.health.hospital.system|jordan.health.services|arts.council.england|wandsworth.council|zynga.inc.|california.dept.of.water.resources|city.of.henderson.nv|spotify|baystate.health|jlt.group|live.nation.entertainment|pggm|sunedison.inc.|vertiba|tcs.uk.end.customer|agero.inc|red.robin.gourmet.burgers|halliburton|videotron.g.p.|compass.group.australia|mitchells.butlers|ppd.inc.|calfrac.well.services.ltd|gemeente.rotterdam|flatiron.health|caci.inc.corp|ssp.worldwide.australia.|city.of.toronto|orange.county|ricoh.australia.pty.ltd|festo.ag.co.kg|adeo.services|moneysupermarket.com.group|aramice|eastman.credit.union|simply.energy|universal.forest.products|campbell.arnott.s|bidfood.australia|decmil.group.limited|nhs.digital|atlific.hotels|trumpf.gmbh.co.kg|new.flyer.industries.canada.ulc|bmw.financial.services.australia|h.j.heinz.company.australia.limited|ey.belgium|age.uk|kimberly.clark|nuon.vattenfall|great.west.financial|westlake.services.llc|a.gas.us.holdings.inc.|british.columbia.investment.management.corporation|summit.electric.supply.co.inc.|driscoll.s|brookstone|innovacare.health|100inc|adaptus.llc|western.region.water.corporation|ditech.financial.llc|workers.compensation.fund|department.of.justice.and.regulation.victoria.australia|harwoods|motorsport.aftermarket.group|ministerie.van.buitenlandse.zaken.foreign.affairs|heraeus|fiesta.restaurant.group|yelp|rentokil.us.headquarters|houlihan.lokey|origin.energy.retail.limited|telstra.super|transport.safety.victoria|coca.cola.european.enterprises.uk.|lend.lease|tupperware.brands.corporation|clark.county.nv|honeywell.aerospace|cuscal|nav.canada|the.university.of.wollongong|hostplus|downer.group|hitachi.consulting|viessmann.manufacturing.us|moneygram.international.inc|nbn.co|ausnet.services|specialty.fashion.group|vitality.corporate.services.ltd|fortress.investment.group|unicredit.dab.bank.ag|securian.financial.group|gymboree|one.america.financial.partners.inc|super.retail.group|oneok|rexel.holdings.australia|cottonwood.financial.administrative.services.llc|lennar|byl.companies|australia.radiation.protection.and.nuclear.safety.agency|formativ.health|general.datatech|abn.amro.clearing.bank.n.v.|pepper.group.limited|signature.healthcare.llc|brenntag.ag|oklahoma.department.of.public.safety|tullverket|metro.north.hospital.and.health.service|eversource.energy|gfk|kite.realty.group|fullbeauty.brands.an.apax.portfolio.company.|swissport.uk|denali.federal.credit.union|jeld.wen.australia.pty.limited|guy.s.and.st.thomas.nhs.foundation.trust|abb.group|henkel.ag.co.kgaa|south.east.sydney.local.health.district|peek.cloppenburg.kg.hamburg|sydney.local.health.district|wellmont.health.system|united.states.secret.service|promutuel.insurance|softcat.end.user.|canada.revenue.agency|statistics.canada|vhv.gruppe|zespri.group|millicom.international.services.llc|komatsu.australia.pty.ltd|zespri.international|home.hardware.stores.limited|cairns.and.hinterland.hospital.and.health.service|children.s.health.queensland.hospital.and.health.service|metro.south.hospital.health.service|gold.coast.hospital.and.health.service|danske.bank.uk|southwark.council|dm.drogerie.markt.gmbh.co.kg|townsville.hospital.health.service|scottsdale.healthcare.corp.|svenska.kyrkan|blacktown.city.council|western.nsw.local.health.district|aurora.energy.limited|marriott.ownership.resorts.inc.|newton.investment.management.ltd.|caremore|compass.group.fr|independer|bell.helicopter|vgm.group|main.roads.wa|rpra|extra.space.storage|bank.victoria|onebeacon.insurance.company|under.armour.inc.|vtb.capital.uk|simmons.bank|newday|dxc|california.state.university.monterey.bay|adyen.nederland|global.experience.specialists.inc|golden.gaming.llc|stonehage.fleming|shv.energy.n.v.|crawford.nz|hmcts|detailresult.groep|indosuez.wealth.management|viterra|tokio.marine.hcc|california.department.of.justice|royal.a.ware|hm.land.registry|cincinnati.insurance.company|first.national.bank.of.omaha|blue.cross.blue.shield.of.minnesota|government.of.northwest.territories|marsh.mclennan.companies.inc.|lanxess|phoenix.pharmahandel|unitymedia|beacon.health.options|blue.cross.blue.shield.of.massachusetts|chisholm.institute|nyu.langone.health|rail.delivery.group|us.lbm|selfridges|star.track.express.pty.limited|midland.states.bank|south32|hms.holdings.corp.|resmed|university.of.iowa|exin.financial.services.holding.b.v.|brainspace.corporation|university.of.newcastle|pet.supplies.plus|kingston.technology.company.inc.|city.of.long.beach|american.airlines.federal.credit.union.inc|aegon.uk|boston.consulting.group.main.account.page.|camaieu.international|celio.france|sammons.enterprises|city.of.edmonton.alberta|city.of.atlanta|city.of.houston.tx|aarp|kansas.city.life.insurance.company|state.of.ohio.ohio.department.of.mental.health.and.addiction.services|state.of.california.california.department.of.child.support.services|aicpa|money3|von.maur|transavia|relx.plc|castle.harlan|sabic.europe|td.bank.group.uk|mondelez.uk|a.s.watson.health.beauty.continental.europe.b.v.|abbvie.uk|zilveren.kruis.achmea|abb.north.america|cdiscount|icap.plc|capita.plc|argo.group.us|herff.jones|delphi|educational.testing.service|sas.institute|overstock.com|farm.credit.canada|victoria.police|department.of.economic.development.jobs.transport.resources|one.stop.stores.ltd.|department.of.the.interior|essity.gmbh|sephora|groupe.canam.inc|validus|cable.and.wireless|shaw.communications|internap.network.services|university.of.wisconsin.madison|centurion|mohave.community.federal.credit.union|auckland.council|ppl.corporation|ig.group.plc|schiphol.group|goldcorp|ifds.uk|ancestry.com|nisa.investment.advisors.llc|ppg.benelux|nex|city.of.surrey.bc|marsh.uk|moody.bible.institute|dunbia.group|standard.life|cais.group|state.of.michigan|rac|myriad.genetics|atco.group|viterra|investcorp.international.holdings|federal.reserve.bank.of.san.francisco|national.cancer.institute.center.for.biomedical.informatics.information.technology.nci.cbiit.|proquire.llc|groupon|yum.brands.uk|uwv|ministry.of.business.innovation.employment|rush.university.medical.center|federal.home.loan.bank.boston|vivat.verzekeringen|pfizer.uk|queensland.airports|nsw.office.of.environment.heritage|incomm.holdings.inc.|baker.hughes|gea|workplace.safety.and.insurance.board.wsib.|first.horizon.national|primary.health.care|vocus.pty.ltd|oaktree.capital.management|informatica.trentino|reynolds.consumer.products|bechtle.ag|smithsonian.tropical.research.institute|viasat|teacher.retirement.system.of.texas|ao.world|nsw.dept.trade.investment|ncc.sweden.ab|asx|tyler.technologies.inc.|state.of.california.calpers|broadridge.financial|american.income.life.insurance.company|munich.re.general.services.ltd|nomura|dkv.mobility.services.group|warwickshire.county.council|sncf|purdue.university|discovery.communications|mcwe|methodist.le.bonheur|great.western.bancorporation|21st.mortgage|costco.wholesale.australia.pty.ltd|reward.distrubution|ashland|the.carlyle.group|owens.corning|timken.company|euroclear.plc|blackhawk.network|rexam|john.deere.company|bcbs.of.kansas.city|lumentum|merlin.entertainments.group.limited|vulcan.materials|mercer|wonga|caltex.australia|vale.australia|toll.global|kws.saat.ag|honda.australia|oregon.health.science.university|the.cheesecake.factory|myer.pty.ltd|money.services.inc.|amn.healthcare|alere.uk|sheffield.city.council|umpqua.holdings|belkin.international|technip.france|tmx.finance|asos.com.limited|bashas.|beam.suntory|four.seasons.hotels|mckesson.uk|foresters|national.institute.for.health.research.nihr|n.brown.group|australian.taxation.office|cubic.corporation|department.of.communities.child.safety.and.disability.services|bpay|universal.music.investments.inc.|david.jones.pty.limited|u.s.office.of.personnel.management|atlas.copco.ab|binckbank.n.v.|vizient.inc.|sodexo.sa|bonneville.power.administration|time.inc.uk.ltd|finisar|gold.corporation.the.perth.mint|envia.mitteldeutsche.energie.ag|verisign|j.jill|american.campus.communities|university.of.rochester.medical.center|netsuite|city.national.bank|baptist.health.south.florida|columbia.sportswear|snyder.s.lance.inc|pret.a.manger.europe.limited|electricity.supply.board|stewart.title|deloitte.digital|old.dominion.freight.line|americold|university.of.kansas.medical.center|axalta.coating.systems|triodos|houston.methodist|armstrong.world.industries|cambridge.university.hospitals.nhs|concur.technologies.inc.|objekt.kontor.is.gmbh.co.kg|morphotrust|debenhams|rs.components|gkn|greencore.group.plc|greene.king|halfords|house.of.fraser|imi|the.body.shop|britvic|cardinal.glass.industries|heartland.co.op|markel.international|specsavers.australia|ocado.group|pz.cussons|rolls.royce.plc.|sig|sony.europe|tate.lyle|whsmith|think.finance.inc.|nxp.semiconductors.usa|synlab|santen.inc|skf.ab|qualifacts.systems.inc|sixt.leasing.se|bank.of.canada|new.look|ict.department.of.finance.services.and.innovation|w.s.badcock|corelogic|sears.canada|iap.worldwide|cegedim|bcd.travel|national.beef.packing.company|circle.k|american.eagle.outfitters.inc.|bi.mart|erie.insurance.group.main.|penn.national.gaming|tal.insurance|state.of.florida.department.of.children.and.families|west.midlands.police|mcdonalds.australia|crh.netherlands|komatsu.america|workcover.queensland|abb.optical.group|cybg.plc|zenith.bank.uk|samsonite|arag|point.and.pay|ipsen|united.supermarkets.llc|mmm.healthcare.llc|department.of.environment.land.water.planning|honorhealth.scottsdale.lincoln.healthcare|gander.mountain|saint.gobain.corporation|emco.chemical.distributors|national.healthcare|jackson.health.system|atria.senior.living.group|cambridgeshire.county.council|billabong|serta.simmons.bedding|cadence.bank|gm.financial|economical.mutual.insurance.company|regis.corporation|allianz.insurance|invacare.corporation|dentsply.international|syneos.health|oerag.rechtsversicherung|bon.ton.stores|yesco|portland.general.electric|dart.container.solo|trident.seafoods.corporation|specsavers.optical.group.limited|sorenson.communications|icf.international|rayonier|burlington.coat.factory.main.account.page.|kettering.health.network|metro.bank.plc|meridian.credit.union.limited|willis.towers.watson|symetra.financial|becu|vornado.realty.trust|first.hawaiian.bank|glacier.bancorp|university.hospitals|cole.taylor.bank|columbia.bank|idb.bank|darigold|things.remembered|edwards.lifesciences.corporation|pep.boys|us.steel|weis.markets|cefcu|electronic.merchant.systems|ugi.utilities|alaska.usa.federal.credit.union|dominion.resources.main.|quirch.foods|sears.home.and.outlet|rc.willey|presence.health|novo.nordisk.americas|spin.master|close.brothers|washington.federal.bank|american.greetings|oxford.industries|rwe.npower|fender.musical.instruments|frankenmuth.mutual.insurance.company|mary.kay.inc.|golden.living|life.care.centers.of.america|marriott.international.inc.|grandvision.retail.holding|ardent.health.services|pacific.seafood|dycom.industries|american.savings.bank.f.s.b.|intersil.corporation|apotex.inc|officeworks.ltd|st.luke.s|asante.health.system|forever.living.products|summa.health.system|hawaii.pacific.health|sydney.trains|capital.bluecross|america.first.credit.union|citi.trends|memorial.health.system.memorial.medical.center.|reser.s.fine.foods|pure.storage|maverik|queen.s.medical.center|libbey.glass|aristocrat.technologies|stephens.media|state.of.california.california.department.of.public.health|american.crystal.sugar.company|kinney.drugs|u.s.census.bureau|equitable.life.of.canada|c.j.clarks|e.on.uk|cott.corporation|police.nurses.limited|cetera.financial.group|chiquita.brands|third.federal.savings|louisiana.state.university|primerica|high.liner.foods.incorporated|renown.health|bureau.of.land.management|sierra.nevada.corporation|edf.energy|flex.n.gate|beaumont.health.system|northwestern.medical.faculty.foundation|osf.healthcare.system|presbyterian.healthcare.services|aimia.inc|aig.emea|boardriders.formerly.quiksilver.|discount.drug.mart|glencore.australia.pty.ltd|griffith.foods.griffith.laboratories.|allied.world.assurance.company.holdings.uk|hudson.group|millercoors|palmer.harvey|tailored.brands|bank.of.canada|cadillac.fairview.corporation.limited.the|franciscan.alliance|.407.etr.canadian.tolling.company.international.inc|nyu.langone.hospitals|baycare.health.system|portfolio.recovery.associates|university.of.nevada.reno|herman.miller|university.of.british.columbia|fidelity.worldwide.investment|medical.mutual.of.ohio|genesco|baker.tilly|six.flags.entertainment.corporation|key.food|international.paper|amwins.group|ehealth.ontario|red.cross|bcbs.of.sc|co.operative.bank|co.op.insurance|mizuho.international.uk.|esterline.technologies|zebra.technologies.corporation|rex.healthcare|london.stock.exchange|wellstar.health.system|arctic.slope.regional.corporation|acadia.healthcare|piper.jaffray|university.of.nevada.las.vegas|harbor.freight.tools|sage.north.america|garantibank.international.n.v.|city.of.sydney|united.suppliers|leidos|co.operators.group.limited.the|anadarko.petroleum.corporation|energy.transfer.partners.l.p.|delta.faucet|domtar.corporation|news.corporation|nestle.holdings.inc.|thor.industries.inc.|cracker.barrel.old.country.store.inc.|frito.lay.inc.|electrolux.north.america.inc.|honeywell.inc.|jbs.usa.food.company|huntington.ingalls.industries.inc.|superior.plus.corp|sally.beauty.holdings.inc.|securitas.holdings.inc.|berry.plastics.group|usg.corporation|university.of.maryland.medical.system.corporation|irving.oil.limited|new.york.power.authority|smithfield.foods.inc.|freeport.mcmoran.corporation|potash.corporation.of.saskatchewan.inc|la.coop.federee|regal.entertainment.group|alliancebernstein.l.p.|everest.reinsurance.holdings.inc.|systemax.inc.|nexeo.solutions.llc|investors.group.financial.services.inc|tokio.marine.holdings|family.dollar.stores.of.louisiana.inc.|general.dynamics.government.systems.corporation|agropur.cooperative|queb.cor.inc|precision.castparts.corp.|state.university.of.new.york|olive.view.medical.center|hanesbrands|kinder.morgan.energy.partners.l.p.|visteon.corporation|tyson.foods.inc.|temple.university|enterprise.products.partners.l.p.|ryder.system.inc.|biomet.inc.|energizer.holdings.inc.|fossil|polyone.corporation|steelcase.inc.|eastman.chemical.company|american.national.insurance.company.inc|city.of.boston.department.of.neighborhood.development|transocean.inc.|scansource|curtiss.wright.corporation|graphic.packaging.holding.company|unified.grocers.inc.|packaging.corporation.of.america|coca.cola.european.partners.master|essentia.health|atrium.health|florida.power.light.company.inc|public.service.enterprise.group.incorporated|indiana.university.health.inc.|utc.aeorspace|technipfmc|otis.elevator.international.inc.|altria|ingredion.incorporated|campbell.soup.company|radioshack.corporation|nrg.energy.inc.|j.b.hunt.transport.services.inc.|airgas.inc.|clark.county.school.district|collective.brands.inc.|crown.castle.international.corp.|mercury.general.insurance|norfolk.southern.corporation|sealed.air.corporation|west.corporation|cornell.university|valmont.industries|lennar|nabors.industries.inc.|nine.west.holdings.inc.|coty.inc|adt|westrock|regal.beloit.corporation|cf.industries.holdings.inc.|bemis.company|lions.gate.entertainment.inc.|plains.all.american.pipeline.l.p.|wakemed|old.mutual|eog.resources.inc.|the.ohio.state.university|maple.leaf.foods.inc|mcdermott.international.inc.|kpmg.llp|schwan.food.company|mccormick.company.incorporated|newmont.mining.corporation|allina.health|sonoco.products.company|towers.watson.co|calpine.corporation|calumet.specialty.products.partners.lp|topco.associates.llc|hawaiian.electric.industries.inc.|roundy.s.supermarkets.inc.|arris.group|tennessee.valley.authority|the.scotts.miracle.gro.company|exide.technologies|bath.body.works.llc|sonic.automotive.inc.|soci.t.des.loteries.du.qu.bec|british.columbia.lottery.corporation.bclc|bwx.technologies.inc.|cinemark.usa.inc.dupe.|jll.jones.lang.lasalle.|american.electric.power.company.inc.|benchmark.electronics.inc.|home.hardware.stores.limited|california.state.university.system|rush.enterprises.inc.|hub.group.inc.|wawanesa.mutual.insurance.company.the|ryerson.inc.|sunpower.corporation|select.medical.corporation|lennox.international.inc.|dean.foods.company|basf.corporation|blackberry.limited|toromont.industries.ltd|heartland.dental.care|kum.go|federated.mutual.insurance|aids.healthcare.foundation|bluegreen|northshore.university.health.system|inova.health.system|abington.memorial.hospital|charlotte.russe|newegg.inc.|concentra|new.mountain.capital|health.first|akron.children.s.hospital|edelman|ingram.industries|the.ensign.group|mcafee|winthrop.university.hospital|syniverse|westchester.medical.center|vizio|rank.group.plc|rollins|fruit.of.the.loom|worldpac|foremost.farms.usa|gate.petroleum|albany.medical.center|amerisure.mutual.insurance|meadowbrook.insurance.group|national.vision|north.memorial.health|mizuho|noridian.mutual.insurance.company|california.pizza.kitchen|yale.new.haven.health.system|intergraph.corporation.hexagon.|hennepin.healthcare.system|the.geo.group|cobank|forsythe.technology|thomas.jefferson.university.hospital|cliftonlarsonallen|department.of.state|biomarin.pharmaceutical|yankee.candle.company|frost.bank|temple.university.health.system|do.it.best|cato.corporation|american.enterprise|children.s.hospitals.and.clinics.of.minnesota|thedacare|pacsun|advancepierre.foods|vibra.healthcare.llc|marshfield.clinic|g.iii.apparel.group.ltd.|calamos.investments.llc|school.specialty|convergys|rpc|popular|hospital.sisters.health.system|office.of.management.and.budget|bankunited|crocs|synaptics|fbr.capital.markets|impax.laboratories|greenstone.farm.credit.services|transdev|ezibuy.nz.omni|valuation.office.agency|sunopta.inc|bdo|viva.energy.australia.ltd|united.states.geological.survey|virgin.mobile.australia|colorado.state.university|digital.river|berkadia|algonquin.power|nhs.england|multicare.health.system|henderson.global.investors|city.of.minneapolis.mn|state.of.vermont.agency.of.human.services|national.stores|avmed.health|sita.inc.usa|puma.ag|veterans.health.administration|scottish.widows.group|infosys|synovus.financial|sabre.glbl.inc.|fujitsu.technology.solutions.gmbh|software.ag|amdocs.incorporated|thomson.uk|cbs.interactive|altice.usa|toro.company|shaw.industries|bgl.group.ltd.|carnegie.mellon.university|city.of.philadelphia|johns.hopkins.university.applied.physics.laborator|magellan.midstream.partners|northrop.grumman.md|alliant.energy|nbc.universal|pearson|ihg|european.parliament|jewelry.television|darden.restaurants|maximus|cantor.fitzgerald.co.|united.guaranty.corporation|u.s.securities.and.exchange.commission.sec.|toronto.hydro.electric.system|travelex.holdings.limited|bull.sas|nbty|harvard.pilgrim.health.care|new.york.presbyterian.healthcare.systems|premier.healthcare.alliance|club.mediterranee|cgi.it.uk.limited|national.bank.of.canada|the.aa|affiliated.foods.midwest.cooperative|scripps.health|phoenix.group|southwest.gas.corporation|leiden.university.medical.center|aaron.s|federal.reserve.bank.of.st.louis|gie.gld.services.groupe.le.duff.|bank.of.the.west|daiwa.capital.markets.europe|erac|admiral.insurance|arch.insurance.subsidiary.|inghams.limited|h.d.smith.llc|kkh.kaufm.nnische.krankenkasse|brown.jordan.international|tata.consulting.services.netherlands.bv|skipton.building.society|nato|engie.na|the.container.store|murex|elekta.ltd.|gareth.morgan.investments|waikato.district.health.board|brocacef|equinix|us.xpress|acn|travelers|department.of.premier.and.cabinet.tasmania|ares.management|pechanga.resort.casino|toronto.district.school.board|la.poste|veritiv|ministerie.van.veiligheid.en.justitie|ageas.insurance.limited|insurance.corporation.of.british.columbia|new.york.community.bancorp|athene.holding|onesavings.bank|city.of.mesa|london.health.sciences|lsc.communications|dawn.meats|westjet.an.alberta.partnership|trimble.navigation|sykes.assistance.services.corporation|pepsico.australia.new.zealand|utica.mutual.insurance.company|lch.clearnet|affiliated.managers.group|vereit|tetrapak.ab|general.dynamics.mission.systems|allied.wallet|telus.communications.inc.|cmc.markets.uk.plc|martinrea.international|fgl.sports|ingenico.epayments|paymark.limited|funnelwise|maricopa.county.az|clarks|australian.pharmaceutical.industries|department.of.public.expenditure.and.reform|axicorp.financial.services.pty.ltd.|vision.super|esure.group|australia.post|univision.communications.inc.|ezcorp|bob.evans|air.products.and.chemicals.inc.main.|cincinnati.children.s.medical.center|esri.deutschland.group|tory.burch|northside.hospital|academy.sports.outdoors|farm.credit.services.of.mid.america|pon.holdings|pc.connection.main.account.page.|g4s|hoag.hospital|lvmh.moet.hennessy.louis.vuitton.inc.|dick.smith.holdings.limited|adyen|viejas.tribal.council|cae.inc|associated.food.stores|public.storage|university.of.chicago.medical.center|king.county|wake.forest.healthcare.ventures|martin.marietta.materials|homebase|hemlock.semiconductor.group|shop.direct.group|academy.mortgage|state.revenue.office.victoria|american.apparel|j.nk.pings.l.ns.landsting|baylor.scott.white|sixt|sheetz.inc.|schuh|russell.investments|oneamerica.financial.dupe.|ocwen.financial.corporation|l.oreal.usa|state.of.kansas|mine.super|bird.construction.company|madison.square.garden|maxim.healthcare.services.main.account.page.|maritime.super|optiver.australia|union|credit.suisse.holdings.australia.|firstmac|qic|aeropostale|indivior|mediolanum.asset.management.ireland|department.of.housing.and.public.works.queensland.|the.related.companies|nuffield.health|cotton.on.group.services.pty.ltd|the.honest.company.inc.|renasant.bank|alorica|j.d.irving.limited|beth.israel.deaconess.medical.center.caregroup.|tesoro.corporation|arup.laboratories.inc|skechers|invista.inc.|cancer.care.ontario|executive.office.of.the.president|oceanx.llc|oxford.university.hospitals.nhs.trust|ak.steel.holding|omnicell|axa.ppp|orica.ltd|adventist.health|cara.operations.limited|enercare.inc.|midfirst.bank|surge.energy|linde.group|lawrence.livermore.national.laboratory|william.hill.australia|j.crew|office.of.the.us.attorneys|eaton.vance|allscripts.healthcare.solutions|aaa.national|flir.systems|equitable.bank|lcmc.health|wiley|varian.medical.systems.inc.|university.of.utah.hospitals.clinics|tops.markets|boyd.gaming|wabco.north.america|genesis.healthcare.corporation|big.y.foods|torstar.corporation|del.monte.foods|99.cents.only.stores|australian.trade.and.investment.commission|nfu.mutual|avis.budget.group|dfc.global.corp.|xilinx.uk.i|port.authority.of.new.york.new.jersey|federal.deposit.insurance.corporation|seattle.children.s.hospital|matrix.medical.network|big.5.sporting.goods|catholic.medical.center|mammoet|psba|commission.junction.inc.|wolseley.canada|kinecta.federal.credit.union|cbre.uk|bank.of.internet.usa|panera.bread|trelleborg|bank.of.scotland.germany|martini.ziekenhuis|ohiohealth|raley.s|department.of.defense.defense.contract.management.agency|capital.and.coast.district.health.board|dave.buster.s|lgia.super|stater.bros.markets|coca.cola.north.america|confluence.health|financial.conduct.authority|teleflex.incorporated|scandic.hotels|kla.tencor.corporation|hsbc.canada|epic.technologies.llc|atlas.copco|worksafebc|illumina.inc.|tesco.bank|euronet.worldwide|black.knight.financial.services|city.of.mississauga.on|axa.equitable.main.|sonepar.pacific|bc.ferries|the.associated.press|aes.corporation|netgear|toronto.blue.jays|mosaic.company|eddie.bauer|wescom.credit.union|polycom|unitedhealth.group.uki|mitsubishi.motors.north.america.inc.|bon.secours.health.system|inter.american.development.bank|aleris.international|sprouts.farmers.market|je.dunn.construction|virginia.mason.medical.center|city.of.phoenix|pension.insurance.corporation|wellspan.health|nationstar.mortgage|cpb.contractors|camso.inc|bcbs.of.nc|burger.king|rack.room.shoes|veterans.united.home.loans|toronto.police.department|people.s.united.bank|heathrow.airport|teleperformance.usa|british.columbia.automobile.association|parsons|landry.s.restaurants|vcu.health.system.subsidiary.|lifespan.corporation|charles.river.laboratories.international|tetra.tech.inc.|cape.cod.healthcare|gmo|bmo.capital.markets|assured.guaranty.municipal.corp.|event.hospitality.entertainment.limited|seqirus.uk.ltd.accounts.payable|national.fuel|the.restaurant.group.plc|everi.holdings.inc.|conmed|world.vision.international|new.era.cap|vanderlande.industries.inc.|adventist.health.system|first.quality.enterprises.inc|unisys|sterling.national.bank|the.university.of.utah|princeton.university|shamrock.foods.company|norampac|tictoc.online.pty.ltd|saputo.inc.|caisse.de.depot.et.placement.du.quebec|dept.of.commerce.wa.|ann.inc.|avista.corporation|city.of.hope|radnet|wilbur.ellis.company|arby.s.restaurant.group|zimmer.biomet|.cfsgam.colonial.first.state.global.asset.management|american.axle.manufacturing|neustar|bj.s.restaurants|u.haul|hubert.burda.media.holding|encore.capital.group|sapient|trustmark.national.bank|regional.municipality.of.peel.the|manorcare|teachers.health.fund|primelending|qbe.europe|british.columbia.hydro.powerex|digital.state|salt.lake.county|batory.foods|rolls.royce.controls.data.services|cox.automotive.australia|lookers|kantar.group.uk.|prime.healthcare|aci.worldwide.inc.|virginia.commonwealth.university|price.chopper|university.of.west.georgia|farmers.merchants.bank.of.long.beach|university.of.pennsylvania.health.system|schnucks.markets.dupe.|fred.s.inc|scan.health.plan|landis.gyr|barnabas.health|scoular|investors.bank|scotia.gas.networks.ltd|friedkin|pinnacle.agriculture.holdings|depository.trust.clearing.corporation|ria.financial.services|urs.corporation|cws.boco.deutschland.gmbh|bureau.of.alcohol.tobacco.firearms.explosives|department.of.energy.oak.ridge.national.lab|marathon.oil|lyft.inc.|dolby.laboratories|aldo|leaseplan.uk.ltd.|coast.capital.savings.credit.union|mallinckrodt.pharmaceuticals|chg.healthcare.services|sonos.inc.|edison.international|state.of.new.york|west.pharmaceutical.services|wpp.group|spartan.motors.inc.|guess.inc.|prologis|foodstuffs.north.island.limited|tom.james.company|vattenfall|covance|open.text.corporation|amsurg|marvell.technology.group.ltd|dupe.john.muir.health|ipay.jack.henry.associates|australian.financial.security.authority.afsa.|endemol.shine.group|invesco.perpetual|federated.co.operatives.limited|siteone|desjardins|axis.capital.holdings|urban.outfitters.uk|roche.uk|fitbit|first.reserve|air.canada|surrey.county.council|provident.financial.group|state.of.florida.department.of.corrections|michelin|poundland|extended.stay|cook.children.s.health.care.system|australian.government.department.of.health|nz.home.loans|department.of.the.treasury.comptroller.of.the.currency|cree.inc|pladis.global|methodist.health.system.of.dallas|james.cook.university|fortive.corporation|tata.steel.netherlands|iqor|hamburg.sud|qgcio|servisfirst.bank|green.shield.canada|astrazeneca|weill.cornell.medical|darling.ingredients|motorit.ab|cadence.design.systems|chanel.uk|amedisys|trelleborg.germany|boart.longyear.limited|lhp.hospital.group|oneweb|urban.outfitters|frontier.agriculture.ltd|rockland.trust|dyno.nobel|liberty.university.inc.|d.h|uniprix|b.e.aerospace|london.metropolitan.police|lvnl|act.health|harvey.norman.holdings.ltd|cdk.global|go.compare|bendigo.and.adelaide.bank|selecthealth|spotlight.retail.group|mercedes.benz.financial.services.uk|insperity.inc|graincorp.ltd|stony.brook.medicine|jeppesen|acosta.sales.marketing|just.energy|bevmo.|caldic|loyola.university.health.system|the.game.group|department.for.culture.media.sport|munich.reinsurance.america|polyconcept.north.america|york.risk.services.group|fidelity.guaranty.life|dannon|raymour.flanigan|bumble.bee.foods|fullbeauty.brands.inc.|modell.s.sporting.goods|spencer.gifts|holman.enterprises|ambac.financial.group|kaleida.health|essent.guaranty|prosight.specialty.insurance|mid.north.coast.local.health.district|agilent.technologies|eli.lilly.and.company|murrumbidgee.local.health.district|state.of.new.mexico|nen|vsp|benjamin.moore.co.|thames.water|federated.investors|resmed.uk.ltd|first.commonwealth.financial|virgin.money|pages.jaunes|academisch.medisch.centrum.amc.|british.airways|british.broadcasting.corporation|essent.energy|hutchison.3g.uk.limited|klm.royal.dutch.airlines|mars|first.investors.corporation.foresters.|nsw.telco.authority|catalent.pharma.solutions|onewest.bank|sunrider.international|s.t.bank|baptist.healthcare.system.ky.|state.of.ohio.ohio.department.of.rehabilitation.and.correction|pricesmart|atlas.holdings|usga.main.|market.axess|main.line.health|symbion.australia|ansys|keysight.technologies|state.of.ohio.ohio.department.of.transportation|total.quality.logistics|smart.and.final|jazz.pharmaceuticals|ttm.technologies|isban.de.santander.group|berlin.packaging|bass.pro.shops|freedom.mortgage|monster.energy.company|federal.home.loan.bank.of.atlanta|bcbg.max.azria.group|east.west.bank|tti|orchard.supply.hardware|daiichi.sankyo|hilmar.cheese|baiada.group|gogo|arista.networks|peet.s.coffee.tea|stage.stores|mouser.electronics|blue.diamond.growers|sunkist.growers|rbc.capital.markets.london|chemed.corporation|panda.restaurant.group|the.brock.group|jacksonville.electric.authority|city.of.portland|lonza|kwik.trip|mvp.health.care|volvo.trucks.north.america|tmg.health|diamond.foods|solar.turbines|callcredit.information.group|mednax|gain.capital.inc.|arcadia.group|state.compensation.insurance.fund|management.training.corporation|tbc|morton.salt|art.van.furniture|coventry.building.society|tyco.integrated.security|advent.international.corporation|interstate.batteries|state.of.california.california.employment.development.department|the.open.university|uc.davis.health.system|zachry.holdings|independent.health|tomorrow.focus.ag|bombardier.transportation.gmbh|physicians.mutual.insurance|bmw.financial.services|mfs.investment.management|mesirow.financial|hesta.super.fund|empire.southwest|bcbs.of.la|intuitive.surgical|camping.world.inc.|weatherford.international|emigrant.bank|teledyne.technologies|wps.health.insurance|evercore.partners|stater.nv|nebraska.furniture.mart|michels.corporation|ventura.foods|alex.lee|probuild|ritchie.bros.auctioneers.incorporated|american.securities|c.r.england|sftf.interflora|norton.healthcare|fry.s.electronics|the.range|energysolutions|p.f.chang.s.china.bistro|jockey.international|citizens.property.insurance.corporation|national.life.group|mercy|lch.clearnet.old.|lts.solutions.ltd|green.dot.corporation|tnt|george.mason.university|new.penn.financial|orlando.health|sparrow.health.system|hitachi.capital|royal.london.group|rescare|firstbank.holding.company|mckinsey.company.inc.|boscov.s.department.stores|allison.transmission|provident.financial.services|bofi.federal.bank|american.hotel.register|globalfoundries|waddell.reed.financial|priority.health|northwestern.university|city.of.san.diego.ca|american.furniture.warehouse|bessemer.trust|yorkshire.building.society|frontier.airlines|rady.children.s.hospital|big.d.construction|edward.don.company|washington.gas|carhartt|jupiter.asset.management|hid.global|lehigh.valley.health.network.inc.|crif.lending.solutions|post.office|carestream.health|first.financial.bank|jack.in.the.box|checkers.drive.in.restaurants|sisters.of.charity.of.leavenworth.health.system|pacific.western.bank|bba.aviation.usa|city.of.oakland.ca|the.metrohealth.system|tarmac|university.of.iowa.health.care|occ.options.clearing.corporation.|chemical.bank.and.trust.company|farm.credit.services.of.america|janus.capital.group.inc.|privatebancorp.inc.|alsco|first.merchants.corporation|groupe.jean.coutu.pjc.inc.le|wsfs.bank|scheels.all.sports|pgg.wrightson|bcbs.of.mn|ohio.national.financial.services.inc.|atlantic.health.system|manhattan.associates|city.of.austin.tx|state.of.wisconsin|inland.empire.health.plan|park.national.bank|alfa.insurance|security.finance.corporation|valley.national.bancorp|fleetcor.technologies|super.a.mart.holdings.pty.ltd|black.box.corporation|brown.brown.insurance|mothercare|victory.capital|wickes|cim.group|one.call.care.management|wilson.sporting.goods|orange.lake.country.club.inc|a.t.u.auto.teile.unger|kenneth.cole.productions|delta.dental.of.wisconsin|virginia.tech|iowa.state.university|cma.systems|banque.laurentienne.du.canada|hni.corporation|nationale.nederlanden|ladbrokes|axel.springer.ag|wesbanco|northwest.federal.credit.union|simon.fraser.university|federal.home.loan.bank.of.new.york|cohen.steers|kratos.defense.security.solutions|beacon.health.system|new.horizons.computer.learning.centers|maimonides.medical.center|direct.general|rochester.regional.health|jimmy.john.s|medpro.group|national.penn|eagle.bancorp.inc.|veronis.suhler.associates|visiting.nurse.service.of.ny|carnival.uk|brother.international.corporation",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",28],
      "arg1":"city.of.dallas|credit.europe.bank|cec.entertainment|schroders.plc|hager.electro.gmbh.co.kg|queensland.department.of.justice.attorney.general|panasonic.avionics.corporation|data.3|m.lnlycke.health.care|janney.montgomery.scott.llc|puget.energy.inc.|lutron.electronics.co.inc.|mellanox.technologies|sanmina.sci.systems.canada.inc|premier.tech.lt.e|methanex.corporation|fraser.health.authority|wilton.brands.inc.|titan.machinery.inc.|rdo.equipment.co.|optionsxpress.holdings.inc.|bremer.financial.corporation|jerry.s.enterprises.inc.|lund.food.holdings.inc.|osi.group|trw.automotive.holdings.corp.|mnp.llp|tolko.industries.ltd.|canadian.nuclear.laboratories.ltd.|university.of.victoria|manitoba.agricultural.services.corporation|ws.packaging.group.inc.|certco|pomp.s.tire.service|hydrite.chemical.co.|piggly.wiggly.midwest.llc|gtcr.golder.rauner.l.l.c.|gardaworld|astellas.pharma.us.inc.|kapstone.paper.and.packaging.corporation|heartland.financial.usa.inc.|inteva.products|ftd.companies.inc.|akorn.inc.|beam.inc.suntory.japan.is.parent.|modine.manufacturing.company.inc|national.energy.board|aldo.group.inc.|rexel.am.rique.du.nord.inc|dvb.bank|chamberlain.group.inc.|cooper.tire.rubber|great.lakes.cheese.company.inc.|rosen.s.diversified|api.group|donaldson.company.inc.|standard.textile.co.inc.|wasserstrom.company|mclaren.health.care|water.street.healthcare.partners.llc|taylor.wimpey.plc|zs.associates|steel.dynamics.inc.|nisource.inc.|deutsche.kreditbank.ag.dkb.|sierra.wireless.inc.|winnipeg.regional.health.authority|ansell.limited|sasktel|isala.ziekenhuis|honda.of.america.mfg.inc.|dealer.tire.llc|healthpartners|compass.group.canada.ltd|contrans.corp|old.national.bancorp.|olympic.steel.inc.|bendix.commercial.vehicle.systems.llc|davey.tree.expert.company|american.mortgage.service.company|bluestem.brands|cedar.fair.l.p.|sapp.bros|community.choice.financial.inc.|kehe.distributors.llc|hydro.ottawa.limited|buckle.inc.|manitowoc.company|skyline.corporation|coborn.s.inc.|select.comfort.corporation|starkey.hearing.technologies.starkey.laboratories.inc.|emera.incorporated|true.value.company|world.kitchen.llc|horace.mann.educators.corporation|quill.corporation|aecon|citywide.home.loans|varex.imaging.corporation|vectren.corporation|finish.line.inc.|eby.brown|johnson.bank|staples.canada|constellation.software.inc|masonite.international.corporation|fairmont.raffles.hotels.international|greater.toronto.airports.authority|omnisource.corporation|volksbank.mittelhessen.eg|canadian.standards.association|andersons.inc.|littelfuse.inc.|equity.lifestyle.properties|midland.paper.company|trillium.health.partners|la.capitale.assureur.de.l.administration.publique.inc|hendrickson.usa|direct.supply|transport.accident.commission|poet.llc|phoenix.contact|stonegate.pub.co.ltd.|erste.abwicklungsanstalt|s.oliver.bernd.freier.gmbh.co.kg|marc.o.polo.ag|the.bank.of.east.asia|cma.cgm|john.clark.holdings.ltd.|systeme.u.centrale.nationale|deichmann.se|arvato.digital.services.llc|bpifrance|praktikertj.nst.ab|legacy.texas.bank|rensa.groep.b.v.|paul.hartmann.ag|great.west.life.co|scalzo.foods|progrexion|global.brands.group|extron.electronics|steadfast.companies|county.of.santa.barbara.ca|amex.gbt|intertek.group.plc|merrick.bank.corporation|pcl.construction.enterprises.inc.|famous.brands.international|craftworks.restaurants.breweries.inc.|1.800.flowers.com.inc.|washington.department.of.transportation|nhs.digital|helm.ag|kfw.group|flow.traders.nv|la.maison.simons|apoteket.ab|villeroy.boch|compugroup.medical.se|gerry.weber.international.ag|rehau.ag.co|pension.insurance.corporation.group.ltd.|city.of.fort.collins|master.empower.retirement.root.|xl.catlin|ceva.sante.animale|stearns.lending|l.a.fitness.international.llc|quest.software|gerdau.ameristeel.us.inc|eurobaustoff.handelsgesellschaft.mbh.co.kg|larry.h.miller.group|monster.beverage.corporation|kemper.corporation|pimco.sub.of.allianz.operates.independently.|keck.hospital.of.usc|united.internet.ag|aurora.capital.group|cedars.sinai.medical.center|primary.residential.mortgage|merit.medical.systems|nicholas.company|colorado.pera.state|leidos|flexigroup.limited|m.g|merz.usa|reliance.steel.aluminum|xerox.uk|carter.s|hmv|apria.healthcare.group|skatteverket|vidant.health|choctaw.nation.of.oklahoma|southside.bank|accident.fund.ins.|lagardere.travel|the.kraft.heinz.company.chicago.hq.|telent.technology.services.ltd|tt.electronics.plc|chassix|city.of.greater.geelong|j.d.williams|fonds.de.solidarit.du.ftq|regie.autonome.des.transports.parisiens|deckers.brands.emea|olympus.europa.se.co.kg|valeo|iag.new.zealand|the.good.guys|fis.uk|northern.sydney.local.health.district|mec.global.uk.|blue.care|brightstar|mutual.of.omaha.bank|balfour.beatty.europe|coke.one.north.america|vivint|atb.financial|msci|british.sugar|u.s.patent.and.trademark.office|grafton.group|air.force|brault.martineau|schibsted.enterprise.technology.ab|loyaltyone.co.|delta.dental.of.minnesota|altisource|medical.university.of.south.carolina|dentons|kik.custom.products.inc.|cabot.financial.limited|united.cooperative|first.citizens.bank|brinker.international.inc.|william.hill.plc|agf.management.limited|central.coast.local.health.district|athenahealth.inc.|transport.for.london|chicago.bridge.iron.company|bny.mellon.europe|lenovo.holding.company.inc.|sallie.mae|metal.management.inc.|postnord|illawarra.shoalhaven.local.health.district|lv.general.insurance.group|metlife|simplot.australia.pty.ltd|nintendo.of.america|blue.cross.and.blue.shield.of.massachusetts.inc.main.account.page.|rei|drybar.holdings.llc|ngl.energy.partners.lp|petsmart.inc.|eneco|university.of.connecticut|lansforsakringar.publ.ab|kruger.inc.|tchibo.gmbh|euromoney.institutional.investor.plc|nsw.department.of.premier.and.cabinet.dpc.|nt.department.of.health|new.american.funding|compass.group.uk|charles.taylor.plc|tower.hamlets.council|patrick.industries|state.of.idaho|cognizant.technology.solutions.u.s.corporation|paramount.pictures|ardagh.group.north.america|the.north.west.company|fair.work.ombudsman|rsm.uk|department.of.education.tasmania|abm|cit.group|columbia.university.medical.center|f5.networks|pan.american.life.insurance.group.inc.|state.of.north.dakota|williams.companies.inc.|city.of.winnipeg.the|opko.health|deckers.outdoor.corporation|cushman.wakefield|rochester.public.utilities|city.of.ballarat|royal.canadian.mounted.police|graybar.electric.company|melbourne.health|db.schenker.inc.|kci.usa.inc.|ig.index.plc|gsk.australia|sandvik|freshdirect.llc|polisen.rps.|station.casinos|the.dun.bradstreet.corporation|nihon.kohden.america|boston.medical.center|first.command.financial.services|health.partners.plans|henry.schein.nl|shoe.show|hightower.advisors.llc|interface|allied.electronics|qantas.airways.limited|camelot.group.limited|chesapeake.energy|ultimate.software|vicsuper|realty.income|warburtons|department.of.commerce.national.institute.of.standards.and.technology|commonwealth.of.massachusetts|carrier.enterprise|mn|b.m.retail|health.canada|state.of.texas.texas.higher.education.coordinating.board|tokio.marine.kiln|rbs.invoice.finance|mtd.products|el.camino.hospital|brisbane.city.council|infosys.australia|kbr|jewson.limited|world.wide.technology|rackspace.us.inc.|oncology.nursing.society|mindshare.uk.|aptean|lombard.odier.north.america|manitoba.liquor.and.lotteries.corporation|worldpay|caliber.home.loans.inc.|sodexo.sweden|global.exchange.services.opentext.|hungry.jacks|cbh.group|state.of.maine|officemax|southwire|beckman.coulter|miller.insurance|atradius|payments.canada|udg.healthcare|leeds.building.society|irs|sainsburys.bank|united.states.nuclear.regulatory.commission|alcoa.inc.|thunderbird.asu|mars.information.services.australia.|airservices.australia|state.of.ohio.ohio.department.of.job.and.family.services|nandos|hyland.software|healthscope|australian.unity.limited|arizona.department.of.child.safety|ochsner.health.system|community.healthcare.system|premier.farnell|bombardier.uk|perkinelmer|tuesday.morning|university.of.washington|espn.inc.|akademiska.sjukhuset|nepean.blue.mountials.local.health.district|rijkswaterstaat|copart.inc.|alstom.grid|blackbaud.inc|intertek|texas.mutual.insurance.company|hertz.nordic|deloitte.united.kingdom|j.m.smith.corporation|rentokil.initial.1927.plc|at.t.partner.solutions|novae.group|bear.river.associates|allegheny.health.network.hospital.provider.network.|assistrx|sammons.financial.group.member.companies|acco.brands|parkland.health.hospital.system|jordan.health.services|arts.council.england|wandsworth.council|zynga.inc.|california.dept.of.water.resources|city.of.henderson.nv|spotify|baystate.health|jlt.group|live.nation.entertainment|pggm|sunedison.inc.|vertiba|tcs.uk.end.customer|agero.inc|red.robin.gourmet.burgers|halliburton|videotron.g.p.|compass.group.australia|mitchells.butlers|ppd.inc.|calfrac.well.services.ltd|gemeente.rotterdam|flatiron.health|caci.inc.corp|ssp.worldwide.australia.|city.of.toronto|orange.county|ricoh.australia.pty.ltd|festo.ag.co.kg|adeo.services|moneysupermarket.com.group|aramice|eastman.credit.union|simply.energy|universal.forest.products|campbell.arnott.s|bidfood.australia|decmil.group.limited|nhs.digital|atlific.hotels|trumpf.gmbh.co.kg|new.flyer.industries.canada.ulc|bmw.financial.services.australia|h.j.heinz.company.australia.limited|ey.belgium|age.uk|kimberly.clark|nuon.vattenfall|great.west.financial|westlake.services.llc|a.gas.us.holdings.inc.|british.columbia.investment.management.corporation|summit.electric.supply.co.inc.|driscoll.s|brookstone|innovacare.health|100inc|adaptus.llc|western.region.water.corporation|ditech.financial.llc|workers.compensation.fund|department.of.justice.and.regulation.victoria.australia|harwoods|motorsport.aftermarket.group|ministerie.van.buitenlandse.zaken.foreign.affairs|heraeus|fiesta.restaurant.group|yelp|rentokil.us.headquarters|houlihan.lokey|origin.energy.retail.limited|telstra.super|transport.safety.victoria|coca.cola.european.enterprises.uk.|lend.lease|tupperware.brands.corporation|clark.county.nv|honeywell.aerospace|cuscal|nav.canada|the.university.of.wollongong|hostplus|downer.group|hitachi.consulting|viessmann.manufacturing.us|moneygram.international.inc|nbn.co|ausnet.services|specialty.fashion.group|vitality.corporate.services.ltd|fortress.investment.group|unicredit.dab.bank.ag|securian.financial.group|gymboree|one.america.financial.partners.inc|super.retail.group|oneok|rexel.holdings.australia|cottonwood.financial.administrative.services.llc|lennar|byl.companies|australia.radiation.protection.and.nuclear.safety.agency|formativ.health|general.datatech|abn.amro.clearing.bank.n.v.|pepper.group.limited|signature.healthcare.llc|brenntag.ag|oklahoma.department.of.public.safety|tullverket|metro.north.hospital.and.health.service|eversource.energy|gfk|kite.realty.group|fullbeauty.brands.an.apax.portfolio.company.|swissport.uk|denali.federal.credit.union|jeld.wen.australia.pty.limited|guy.s.and.st.thomas.nhs.foundation.trust|abb.group|henkel.ag.co.kgaa|south.east.sydney.local.health.district|peek.cloppenburg.kg.hamburg|sydney.local.health.district|wellmont.health.system|united.states.secret.service|promutuel.insurance|softcat.end.user.|canada.revenue.agency|statistics.canada|vhv.gruppe|zespri.group|millicom.international.services.llc|komatsu.australia.pty.ltd|zespri.international|home.hardware.stores.limited|cairns.and.hinterland.hospital.and.health.service|children.s.health.queensland.hospital.and.health.service|metro.south.hospital.health.service|gold.coast.hospital.and.health.service|danske.bank.uk|southwark.council|dm.drogerie.markt.gmbh.co.kg|townsville.hospital.health.service|scottsdale.healthcare.corp.|svenska.kyrkan|blacktown.city.council|western.nsw.local.health.district|aurora.energy.limited|marriott.ownership.resorts.inc.|newton.investment.management.ltd.|caremore|compass.group.fr|independer|bell.helicopter|vgm.group|main.roads.wa|rpra|extra.space.storage|bank.victoria|onebeacon.insurance.company|under.armour.inc.|vtb.capital.uk|simmons.bank|newday|dxc|california.state.university.monterey.bay|adyen.nederland|global.experience.specialists.inc|golden.gaming.llc|stonehage.fleming|shv.energy.n.v.|crawford.nz|hmcts|detailresult.groep|indosuez.wealth.management|viterra|tokio.marine.hcc|california.department.of.justice|royal.a.ware|hm.land.registry|cincinnati.insurance.company|first.national.bank.of.omaha|blue.cross.blue.shield.of.minnesota|government.of.northwest.territories|marsh.mclennan.companies.inc.|lanxess|phoenix.pharmahandel|unitymedia|beacon.health.options|blue.cross.blue.shield.of.massachusetts|chisholm.institute|nyu.langone.health|rail.delivery.group|us.lbm|selfridges|star.track.express.pty.limited|midland.states.bank|south32|hms.holdings.corp.|resmed|university.of.iowa|exin.financial.services.holding.b.v.|brainspace.corporation|university.of.newcastle|pet.supplies.plus|kingston.technology.company.inc.|city.of.long.beach|american.airlines.federal.credit.union.inc|aegon.uk|boston.consulting.group.main.account.page.|camaieu.international|celio.france|sammons.enterprises|city.of.edmonton.alberta|city.of.atlanta|city.of.houston.tx|aarp|kansas.city.life.insurance.company|state.of.ohio.ohio.department.of.mental.health.and.addiction.services|state.of.california.california.department.of.child.support.services|aicpa|money3|von.maur|transavia|relx.plc|castle.harlan|sabic.europe|td.bank.group.uk|mondelez.uk|a.s.watson.health.beauty.continental.europe.b.v.|abbvie.uk|zilveren.kruis.achmea|abb.north.america|cdiscount|icap.plc|capita.plc|argo.group.us|herff.jones|delphi|educational.testing.service|sas.institute|overstock.com|farm.credit.canada|victoria.police|department.of.economic.development.jobs.transport.resources|one.stop.stores.ltd.|department.of.the.interior|essity.gmbh|sephora|groupe.canam.inc|validus|cable.and.wireless|shaw.communications|internap.network.services|university.of.wisconsin.madison|centurion|mohave.community.federal.credit.union|auckland.council|ppl.corporation|ig.group.plc|schiphol.group|goldcorp|ifds.uk|ancestry.com|nisa.investment.advisors.llc|ppg.benelux|nex|city.of.surrey.bc|marsh.uk|moody.bible.institute|dunbia.group|standard.life|cais.group|state.of.michigan|rac|myriad.genetics|atco.group|viterra|investcorp.international.holdings|federal.reserve.bank.of.san.francisco|national.cancer.institute.center.for.biomedical.informatics.information.technology.nci.cbiit.|proquire.llc|groupon|yum.brands.uk|uwv|ministry.of.business.innovation.employment|rush.university.medical.center|federal.home.loan.bank.boston|vivat.verzekeringen|pfizer.uk|queensland.airports|nsw.office.of.environment.heritage|incomm.holdings.inc.|baker.hughes|gea|workplace.safety.and.insurance.board.wsib.|first.horizon.national|primary.health.care|vocus.pty.ltd|oaktree.capital.management|informatica.trentino|reynolds.consumer.products|bechtle.ag|smithsonian.tropical.research.institute|viasat|teacher.retirement.system.of.texas|ao.world|nsw.dept.trade.investment|ncc.sweden.ab|asx|tyler.technologies.inc.|state.of.california.calpers|broadridge.financial|american.income.life.insurance.company|munich.re.general.services.ltd|nomura|dkv.mobility.services.group|warwickshire.county.council|sncf|purdue.university|discovery.communications|mcwe|methodist.le.bonheur|great.western.bancorporation|21st.mortgage|costco.wholesale.australia.pty.ltd|reward.distrubution|ashland|the.carlyle.group|owens.corning|timken.company|euroclear.plc|blackhawk.network|rexam|john.deere.company|bcbs.of.kansas.city|lumentum|merlin.entertainments.group.limited|vulcan.materials|mercer|wonga|caltex.australia|vale.australia|toll.global|kws.saat.ag|honda.australia|oregon.health.science.university|the.cheesecake.factory|myer.pty.ltd|money.services.inc.|amn.healthcare|alere.uk|sheffield.city.council|umpqua.holdings|belkin.international|technip.france|tmx.finance|asos.com.limited|bashas.|beam.suntory|four.seasons.hotels|mckesson.uk|foresters|national.institute.for.health.research.nihr|n.brown.group|australian.taxation.office|cubic.corporation|department.of.communities.child.safety.and.disability.services|bpay|universal.music.investments.inc.|david.jones.pty.limited|u.s.office.of.personnel.management|atlas.copco.ab|binckbank.n.v.|vizient.inc.|sodexo.sa|bonneville.power.administration|time.inc.uk.ltd|finisar|gold.corporation.the.perth.mint|envia.mitteldeutsche.energie.ag|verisign|j.jill|american.campus.communities|university.of.rochester.medical.center|netsuite|city.national.bank|baptist.health.south.florida|columbia.sportswear|snyder.s.lance.inc|pret.a.manger.europe.limited|electricity.supply.board|stewart.title|deloitte.digital|old.dominion.freight.line|americold|university.of.kansas.medical.center|axalta.coating.systems|triodos|houston.methodist|armstrong.world.industries|cambridge.university.hospitals.nhs|concur.technologies.inc.|objekt.kontor.is.gmbh.co.kg|morphotrust|debenhams|rs.components|gkn|greencore.group.plc|greene.king|halfords|house.of.fraser|imi|the.body.shop|britvic|cardinal.glass.industries|heartland.co.op|markel.international|specsavers.australia|ocado.group|pz.cussons|rolls.royce.plc.|sig|sony.europe|tate.lyle|whsmith|think.finance.inc.|nxp.semiconductors.usa|synlab|santen.inc|skf.ab|qualifacts.systems.inc|sixt.leasing.se|bank.of.canada|new.look|ict.department.of.finance.services.and.innovation|w.s.badcock|corelogic|sears.canada|iap.worldwide|cegedim|bcd.travel|national.beef.packing.company|circle.k|american.eagle.outfitters.inc.|bi.mart|erie.insurance.group.main.|penn.national.gaming|tal.insurance|state.of.florida.department.of.children.and.families|west.midlands.police|mcdonalds.australia|crh.netherlands|komatsu.america|workcover.queensland|abb.optical.group|cybg.plc|zenith.bank.uk|samsonite|arag|point.and.pay|ipsen|united.supermarkets.llc|mmm.healthcare.llc|department.of.environment.land.water.planning|honorhealth.scottsdale.lincoln.healthcare|gander.mountain|saint.gobain.corporation|emco.chemical.distributors|national.healthcare|jackson.health.system|atria.senior.living.group|cambridgeshire.county.council|billabong|serta.simmons.bedding|cadence.bank|gm.financial|economical.mutual.insurance.company|regis.corporation|allianz.insurance|invacare.corporation|dentsply.international|syneos.health|oerag.rechtsversicherung|bon.ton.stores|yesco|portland.general.electric|dart.container.solo|trident.seafoods.corporation|specsavers.optical.group.limited|sorenson.communications|icf.international|rayonier|burlington.coat.factory.main.account.page.|kettering.health.network|metro.bank.plc|meridian.credit.union.limited|willis.towers.watson|symetra.financial|becu|vornado.realty.trust|first.hawaiian.bank|glacier.bancorp|university.hospitals|cole.taylor.bank|columbia.bank|idb.bank|darigold|things.remembered|edwards.lifesciences.corporation|pep.boys|us.steel|weis.markets|cefcu|electronic.merchant.systems|ugi.utilities|alaska.usa.federal.credit.union|dominion.resources.main.|quirch.foods|sears.home.and.outlet|rc.willey|presence.health|novo.nordisk.americas|spin.master|close.brothers|washington.federal.bank|american.greetings|oxford.industries|rwe.npower|fender.musical.instruments|frankenmuth.mutual.insurance.company|mary.kay.inc.|golden.living|life.care.centers.of.america|marriott.international.inc.|grandvision.retail.holding|ardent.health.services|pacific.seafood|dycom.industries|american.savings.bank.f.s.b.|intersil.corporation|apotex.inc|officeworks.ltd|st.luke.s|asante.health.system|forever.living.products|summa.health.system|hawaii.pacific.health|sydney.trains|capital.bluecross|america.first.credit.union|citi.trends|memorial.health.system.memorial.medical.center.|reser.s.fine.foods|pure.storage|maverik|queen.s.medical.center|libbey.glass|aristocrat.technologies|stephens.media|state.of.california.california.department.of.public.health|american.crystal.sugar.company|kinney.drugs|u.s.census.bureau|equitable.life.of.canada|c.j.clarks|e.on.uk|cott.corporation|police.nurses.limited|cetera.financial.group|chiquita.brands|third.federal.savings|louisiana.state.university|primerica|high.liner.foods.incorporated|renown.health|bureau.of.land.management|sierra.nevada.corporation|edf.energy|flex.n.gate|beaumont.health.system|northwestern.medical.faculty.foundation|osf.healthcare.system|presbyterian.healthcare.services|aimia.inc|aig.emea|boardriders.formerly.quiksilver.|discount.drug.mart|glencore.australia.pty.ltd|griffith.foods.griffith.laboratories.|allied.world.assurance.company.holdings.uk|hudson.group|millercoors|palmer.harvey|tailored.brands|bank.of.canada|cadillac.fairview.corporation.limited.the|franciscan.alliance|.407.etr.canadian.tolling.company.international.inc|nyu.langone.hospitals|baycare.health.system|portfolio.recovery.associates|university.of.nevada.reno|herman.miller|university.of.british.columbia|fidelity.worldwide.investment|medical.mutual.of.ohio|genesco|baker.tilly|six.flags.entertainment.corporation|key.food|international.paper|amwins.group|ehealth.ontario|red.cross|bcbs.of.sc|co.operative.bank|co.op.insurance|mizuho.international.uk.|esterline.technologies|zebra.technologies.corporation|rex.healthcare|london.stock.exchange|wellstar.health.system|arctic.slope.regional.corporation|acadia.healthcare|piper.jaffray|university.of.nevada.las.vegas|harbor.freight.tools|sage.north.america|garantibank.international.n.v.|city.of.sydney|united.suppliers|leidos|co.operators.group.limited.the|anadarko.petroleum.corporation|energy.transfer.partners.l.p.|delta.faucet|domtar.corporation|news.corporation|nestle.holdings.inc.|thor.industries.inc.|cracker.barrel.old.country.store.inc.|frito.lay.inc.|electrolux.north.america.inc.|honeywell.inc.|jbs.usa.food.company|huntington.ingalls.industries.inc.|superior.plus.corp|sally.beauty.holdings.inc.|securitas.holdings.inc.|berry.plastics.group|usg.corporation|university.of.maryland.medical.system.corporation|irving.oil.limited|new.york.power.authority|smithfield.foods.inc.|freeport.mcmoran.corporation|potash.corporation.of.saskatchewan.inc|la.coop.federee|regal.entertainment.group|alliancebernstein.l.p.|everest.reinsurance.holdings.inc.|systemax.inc.|nexeo.solutions.llc|investors.group.financial.services.inc|tokio.marine.holdings|family.dollar.stores.of.louisiana.inc.|general.dynamics.government.systems.corporation|agropur.cooperative|queb.cor.inc|precision.castparts.corp.|state.university.of.new.york|olive.view.medical.center|hanesbrands|kinder.morgan.energy.partners.l.p.|visteon.corporation|tyson.foods.inc.|temple.university|enterprise.products.partners.l.p.|ryder.system.inc.|biomet.inc.|energizer.holdings.inc.|fossil|polyone.corporation|steelcase.inc.|eastman.chemical.company|american.national.insurance.company.inc|city.of.boston.department.of.neighborhood.development|transocean.inc.|scansource|curtiss.wright.corporation|graphic.packaging.holding.company|unified.grocers.inc.|packaging.corporation.of.america|coca.cola.european.partners.master|essentia.health|atrium.health|florida.power.light.company.inc|public.service.enterprise.group.incorporated|indiana.university.health.inc.|utc.aeorspace|technipfmc|otis.elevator.international.inc.|altria|ingredion.incorporated|campbell.soup.company|radioshack.corporation|nrg.energy.inc.|j.b.hunt.transport.services.inc.|airgas.inc.|clark.county.school.district|collective.brands.inc.|crown.castle.international.corp.|mercury.general.insurance|norfolk.southern.corporation|sealed.air.corporation|west.corporation|cornell.university|valmont.industries|lennar|nabors.industries.inc.|nine.west.holdings.inc.|coty.inc|adt|westrock|regal.beloit.corporation|cf.industries.holdings.inc.|bemis.company|lions.gate.entertainment.inc.|plains.all.american.pipeline.l.p.|wakemed|old.mutual|eog.resources.inc.|the.ohio.state.university|maple.leaf.foods.inc|mcdermott.international.inc.|kpmg.llp|schwan.food.company|mccormick.company.incorporated|newmont.mining.corporation|allina.health|sonoco.products.company|towers.watson.co|calpine.corporation|calumet.specialty.products.partners.lp|topco.associates.llc|hawaiian.electric.industries.inc.|roundy.s.supermarkets.inc.|arris.group|tennessee.valley.authority|the.scotts.miracle.gro.company|exide.technologies|bath.body.works.llc|sonic.automotive.inc.|soci.t.des.loteries.du.qu.bec|british.columbia.lottery.corporation.bclc|bwx.technologies.inc.|cinemark.usa.inc.dupe.|jll.jones.lang.lasalle.|american.electric.power.company.inc.|benchmark.electronics.inc.|home.hardware.stores.limited|california.state.university.system|rush.enterprises.inc.|hub.group.inc.|wawanesa.mutual.insurance.company.the|ryerson.inc.|sunpower.corporation|select.medical.corporation|lennox.international.inc.|dean.foods.company|basf.corporation|blackberry.limited|toromont.industries.ltd|heartland.dental.care|kum.go|federated.mutual.insurance|aids.healthcare.foundation|bluegreen|northshore.university.health.system|inova.health.system|abington.memorial.hospital|charlotte.russe|newegg.inc.|concentra|new.mountain.capital|health.first|akron.children.s.hospital|edelman|ingram.industries|the.ensign.group|mcafee|winthrop.university.hospital|syniverse|westchester.medical.center|vizio|rank.group.plc|rollins|fruit.of.the.loom|worldpac|foremost.farms.usa|gate.petroleum|albany.medical.center|amerisure.mutual.insurance|meadowbrook.insurance.group|national.vision|north.memorial.health|mizuho|noridian.mutual.insurance.company|california.pizza.kitchen|yale.new.haven.health.system|intergraph.corporation.hexagon.|hennepin.healthcare.system|the.geo.group|cobank|forsythe.technology|thomas.jefferson.university.hospital|cliftonlarsonallen|department.of.state|biomarin.pharmaceutical|yankee.candle.company|frost.bank|temple.university.health.system|do.it.best|cato.corporation|american.enterprise|children.s.hospitals.and.clinics.of.minnesota|thedacare|pacsun|advancepierre.foods|vibra.healthcare.llc|marshfield.clinic|g.iii.apparel.group.ltd.|calamos.investments.llc|school.specialty|convergys|rpc|popular|hospital.sisters.health.system|office.of.management.and.budget|bankunited|crocs|synaptics|fbr.capital.markets|impax.laboratories|greenstone.farm.credit.services|transdev|ezibuy.nz.omni|valuation.office.agency|sunopta.inc|bdo|viva.energy.australia.ltd|united.states.geological.survey|virgin.mobile.australia|colorado.state.university|digital.river|berkadia|algonquin.power|nhs.england|multicare.health.system|henderson.global.investors|city.of.minneapolis.mn|state.of.vermont.agency.of.human.services|national.stores|avmed.health|sita.inc.usa|puma.ag|veterans.health.administration|scottish.widows.group|infosys|synovus.financial|sabre.glbl.inc.|fujitsu.technology.solutions.gmbh|software.ag|amdocs.incorporated|thomson.uk|cbs.interactive|altice.usa|toro.company|shaw.industries|bgl.group.ltd.|carnegie.mellon.university|city.of.philadelphia|johns.hopkins.university.applied.physics.laborator|magellan.midstream.partners|northrop.grumman.md|alliant.energy|nbc.universal|pearson|ihg|european.parliament|jewelry.television|darden.restaurants|maximus|cantor.fitzgerald.co.|united.guaranty.corporation|u.s.securities.and.exchange.commission.sec.|toronto.hydro.electric.system|travelex.holdings.limited|bull.sas|nbty|harvard.pilgrim.health.care|new.york.presbyterian.healthcare.systems|premier.healthcare.alliance|club.mediterranee|cgi.it.uk.limited|national.bank.of.canada|the.aa|affiliated.foods.midwest.cooperative|scripps.health|phoenix.group|southwest.gas.corporation|leiden.university.medical.center|aaron.s|federal.reserve.bank.of.st.louis|gie.gld.services.groupe.le.duff.|bank.of.the.west|daiwa.capital.markets.europe|erac|admiral.insurance|arch.insurance.subsidiary.|inghams.limited|h.d.smith.llc|kkh.kaufm.nnische.krankenkasse|brown.jordan.international|tata.consulting.services.netherlands.bv|skipton.building.society|nato|engie.na|the.container.store|murex|elekta.ltd.|gareth.morgan.investments|waikato.district.health.board|brocacef|equinix|us.xpress|acn|travelers|department.of.premier.and.cabinet.tasmania|ares.management|pechanga.resort.casino|toronto.district.school.board|la.poste|veritiv|ministerie.van.veiligheid.en.justitie|ageas.insurance.limited|insurance.corporation.of.british.columbia|new.york.community.bancorp|athene.holding|onesavings.bank|city.of.mesa|london.health.sciences|lsc.communications|dawn.meats|westjet.an.alberta.partnership|trimble.navigation|sykes.assistance.services.corporation|pepsico.australia.new.zealand|utica.mutual.insurance.company|lch.clearnet|affiliated.managers.group|vereit|tetrapak.ab|general.dynamics.mission.systems|allied.wallet|telus.communications.inc.|cmc.markets.uk.plc|martinrea.international|fgl.sports|ingenico.epayments|paymark.limited|funnelwise|maricopa.county.az|clarks|australian.pharmaceutical.industries|department.of.public.expenditure.and.reform|axicorp.financial.services.pty.ltd.|vision.super|esure.group|australia.post|univision.communications.inc.|ezcorp|bob.evans|air.products.and.chemicals.inc.main.|cincinnati.children.s.medical.center|esri.deutschland.group|tory.burch|northside.hospital|academy.sports.outdoors|farm.credit.services.of.mid.america|pon.holdings|pc.connection.main.account.page.|g4s|hoag.hospital|lvmh.moet.hennessy.louis.vuitton.inc.|dick.smith.holdings.limited|adyen|viejas.tribal.council|cae.inc|associated.food.stores|public.storage|university.of.chicago.medical.center|king.county|wake.forest.healthcare.ventures|martin.marietta.materials|homebase|hemlock.semiconductor.group|shop.direct.group|academy.mortgage|state.revenue.office.victoria|american.apparel|j.nk.pings.l.ns.landsting|baylor.scott.white|sixt|sheetz.inc.|schuh|russell.investments|oneamerica.financial.dupe.|ocwen.financial.corporation|l.oreal.usa|state.of.kansas|mine.super|bird.construction.company|madison.square.garden|maxim.healthcare.services.main.account.page.|maritime.super|optiver.australia|union|credit.suisse.holdings.australia.|firstmac|qic|aeropostale|indivior|mediolanum.asset.management.ireland|department.of.housing.and.public.works.queensland.|the.related.companies|nuffield.health|cotton.on.group.services.pty.ltd|the.honest.company.inc.|renasant.bank|alorica|j.d.irving.limited|beth.israel.deaconess.medical.center.caregroup.|tesoro.corporation|arup.laboratories.inc|skechers|invista.inc.|cancer.care.ontario|executive.office.of.the.president|oceanx.llc|oxford.university.hospitals.nhs.trust|ak.steel.holding|omnicell|axa.ppp|orica.ltd|adventist.health|cara.operations.limited|enercare.inc.|midfirst.bank|surge.energy|linde.group|lawrence.livermore.national.laboratory|william.hill.australia|j.crew|office.of.the.us.attorneys|eaton.vance|allscripts.healthcare.solutions|aaa.national|flir.systems|equitable.bank|lcmc.health|wiley|varian.medical.systems.inc.|university.of.utah.hospitals.clinics|tops.markets|boyd.gaming|wabco.north.america|genesis.healthcare.corporation|big.y.foods|torstar.corporation|del.monte.foods|99.cents.only.stores|australian.trade.and.investment.commission|nfu.mutual|avis.budget.group|dfc.global.corp.|xilinx.uk.i|port.authority.of.new.york.new.jersey|federal.deposit.insurance.corporation|seattle.children.s.hospital|matrix.medical.network|big.5.sporting.goods|catholic.medical.center|mammoet|psba|commission.junction.inc.|wolseley.canada|kinecta.federal.credit.union|cbre.uk|bank.of.internet.usa|panera.bread|trelleborg|bank.of.scotland.germany|martini.ziekenhuis|ohiohealth|raley.s|department.of.defense.defense.contract.management.agency|capital.and.coast.district.health.board|dave.buster.s|lgia.super|stater.bros.markets|coca.cola.north.america|confluence.health|financial.conduct.authority|teleflex.incorporated|scandic.hotels|kla.tencor.corporation|hsbc.canada|epic.technologies.llc|atlas.copco|worksafebc|illumina.inc.|tesco.bank|euronet.worldwide|black.knight.financial.services|city.of.mississauga.on|axa.equitable.main.|sonepar.pacific|bc.ferries|the.associated.press|aes.corporation|netgear|toronto.blue.jays|mosaic.company|eddie.bauer|wescom.credit.union|polycom|unitedhealth.group.uki|mitsubishi.motors.north.america.inc.|bon.secours.health.system|inter.american.development.bank|aleris.international|sprouts.farmers.market|je.dunn.construction|virginia.mason.medical.center|city.of.phoenix|pension.insurance.corporation|wellspan.health|nationstar.mortgage|cpb.contractors|camso.inc|bcbs.of.nc|burger.king|rack.room.shoes|veterans.united.home.loans|toronto.police.department|people.s.united.bank|heathrow.airport|teleperformance.usa|british.columbia.automobile.association|parsons|landry.s.restaurants|vcu.health.system.subsidiary.|lifespan.corporation|charles.river.laboratories.international|tetra.tech.inc.|cape.cod.healthcare|gmo|bmo.capital.markets|assured.guaranty.municipal.corp.|event.hospitality.entertainment.limited|seqirus.uk.ltd.accounts.payable|national.fuel|the.restaurant.group.plc|everi.holdings.inc.|conmed|world.vision.international|new.era.cap|vanderlande.industries.inc.|adventist.health.system|first.quality.enterprises.inc|unisys|sterling.national.bank|the.university.of.utah|princeton.university|shamrock.foods.company|norampac|tictoc.online.pty.ltd|saputo.inc.|caisse.de.depot.et.placement.du.quebec|dept.of.commerce.wa.|ann.inc.|avista.corporation|city.of.hope|radnet|wilbur.ellis.company|arby.s.restaurant.group|zimmer.biomet|.cfsgam.colonial.first.state.global.asset.management|american.axle.manufacturing|neustar|bj.s.restaurants|u.haul|hubert.burda.media.holding|encore.capital.group|sapient|trustmark.national.bank|regional.municipality.of.peel.the|manorcare|teachers.health.fund|primelending|qbe.europe|british.columbia.hydro.powerex|digital.state|salt.lake.county|batory.foods|rolls.royce.controls.data.services|cox.automotive.australia|lookers|kantar.group.uk.|prime.healthcare|aci.worldwide.inc.|virginia.commonwealth.university|price.chopper|university.of.west.georgia|farmers.merchants.bank.of.long.beach|university.of.pennsylvania.health.system|schnucks.markets.dupe.|fred.s.inc|scan.health.plan|landis.gyr|barnabas.health|scoular|investors.bank|scotia.gas.networks.ltd|friedkin|pinnacle.agriculture.holdings|depository.trust.clearing.corporation|ria.financial.services|urs.corporation|cws.boco.deutschland.gmbh|bureau.of.alcohol.tobacco.firearms.explosives|department.of.energy.oak.ridge.national.lab|marathon.oil|lyft.inc.|dolby.laboratories|aldo|leaseplan.uk.ltd.|coast.capital.savings.credit.union|mallinckrodt.pharmaceuticals|chg.healthcare.services|sonos.inc.|edison.international|state.of.new.york|west.pharmaceutical.services|wpp.group|spartan.motors.inc.|guess.inc.|prologis|foodstuffs.north.island.limited|tom.james.company|vattenfall|covance|open.text.corporation|amsurg|marvell.technology.group.ltd|dupe.john.muir.health|ipay.jack.henry.associates|australian.financial.security.authority.afsa.|endemol.shine.group|invesco.perpetual|federated.co.operatives.limited|siteone|desjardins|axis.capital.holdings|urban.outfitters.uk|roche.uk|fitbit|first.reserve|air.canada|surrey.county.council|provident.financial.group|state.of.florida.department.of.corrections|michelin|poundland|extended.stay|cook.children.s.health.care.system|australian.government.department.of.health|nz.home.loans|department.of.the.treasury.comptroller.of.the.currency|cree.inc|pladis.global|methodist.health.system.of.dallas|james.cook.university|fortive.corporation|tata.steel.netherlands|iqor|hamburg.sud|qgcio|servisfirst.bank|green.shield.canada|astrazeneca|weill.cornell.medical|darling.ingredients|motorit.ab|cadence.design.systems|chanel.uk|amedisys|trelleborg.germany|boart.longyear.limited|lhp.hospital.group|oneweb|urban.outfitters|frontier.agriculture.ltd|rockland.trust|dyno.nobel|liberty.university.inc.|d.h|uniprix|b.e.aerospace|london.metropolitan.police|lvnl|act.health|harvey.norman.holdings.ltd|cdk.global|go.compare|bendigo.and.adelaide.bank|selecthealth|spotlight.retail.group|mercedes.benz.financial.services.uk|insperity.inc|graincorp.ltd|stony.brook.medicine|jeppesen|acosta.sales.marketing|just.energy|bevmo.|caldic|loyola.university.health.system|the.game.group|department.for.culture.media.sport|munich.reinsurance.america|polyconcept.north.america|york.risk.services.group|fidelity.guaranty.life|dannon|raymour.flanigan|bumble.bee.foods|fullbeauty.brands.inc.|modell.s.sporting.goods|spencer.gifts|holman.enterprises|ambac.financial.group|kaleida.health|essent.guaranty|prosight.specialty.insurance|mid.north.coast.local.health.district|agilent.technologies|eli.lilly.and.company|murrumbidgee.local.health.district|state.of.new.mexico|nen|vsp|benjamin.moore.co.|thames.water|federated.investors|resmed.uk.ltd|first.commonwealth.financial|virgin.money|pages.jaunes|academisch.medisch.centrum.amc.|british.airways|british.broadcasting.corporation|essent.energy|hutchison.3g.uk.limited|klm.royal.dutch.airlines|mars|first.investors.corporation.foresters.|nsw.telco.authority|catalent.pharma.solutions|onewest.bank|sunrider.international|s.t.bank|baptist.healthcare.system.ky.|state.of.ohio.ohio.department.of.rehabilitation.and.correction|pricesmart|atlas.holdings|usga.main.|market.axess|main.line.health|symbion.australia|ansys|keysight.technologies|state.of.ohio.ohio.department.of.transportation|total.quality.logistics|smart.and.final|jazz.pharmaceuticals|ttm.technologies|isban.de.santander.group|berlin.packaging|bass.pro.shops|freedom.mortgage|monster.energy.company|federal.home.loan.bank.of.atlanta|bcbg.max.azria.group|east.west.bank|tti|orchard.supply.hardware|daiichi.sankyo|hilmar.cheese|baiada.group|gogo|arista.networks|peet.s.coffee.tea|stage.stores|mouser.electronics|blue.diamond.growers|sunkist.growers|rbc.capital.markets.london|chemed.corporation|panda.restaurant.group|the.brock.group|jacksonville.electric.authority|city.of.portland|lonza|kwik.trip|mvp.health.care|volvo.trucks.north.america|tmg.health|diamond.foods|solar.turbines|callcredit.information.group|mednax|gain.capital.inc.|arcadia.group|state.compensation.insurance.fund|management.training.corporation|tbc|morton.salt|art.van.furniture|coventry.building.society|tyco.integrated.security|advent.international.corporation|interstate.batteries|state.of.california.california.employment.development.department|the.open.university|uc.davis.health.system|zachry.holdings|independent.health|tomorrow.focus.ag|bombardier.transportation.gmbh|physicians.mutual.insurance|bmw.financial.services|mfs.investment.management|mesirow.financial|hesta.super.fund|empire.southwest|bcbs.of.la|intuitive.surgical|camping.world.inc.|weatherford.international|emigrant.bank|teledyne.technologies|wps.health.insurance|evercore.partners|stater.nv|nebraska.furniture.mart|michels.corporation|ventura.foods|alex.lee|probuild|ritchie.bros.auctioneers.incorporated|american.securities|c.r.england|sftf.interflora|norton.healthcare|fry.s.electronics|the.range|energysolutions|p.f.chang.s.china.bistro|jockey.international|citizens.property.insurance.corporation|national.life.group|mercy|lch.clearnet.old.|lts.solutions.ltd|green.dot.corporation|tnt|george.mason.university|new.penn.financial|orlando.health|sparrow.health.system|hitachi.capital|royal.london.group|rescare|firstbank.holding.company|mckinsey.company.inc.|boscov.s.department.stores|allison.transmission|provident.financial.services|bofi.federal.bank|american.hotel.register|globalfoundries|waddell.reed.financial|priority.health|northwestern.university|city.of.san.diego.ca|american.furniture.warehouse|bessemer.trust|yorkshire.building.society|frontier.airlines|rady.children.s.hospital|big.d.construction|edward.don.company|washington.gas|carhartt|jupiter.asset.management|hid.global|lehigh.valley.health.network.inc.|crif.lending.solutions|post.office|carestream.health|first.financial.bank|jack.in.the.box|checkers.drive.in.restaurants|sisters.of.charity.of.leavenworth.health.system|pacific.western.bank|bba.aviation.usa|city.of.oakland.ca|the.metrohealth.system|tarmac|university.of.iowa.health.care|occ.options.clearing.corporation.|chemical.bank.and.trust.company|farm.credit.services.of.america|janus.capital.group.inc.|privatebancorp.inc.|alsco|first.merchants.corporation|groupe.jean.coutu.pjc.inc.le|wsfs.bank|scheels.all.sports|pgg.wrightson|bcbs.of.mn|ohio.national.financial.services.inc.|atlantic.health.system|manhattan.associates|city.of.austin.tx|state.of.wisconsin|inland.empire.health.plan|park.national.bank|alfa.insurance|security.finance.corporation|valley.national.bancorp|fleetcor.technologies|super.a.mart.holdings.pty.ltd|black.box.corporation|brown.brown.insurance|mothercare|victory.capital|wickes|cim.group|one.call.care.management|wilson.sporting.goods|orange.lake.country.club.inc|a.t.u.auto.teile.unger|kenneth.cole.productions|delta.dental.of.wisconsin|virginia.tech|iowa.state.university|cma.systems|banque.laurentienne.du.canada|hni.corporation|nationale.nederlanden|ladbrokes|axel.springer.ag|wesbanco|northwest.federal.credit.union|simon.fraser.university|federal.home.loan.bank.of.new.york|cohen.steers|kratos.defense.security.solutions|beacon.health.system|new.horizons.computer.learning.centers|maimonides.medical.center|direct.general|rochester.regional.health|jimmy.john.s|medpro.group|national.penn|eagle.bancorp.inc.|veronis.suhler.associates|visiting.nurse.service.of.ny|carnival.uk|brother.international.corporation",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",6],
      "arg1":"gtm.timer"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"naccts"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"\/resources\/"
    },{
      "function":"_re",
      "arg0":["macro",10],
      "arg1":"\/assets\/|\\\/assets\\\/|\\.pdf|.pdf|pptx|jpg"
    },{
      "function":"_cn",
      "arg0":["macro",11],
      "arg1":"transformwithapis"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"(^$|((^|,)63355_648($|,)))"
    },{
      "function":"_cn",
      "arg0":["macro",29],
      "arg1":"a-video tile-action"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"transformwithapis"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"(^$|((^|,)63355_601($|,)))"
    },{
      "function":"_re",
      "arg0":["macro",30],
      "arg1":"1M|10M|50M|100M|250M",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"gtm.timer"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"(^$|((^|,)63355_645($|,)))"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"https:\/\/stg-mulesoftd8.www.msit.io"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",18],
      "arg1":"mulesoftd8.www.msit.io"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"\/"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"help.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",10],
      "arg1":"https:\/\/connect.mulesoft.com\/events\/connect\/london"
    },{
      "function":"_eq",
      "arg0":["macro",8],
      "arg1":"https:\/\/www.mulesoft.com"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"(^$|((^|,)63355_606($|,)))"
    },{
      "function":"_cn",
      "arg0":["macro",29],
      "arg1":"connect_london-nav-cta"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"(^$|((^|,)63355_604($|,)))"
    },{
      "function":"_cn",
      "arg0":["macro",29],
      "arg1":"connect_london-body-cta"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"(^$|((^|,)63355_602($|,)))"
    },{
      "function":"_cn",
      "arg0":["macro",29],
      "arg1":"event-price-register-cta"
    },{
      "function":"_cn",
      "arg0":["macro",8],
      "arg1":"\/london\/"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"(^$|((^|,)63355_603($|,)))"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"meetups.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",11],
      "arg1":"resources.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"https:\/\/docs.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",11],
      "arg1":"docs.stgx.mulesoft.com"
    },{
      "function":"_cn",
      "arg0":["macro",11],
      "arg1":"raml.org"
    },{
      "function":"_cn",
      "arg0":["macro",11],
      "arg1":"library.mulesoft.com"
    },{
      "function":"_eq",
      "arg0":["macro",10],
      "arg1":"https:\/\/anypoint.mulesoft.com\/login\/#\/signup?apintent=generic"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"(^$|((^|,)63355_620($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",4],
      "arg1":"true"
    },{
      "function":"_cn",
      "arg0":["macro",10],
      "arg1":"\/lp\/dl\/studio"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"(^$|((^|,)63355_633($|,)))"
    },{
      "function":"_re",
      "arg0":["macro",31],
      "arg1":"Banner Accept Cookies|Banner Auto Close|Banner Close Button|Preferences Save Settings",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",6],
      "arg1":"trackOptanonEvent"
    },{
      "function":"_css",
      "arg0":["macro",32],
      "arg1":"div.optanon-save-settings-button a, div.optanon-save-settings-button div[class*=optanon-white-button], div.optanon-allow-all-button div[class*=optanon-white-button], button.save-preference-btn-handler, #accept-recommended-btn-handler, button.onetrust-close-btn-handler"
    },{
      "function":"_eq",
      "arg0":["macro",29],
      "arg1":"mktoButton"
    },{
      "function":"_re",
      "arg0":["macro",7],
      "arg1":"\/webinars\/|\/lp\/|\/dl\/|\/contact"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"https:\/\/docs.mulesoft.com\/"
    }],
  "rules":[
    [["if",0],["add",6]],
    [["if",5,6],["add",7]],
    [["if",6,8],["add",8,10,15,16,20,29,32,38,86],["block",30]],
    [["if",6,9],["add",8,17,86]],
    [["if",10,11,12],["add",8,10,16,32,38,86]],
    [["if",14,15,16],["unless",13],["add",9]],
    [["if",17,18],["add",11]],
    [["if",6,20],["unless",19],["add",12,25,30,31,33,36,73,79,81,83,85]],
    [["if",6,23],["add",13,18,19,26,27,4,5]],
    [["if",6],["add",14,75,82,87,43,44,45,46,47,48,49,50,51,52,53,54,57,58]],
    [["if",6,29],["add",16]],
    [["if",6,30],["add",16]],
    [["if",6,31],["add",17]],
    [["if",6,35],["add",21,88,92],["block",4]],
    [["if",6,36],["add",22,63,91],["block",4]],
    [["if",6,34],["add",23],["block",19]],
    [["if",37,38],["add",24]],
    [["if",44],["add",27,59,60,72]],
    [["if",6,45],["add",27]],
    [["if",46],["add",28]],
    [["if",6,48],["add",33,64,1,79,81,85,91],["block",5]],
    [["if",6,14],["add",33,61,1,77,79,81,85,91],["block",19,4]],
    [["if",6,49],["add",33,67,1,81,91]],
    [["if",6,39],["add",33,65,81],["block",25,5]],
    [["if",6,50],["add",33,81]],
    [["if",52],["unless",51],["add",34]],
    [["if",52,53],["add",35]],
    [["if",54,55],["add",35]],
    [["if",6,56],["add",35]],
    [["if",6,57],["add",37]],
    [["if",15,58,59,60],["add",39]],
    [["if",15,61,62,63],["add",40]],
    [["if",65,66],["unless",64],["add",41]],
    [["if",6,67],["add",42]],
    [["if",6,68],["add",42,91]],
    [["if",6,69],["add",42,2]],
    [["if",6,70],["add",55,56]],
    [["if",6,32],["add",62,1,79,85,91],["block",19,68]],
    [["if",6,71],["add",66],["block",5]],
    [["if",15,72,73,74],["add",68]],
    [["if",15,75,76],["add",69]],
    [["if",15,77,78],["add",70]],
    [["if",15,79,80,81],["add",71]],
    [["if",6,82],["add",3]],
    [["if",6,20],["add",0]],
    [["if",6,83],["add",1],["block",82]],
    [["if",6,84],["add",1,74],["block",5]],
    [["if",6,85],["add",1],["block",5]],
    [["if",6,86],["add",76],["block",4]],
    [["if",15,88,89],["add",78]],
    [["if",6,90],["add",5]],
    [["if",15,91,92],["add",84]],
    [["if",93,94],["add",89]],
    [["if",12,95],["add",89]],
    [["if",12,96,97],["add",90]],
    [["if",6,98],["add",93]],
    [["if",1,2,3,4],["block",6]],
    [["if",1,4],["unless",7],["block",7,9,21,22,23,24,28,33,39,40,61,62,63,64,65,66,67,68,69,70,71,3,0,73,1,76,77,4,78,5,80,81,82,83,84,90,2,91]],
    [["if",2,4],["block",8,10,13,14,16,17,18,19,20,25,26,27,29,30,31,32,34,35,36,37,41,42,74,75,85,86,87]],
    [["if",6,21],["block",12]],
    [["if",6,22],["block",12]],
    [["if",6,24],["block",13,14,19,24,25,30,31]],
    [["if",6,25],["block",13,19]],
    [["if",6,26],["block",13]],
    [["if",6,27],["block",13]],
    [["if",6,28],["block",14,16,18,26]],
    [["if",6,33],["block",19]],
    [["if",6,40],["block",25]],
    [["if",6,41],["block",25,30,31]],
    [["if",6,42],["block",25]],
    [["if",6,43],["block",25]],
    [["if",6,47],["block",5,82]],
    [["if",6,87],["block",4]]]
},
"runtime":[]




};
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var aa,ba="function"==typeof Object.create?Object.create:function(a){var b=function(){};b.prototype=a;return new b},ca;if("function"==typeof Object.setPrototypeOf)ca=Object.setPrototypeOf;else{var da;a:{var ea={lf:!0},fa={};try{fa.__proto__=ea;da=fa.lf;break a}catch(a){}da=!1}ca=da?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null}var ia=ca,ja=this||self,la=/^[\w+/_-]+[=]{0,2}$/,ma=null;var pa=function(){},qa=function(a){return"function"==typeof a},g=function(a){return"string"==typeof a},ra=function(a){return"number"==typeof a&&!isNaN(a)},ua=function(a){return"[object Array]"==Object.prototype.toString.call(Object(a))},r=function(a,b){if(Array.prototype.indexOf){var c=a.indexOf(b);return"number"==typeof c?c:-1}for(var d=0;d<a.length;d++)if(a[d]===b)return d;return-1},va=function(a,b){if(a&&ua(a))for(var c=0;c<a.length;c++)if(a[c]&&b(a[c]))return a[c]},wa=function(a,b){if(!ra(a)||
!ra(b)||a>b)a=0,b=2147483647;return Math.floor(Math.random()*(b-a+1)+a)},ya=function(a,b){for(var c=new xa,d=0;d<a.length;d++)c.set(a[d],!0);for(var e=0;e<b.length;e++)if(c.get(b[e]))return!0;return!1},za=function(a,b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b(c,a[c])},Aa=function(a){return Math.round(Number(a))||0},Ba=function(a){return"false"==String(a).toLowerCase()?!1:!!a},Ca=function(a){var b=[];if(ua(a))for(var c=0;c<a.length;c++)b.push(String(a[c]));return b},Ea=function(a){return a?
a.replace(/^\s+|\s+$/g,""):""},Fa=function(){return(new Date).getTime()},xa=function(){this.prefix="gtm.";this.values={}};xa.prototype.set=function(a,b){this.values[this.prefix+a]=b};xa.prototype.get=function(a){return this.values[this.prefix+a]};
var Ga=function(a,b,c){return a&&a.hasOwnProperty(b)?a[b]:c},Ha=function(a){var b=!1;return function(){if(!b)try{a()}catch(c){}b=!0}},Ia=function(a,b){for(var c in b)b.hasOwnProperty(c)&&(a[c]=b[c])},Ja=function(a){for(var b in a)if(a.hasOwnProperty(b))return!0;return!1},Ka=function(a,b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]),c.push.apply(c,b[a[d]]||[]);return c},La=function(a,b){for(var c={},d=c,e=a.split("."),f=0;f<e.length-1;f++)d=d[e[f]]={};d[e[e.length-1]]=b;return c},Ma=function(a){var b=
[];za(a,function(c,d){10>c.length&&d&&b.push(c)});return b.join(",")},Na=function(a){for(var b=[],c=0;c<a.length;c++){var d=a.charCodeAt(c);128>d?b.push(d):2048>d?b.push(192|d>>6,128|d&63):55296>d||57344<=d?b.push(224|d>>12,128|d>>6&63,128|d&63):(d=65536+((d&1023)<<10|a.charCodeAt(++c)&1023),b.push(240|d>>18,128|d>>12&63,128|d>>6&63,128|d&63))}return new Uint8Array(b)};/*
 jQuery v1.9.1 (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
var Oa=/\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,Pa=function(a){if(null==a)return String(a);var b=Oa.exec(Object.prototype.toString.call(Object(a)));return b?b[1].toLowerCase():"object"},Qa=function(a,b){return Object.prototype.hasOwnProperty.call(Object(a),b)},Ra=function(a){if(!a||"object"!=Pa(a)||a.nodeType||a==a.window)return!1;try{if(a.constructor&&!Qa(a,"constructor")&&!Qa(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}for(var b in a);return void 0===
b||Qa(a,b)},B=function(a,b){var c=b||("array"==Pa(a)?[]:{}),d;for(d in a)if(Qa(a,d)){var e=a[d];"array"==Pa(e)?("array"!=Pa(c[d])&&(c[d]=[]),c[d]=B(e,c[d])):Ra(e)?(Ra(c[d])||(c[d]={}),c[d]=B(e,c[d])):c[d]=e}return c};
var Sa=[],Ta={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"},Ua=function(a){return Ta[a]},Va=/[\x00\x22\x26\x27\x3c\x3e]/g;var Za=/[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\\\x85\u2028\u2029]/g,cb={"\x00":"\\x00","\b":"\\x08","\t":"\\t","\n":"\\n","\x0B":"\\x0b",
"\f":"\\f","\r":"\\r",'"':"\\x22","&":"\\x26","'":"\\x27","/":"\\/","<":"\\x3c","=":"\\x3d",">":"\\x3e","\\":"\\\\","\u0085":"\\x85","\u2028":"\\u2028","\u2029":"\\u2029",$:"\\x24","(":"\\x28",")":"\\x29","*":"\\x2a","+":"\\x2b",",":"\\x2c","-":"\\x2d",".":"\\x2e",":":"\\x3a","?":"\\x3f","[":"\\x5b","]":"\\x5d","^":"\\x5e","{":"\\x7b","|":"\\x7c","}":"\\x7d"},db=function(a){return cb[a]};
Sa[8]=function(a){if(null==a)return" null ";switch(typeof a){case "boolean":case "number":return" "+a+" ";default:return"'"+String(String(a)).replace(Za,db)+"'"}};var mb=/[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,nb={"\x00":"%00","\u0001":"%01","\u0002":"%02","\u0003":"%03","\u0004":"%04","\u0005":"%05","\u0006":"%06","\u0007":"%07","\b":"%08","\t":"%09","\n":"%0A","\x0B":"%0B","\f":"%0C","\r":"%0D","\u000e":"%0E","\u000f":"%0F","\u0010":"%10",
"\u0011":"%11","\u0012":"%12","\u0013":"%13","\u0014":"%14","\u0015":"%15","\u0016":"%16","\u0017":"%17","\u0018":"%18","\u0019":"%19","\u001a":"%1A","\u001b":"%1B","\u001c":"%1C","\u001d":"%1D","\u001e":"%1E","\u001f":"%1F"," ":"%20",'"':"%22","'":"%27","(":"%28",")":"%29","<":"%3C",">":"%3E","\\":"%5C","{":"%7B","}":"%7D","\u007f":"%7F","\u0085":"%C2%85","\u00a0":"%C2%A0","\u2028":"%E2%80%A8","\u2029":"%E2%80%A9","\uff01":"%EF%BC%81","\uff03":"%EF%BC%83","\uff04":"%EF%BC%84","\uff06":"%EF%BC%86",
"\uff07":"%EF%BC%87","\uff08":"%EF%BC%88","\uff09":"%EF%BC%89","\uff0a":"%EF%BC%8A","\uff0b":"%EF%BC%8B","\uff0c":"%EF%BC%8C","\uff0f":"%EF%BC%8F","\uff1a":"%EF%BC%9A","\uff1b":"%EF%BC%9B","\uff1d":"%EF%BC%9D","\uff1f":"%EF%BC%9F","\uff20":"%EF%BC%A0","\uff3b":"%EF%BC%BB","\uff3d":"%EF%BC%BD"},ob=function(a){return nb[a]};Sa[16]=function(a){return a};var qb;
var rb=[],sb=[],tb=[],vb=[],wb=[],xb={},yb,zb,Ab,Bb=function(a,b){var c={};c["function"]="__"+a;for(var d in b)b.hasOwnProperty(d)&&(c["vtp_"+d]=b[d]);return c},Cb=function(a,b){var c=a["function"];if(!c)throw Error("Error: No function name given for function call.");var d=xb[c],e={},f;for(f in a)a.hasOwnProperty(f)&&0===f.indexOf("vtp_")&&(e[void 0!==d?f:f.substr(4)]=a[f]);return void 0!==d?d(e):qb(c,e,b)},Eb=function(a,b,c){c=c||[];var d={},e;for(e in a)a.hasOwnProperty(e)&&(d[e]=Db(a[e],b,c));
return d},Fb=function(a){var b=a["function"];if(!b)throw"Error: No function name given for function call.";var c=xb[b];return c?c.priorityOverride||0:0},Db=function(a,b,c){if(ua(a)){var d;switch(a[0]){case "function_id":return a[1];case "list":d=[];for(var e=1;e<a.length;e++)d.push(Db(a[e],b,c));return d;case "macro":var f=a[1];if(c[f])return;var h=rb[f];if(!h||b.Lc(h))return;c[f]=!0;try{var k=Eb(h,b,c);k.vtp_gtmEventId=b.id;d=Cb(k,b);Ab&&(d=Ab.Mf(d,k))}catch(y){b.te&&b.te(y,Number(f)),d=!1}c[f]=
!1;return d;case "map":d={};for(var l=1;l<a.length;l+=2)d[Db(a[l],b,c)]=Db(a[l+1],b,c);return d;case "template":d=[];for(var m=!1,n=1;n<a.length;n++){var q=Db(a[n],b,c);zb&&(m=m||q===zb.ub);d.push(q)}return zb&&m?zb.Pf(d):d.join("");case "escape":d=Db(a[1],b,c);if(zb&&ua(a[1])&&"macro"===a[1][0]&&zb.mg(a))return zb.Jg(d);d=String(d);for(var u=2;u<a.length;u++)Sa[a[u]]&&(d=Sa[a[u]](d));return d;case "tag":var p=a[1];if(!vb[p])throw Error("Unable to resolve tag reference "+p+".");return d={fe:a[2],
index:p};case "zb":var t={arg0:a[2],arg1:a[3],ignore_case:a[5]};t["function"]=a[1];var v=Hb(t,b,c),w=!!a[4];return w||2!==v?w!==(1===v):null;default:throw Error("Attempting to expand unknown Value type: "+a[0]+".");}}return a},Hb=function(a,b,c){try{return yb(Eb(a,b,c))}catch(d){JSON.stringify(a)}return 2};var Ib=function(){var a=function(b){return{toString:function(){return b}}};return{qd:a("convert_case_to"),rd:a("convert_false_to"),sd:a("convert_null_to"),td:a("convert_true_to"),ud:a("convert_undefined_to"),rh:a("debug_mode_metadata"),ra:a("function"),Qe:a("instance_name"),Ue:a("live_only"),We:a("malware_disabled"),Xe:a("metadata"),sh:a("original_vendor_template_id"),af:a("once_per_event"),Dd:a("once_per_load"),Ld:a("setup_tags"),Nd:a("tag_id"),Od:a("teardown_tags")}}();var Jb=null,Mb=function(a){function b(q){for(var u=0;u<q.length;u++)d[q[u]]=!0}var c=[],d=[];Jb=Kb(a);for(var e=0;e<sb.length;e++){var f=sb[e],h=Lb(f);if(h){for(var k=f.add||[],l=0;l<k.length;l++)c[k[l]]=!0;b(f.block||[])}else null===h&&b(f.block||[])}for(var m=[],n=0;n<vb.length;n++)c[n]&&!d[n]&&(m[n]=!0);return m},Lb=function(a){for(var b=a["if"]||[],c=0;c<b.length;c++){var d=Jb(b[c]);if(0===d)return!1;if(2===d)return null}for(var e=a.unless||[],f=0;f<e.length;f++){var h=Jb(e[f]);if(2===h)return null;
if(1===h)return!1}return!0},Kb=function(a){var b=[];return function(c){void 0===b[c]&&(b[c]=Hb(tb[c],a));return b[c]}};/*
 Copyright (c) 2014 Derek Brans, MIT license https://github.com/krux/postscribe/blob/master/LICENSE. Portions derived from simplehtmlparser, which is licensed under the Apache License, Version 2.0 */
var D=window,F=document,fc=navigator,gc=F.currentScript&&F.currentScript.src,hc=function(a,b){var c=D[a];D[a]=void 0===c?b:c;return D[a]},ic=function(a,b){b&&(a.addEventListener?a.onload=b:a.onreadystatechange=function(){a.readyState in{loaded:1,complete:1}&&(a.onreadystatechange=null,b())})},jc=function(a,b,c){var d=F.createElement("script");d.type="text/javascript";d.async=!0;d.src=a;ic(d,b);c&&(d.onerror=c);var e;if(null===ma)b:{var f=ja.document,h=f.querySelector&&f.querySelector("script[nonce]");
if(h){var k=h.nonce||h.getAttribute("nonce");if(k&&la.test(k)){ma=k;break b}}ma=""}e=ma;e&&d.setAttribute("nonce",e);var l=F.getElementsByTagName("script")[0]||F.body||F.head;l.parentNode.insertBefore(d,l);return d},kc=function(){if(gc){var a=gc.toLowerCase();if(0===a.indexOf("https://"))return 2;if(0===a.indexOf("http://"))return 3}return 1},lc=function(a,b){var c=F.createElement("iframe");c.height="0";c.width="0";c.style.display="none";c.style.visibility="hidden";var d=F.body&&F.body.lastChild||
F.body||F.head;d.parentNode.insertBefore(c,d);ic(c,b);void 0!==a&&(c.src=a);return c},mc=function(a,b,c){var d=new Image(1,1);d.onload=function(){d.onload=null;b&&b()};d.onerror=function(){d.onerror=null;c&&c()};d.src=a;return d},nc=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,!!d):a.attachEvent&&a.attachEvent("on"+b,c)},oc=function(a,b,c){a.removeEventListener?a.removeEventListener(b,c,!1):a.detachEvent&&a.detachEvent("on"+b,c)},G=function(a){D.setTimeout(a,0)},qc=function(a,b){return a&&
b&&a.attributes&&a.attributes[b]?a.attributes[b].value:null},rc=function(a){var b=a.innerText||a.textContent||"";b&&" "!=b&&(b=b.replace(/^[\s\xa0]+|[\s\xa0]+$/g,""));b&&(b=b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g," "));return b},sc=function(a){var b=F.createElement("div");b.innerHTML="A<div>"+a+"</div>";b=b.lastChild;for(var c=[];b.firstChild;)c.push(b.removeChild(b.firstChild));return c},tc=function(a,b,c){c=c||100;for(var d={},e=0;e<b.length;e++)d[b[e]]=!0;for(var f=a,h=0;f&&h<=c;h++){if(d[String(f.tagName).toLowerCase()])return f;
f=f.parentElement}return null},uc=function(a,b){var c=a[b];c&&"string"===typeof c.animVal&&(c=c.animVal);return c};var wc=function(a){return vc?F.querySelectorAll(a):null},xc=function(a,b){if(!vc)return null;if(Element.prototype.closest)try{return a.closest(b)}catch(e){return null}var c=Element.prototype.matches||Element.prototype.webkitMatchesSelector||Element.prototype.mozMatchesSelector||Element.prototype.msMatchesSelector||Element.prototype.oMatchesSelector,d=a;if(!F.documentElement.contains(d))return null;do{try{if(c.call(d,b))return d}catch(e){break}d=d.parentElement||d.parentNode}while(null!==d&&1===d.nodeType);
return null},yc=!1;if(F.querySelectorAll)try{var zc=F.querySelectorAll(":root");zc&&1==zc.length&&zc[0]==F.documentElement&&(yc=!0)}catch(a){}var vc=yc;var H={qa:"_ee",nc:"event_callback",tb:"event_timeout",D:"gtag.config",X:"allow_ad_personalization_signals",oc:"restricted_data_processing",Qa:"allow_google_signals",Y:"cookie_expires",sb:"cookie_update",Ra:"session_duration",ca:"user_properties"};
H.de=[H.X,H.Qa,H.sb];H.ke=[H.Y,H.tb,H.Ra];var Pc=/[A-Z]+/,Qc=/\s/,Rc=function(a){if(g(a)&&(a=Ea(a),!Qc.test(a))){var b=a.indexOf("-");if(!(0>b)){var c=a.substring(0,b);if(Pc.test(c)){for(var d=a.substring(b+1).split("/"),e=0;e<d.length;e++)if(!d[e])return;return{id:a,prefix:c,containerId:c+"-"+d[0],o:d}}}}},Tc=function(a){for(var b={},c=0;c<a.length;++c){var d=Rc(a[c]);d&&(b[d.id]=d)}Sc(b);var e=[];za(b,function(f,h){e.push(h)});return e};
function Sc(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];"AW"===d.prefix&&d.o[1]&&b.push(d.containerId)}for(var e=0;e<b.length;++e)delete a[b[e]]};var Uc={},Vc=null,Wc=Math.random();Uc.s="GTM-SP2R";Uc.yb="250";var Xc={__cl:!0,__ecl:!0,__ehl:!0,__evl:!0,__fal:!0,__fil:!0,__fsl:!0,__hl:!0,__jel:!0,__lcl:!0,__sdl:!0,__tl:!0,__ytl:!0,__paused:!0,__tg:!0},Zc="www.googletagmanager.com/gtm.js";var $c=Zc,ad=null,bd=null,cd=null,dd="//www.googletagmanager.com/a?id="+Uc.s+"&cv=667",ed={},fd={},gd=function(){var a=Vc.sequence||0;Vc.sequence=a+1;return a};var hd={},I=function(a,b){hd[a]=hd[a]||[];hd[a][b]=!0},id=function(a){for(var b=[],c=hd[a]||[],d=0;d<c.length;d++)c[d]&&(b[Math.floor(d/6)]^=1<<d%6);for(var e=0;e<b.length;e++)b[e]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(b[e]||0);return b.join("")};
var jd=function(){return"&tc="+vb.filter(function(a){return a}).length},md=function(){kd||(kd=D.setTimeout(ld,500))},ld=function(){kd&&(D.clearTimeout(kd),kd=void 0);void 0===nd||od[nd]&&!pd&&!qd||(rd[nd]||sd.og()||0>=td--?(I("GTM",1),rd[nd]=!0):(sd.Sg(),mc(ud()),od[nd]=!0,vd=wd=qd=pd=""))},ud=function(){var a=nd;if(void 0===a)return"";var b=id("GTM"),c=id("TAGGING");return[xd,od[a]?"":"&es=1",yd[a],b?"&u="+b:"",c?"&ut="+c:"",jd(),pd,qd,wd,vd,"&z=0"].join("")},zd=function(){return[dd,"&v=3&t=t","&pid="+
wa(),"&rv="+Uc.yb].join("")},Ad="0.005000">Math.random(),xd=zd(),Bd=function(){xd=zd()},od={},pd="",qd="",vd="",wd="",nd=void 0,yd={},rd={},kd=void 0,sd=function(a,b){var c=0,d=0;return{og:function(){if(c<a)return!1;Fa()-d>=b&&(c=0);return c>=a},Sg:function(){Fa()-d>=b&&(c=0);c++;d=Fa()}}}(2,1E3),td=1E3,Cd=function(a,b){if(Ad&&!rd[a]&&nd!==a){ld();nd=a;vd=pd="";var c;c=0===b.indexOf("gtm.")?encodeURIComponent(b):"*";yd[a]="&e="+c+"&eid="+a;md()}},Dd=function(a,b,c){if(Ad&&!rd[a]&&
b){a!==nd&&(ld(),nd=a);var d,e=String(b[Ib.ra]||"").replace(/_/g,"");0===e.indexOf("cvt")&&(e="cvt");d=e;var f=c+d;pd=pd?pd+"."+f:"&tr="+f;var h=b["function"];if(!h)throw Error("Error: No function name given for function call.");var k=(xb[h]?"1":"2")+d;vd=vd?vd+"."+k:"&ti="+k;md();2022<=ud().length&&ld()}},Ed=function(a,b,c){if(Ad&&!rd[a]){a!==nd&&(ld(),nd=a);var d=c+b;qd=qd?qd+
"."+d:"&epr="+d;md();2022<=ud().length&&ld()}};var Fd={},Gd=new xa,Hd={},Id={},Ld={name:"dataLayer",set:function(a,b){B(La(a,b),Hd);Jd()},get:function(a){return Kd(a,2)},reset:function(){Gd=new xa;Hd={};Jd()}},Kd=function(a,b){if(2!=b){var c=Gd.get(a);if(Ad){var d=Md(a);c!==d&&I("GTM",5)}return c}return Md(a)},Md=function(a,b,c){var d=a.split("."),e=!1,f=void 0;return e?f:Od(d)},Od=function(a){for(var b=Hd,c=0;c<a.length;c++){if(null===b)return!1;if(void 0===b)break;b=b[a[c]]}return b};
var Qd=function(a,b){Id.hasOwnProperty(a)||(Gd.set(a,b),B(La(a,b),Hd),Jd())},Jd=function(a){za(Id,function(b,c){Gd.set(b,c);B(La(b,void 0),Hd);B(La(b,c),Hd);a&&delete Id[b]})},Rd=function(a,b,c){Fd[a]=Fd[a]||{};var d=1!==c?Md(b):Gd.get(b);"array"===Pa(d)||"object"===Pa(d)?Fd[a][b]=B(d):Fd[a][b]=d},Sd=function(a,b){if(Fd[a])return Fd[a][b]},Td=function(a,b){Fd[a]&&delete Fd[a][b]};var Ud=function(){var a=!1;return a};var Q=function(a,b,c,d){return(2===Vd()||d||"http:"!=D.location.protocol?a:b)+c},Vd=function(){var a=kc(),b;if(1===a)a:{var c=$c;c=c.toLowerCase();for(var d="https://"+c,e="http://"+c,f=1,h=F.getElementsByTagName("script"),k=0;k<h.length&&100>k;k++){var l=h[k].src;if(l){l=l.toLowerCase();if(0===l.indexOf(e)){b=3;break a}1===f&&0===l.indexOf(d)&&(f=2)}}b=f}else b=a;return b};var je=new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),ke={cl:["ecl"],customPixels:["nonGooglePixels"],ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],customScripts:["html","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],nonGooglePixels:[],nonGoogleScripts:["nonGooglePixels"],nonGoogleIframes:["nonGooglePixels"]},le={cl:["ecl"],customPixels:["customScripts","html"],
ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts"],customScripts:["html"],nonGooglePixels:["customPixels","customScripts","html","nonGoogleScripts","nonGoogleIframes"],nonGoogleScripts:["customScripts","html"],nonGoogleIframes:["customScripts","html","nonGoogleScripts"]},me="google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");
var oe=function(a){var b=Kd("gtm.whitelist");b&&I("GTM",9);var c=b&&Ka(Ca(b),ke),d=Kd("gtm.blacklist");d||(d=Kd("tagTypeBlacklist"))&&I("GTM",3);d?
I("GTM",8):d=[];ne()&&(d=Ca(d),d.push("nonGooglePixels","nonGoogleScripts","sandboxedScripts"));0<=r(Ca(d),"google")&&I("GTM",2);var e=d&&Ka(Ca(d),le),f={};return function(h){var k=h&&h[Ib.ra];if(!k||"string"!=typeof k)return!0;k=k.replace(/^_*/,"");if(void 0!==f[k])return f[k];var l=fd[k]||[],m=a(k,l);if(b){var n;if(n=m)a:{if(0>r(c,k))if(l&&0<l.length)for(var q=0;q<
l.length;q++){if(0>r(c,l[q])){I("GTM",11);n=!1;break a}}else{n=!1;break a}n=!0}m=n}var u=!1;if(d){var p=0<=r(e,k);if(p)u=p;else{var t=ya(e,l||[]);t&&I("GTM",10);u=t}}var v=!m||u;v||!(0<=r(l,"sandboxedScripts"))||c&&-1!==r(c,"sandboxedScripts")||(v=ya(e,me));return f[k]=v}},ne=function(){return je.test(D.location&&D.location.hostname)};var pe={Mf:function(a,b){b[Ib.qd]&&"string"===typeof a&&(a=1==b[Ib.qd]?a.toLowerCase():a.toUpperCase());b.hasOwnProperty(Ib.sd)&&null===a&&(a=b[Ib.sd]);b.hasOwnProperty(Ib.ud)&&void 0===a&&(a=b[Ib.ud]);b.hasOwnProperty(Ib.td)&&!0===a&&(a=b[Ib.td]);b.hasOwnProperty(Ib.rd)&&!1===a&&(a=b[Ib.rd]);return a}};var qe={active:!0,isWhitelisted:function(){return!0}},re=function(a){var b=Vc.zones;!b&&a&&(b=Vc.zones=a());return b};var se=function(){};var te=!1,ue=0,ve=[];function we(a){if(!te){var b=F.createEventObject,c="complete"==F.readyState,d="interactive"==F.readyState;if(!a||"readystatechange"!=a.type||c||!b&&d){te=!0;for(var e=0;e<ve.length;e++)G(ve[e])}ve.push=function(){for(var f=0;f<arguments.length;f++)G(arguments[f]);return 0}}}function xe(){if(!te&&140>ue){ue++;try{F.documentElement.doScroll("left"),we()}catch(a){D.setTimeout(xe,50)}}}var ye=function(a){te?a():ve.push(a)};var ze={},Ae={},Be=function(a,b,c,d){if(!Ae[a]||Xc[b]||"__zone"===b)return-1;var e={};Ra(d)&&(e=B(d,e));e.id=c;e.status="timeout";return Ae[a].tags.push(e)-1},Ce=function(a,b,c,d){if(Ae[a]){var e=Ae[a].tags[b];e&&(e.status=c,e.executionTime=d)}};function De(a){for(var b=ze[a]||[],c=0;c<b.length;c++)b[c]();ze[a]={push:function(d){d(Uc.s,Ae[a])}}}
var Ge=function(a,b,c){Ae[a]={tags:[]};qa(b)&&Ee(a,b);c&&D.setTimeout(function(){return De(a)},Number(c));return Fe(a)},Ee=function(a,b){ze[a]=ze[a]||[];ze[a].push(Ha(function(){return G(function(){b(Uc.s,Ae[a])})}))};function Fe(a){var b=0,c=0,d=!1;return{add:function(){c++;return Ha(function(){b++;d&&b>=c&&De(a)})},yf:function(){d=!0;b>=c&&De(a)}}};var He=function(){function a(d){return!ra(d)||0>d?0:d}if(!Vc._li&&D.performance&&D.performance.timing){var b=D.performance.timing.navigationStart,c=ra(Ld.get("gtm.start"))?Ld.get("gtm.start"):0;Vc._li={cst:a(c-b),cbt:a(bd-b)}}};var Le={},Me=function(){return D.GoogleAnalyticsObject&&D[D.GoogleAnalyticsObject]},Ne=!1;
var Oe=function(a){D.GoogleAnalyticsObject||(D.GoogleAnalyticsObject=a||"ga");var b=D.GoogleAnalyticsObject;if(D[b])D.hasOwnProperty(b)||I("GTM",12);else{var c=function(){c.q=c.q||[];c.q.push(arguments)};c.l=Number(new Date);D[b]=c}He();return D[b]},Pe=function(a,b,c,d){b=String(b).replace(/\s+/g,"").split(",");var e=Me();e(a+"require","linker");e(a+"linker:autoLink",b,c,d)};
var Re=function(a){},Qe=function(){return D.GoogleAnalyticsObject||"ga"};var Te=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;var Ue=/:[0-9]+$/,Ve=function(a,b,c){for(var d=a.split("&"),e=0;e<d.length;e++){var f=d[e].split("=");if(decodeURIComponent(f[0]).replace(/\+/g," ")===b){var h=f.slice(1).join("=");return c?h:decodeURIComponent(h).replace(/\+/g," ")}}},Ye=function(a,b,c,d,e){b&&(b=String(b).toLowerCase());if("protocol"===b||"port"===b)a.protocol=We(a.protocol)||We(D.location.protocol);"port"===b?a.port=String(Number(a.hostname?a.port:D.location.port)||("http"==a.protocol?80:"https"==a.protocol?443:"")):"host"===b&&
(a.hostname=(a.hostname||D.location.hostname).replace(Ue,"").toLowerCase());var f=b,h,k=We(a.protocol);f&&(f=String(f).toLowerCase());switch(f){case "url_no_fragment":h=Xe(a);break;case "protocol":h=k;break;case "host":h=a.hostname.replace(Ue,"").toLowerCase();if(c){var l=/^www\d*\./.exec(h);l&&l[0]&&(h=h.substr(l[0].length))}break;case "port":h=String(Number(a.port)||("http"==k?80:"https"==k?443:""));break;case "path":a.pathname||a.hostname||I("TAGGING",1);h="/"==a.pathname.substr(0,1)?a.pathname:
"/"+a.pathname;var m=h.split("/");0<=r(d||[],m[m.length-1])&&(m[m.length-1]="");h=m.join("/");break;case "query":h=a.search.replace("?","");e&&(h=Ve(h,e,void 0));break;case "extension":var n=a.pathname.split(".");h=1<n.length?n[n.length-1]:"";h=h.split("/")[0];break;case "fragment":h=a.hash.replace("#","");break;default:h=a&&a.href}return h},We=function(a){return a?a.replace(":","").toLowerCase():""},Xe=function(a){var b="";if(a&&a.href){var c=a.href.indexOf("#");b=0>c?a.href:a.href.substr(0,c)}return b},
Ze=function(a){var b=F.createElement("a");a&&(b.href=a);var c=b.pathname;"/"!==c[0]&&(a||I("TAGGING",1),c="/"+c);var d=b.hostname.replace(Ue,"");return{href:b.href,protocol:b.protocol,host:b.host,hostname:d,pathname:c,search:b.search,hash:b.hash,port:b.port}};function df(a,b,c,d){var e=vb[a],f=ef(a,b,c,d);if(!f)return null;var h=Db(e[Ib.Ld],c,[]);if(h&&h.length){var k=h[0];f=df(k.index,{B:f,w:1===k.fe?b.terminate:f,terminate:b.terminate},c,d)}return f}
function ef(a,b,c,d){function e(){if(f[Ib.We])k();else{var w=Eb(f,c,[]),y=Be(c.id,String(f[Ib.ra]),Number(f[Ib.Nd]),w[Ib.Xe]),x=!1;w.vtp_gtmOnSuccess=function(){if(!x){x=!0;var A=Fa()-C;Dd(c.id,vb[a],"5");Ce(c.id,y,"success",A);h()}};w.vtp_gtmOnFailure=function(){if(!x){x=!0;var A=Fa()-C;Dd(c.id,vb[a],"6");Ce(c.id,y,"failure",A);k()}};w.vtp_gtmTagId=f.tag_id;
w.vtp_gtmEventId=c.id;Dd(c.id,f,"1");var z=function(){var A=Fa()-C;Dd(c.id,f,"7");Ce(c.id,y,"exception",A);x||(x=!0,k())};var C=Fa();try{Cb(w,c)}catch(A){z(A)}}}var f=vb[a],h=b.B,k=b.w,l=b.terminate;if(c.Lc(f))return null;var m=Db(f[Ib.Od],c,[]);if(m&&m.length){var n=m[0],q=df(n.index,{B:h,w:k,terminate:l},c,d);if(!q)return null;h=q;k=2===n.fe?l:q}if(f[Ib.Dd]||f[Ib.af]){var u=f[Ib.Dd]?wb:c.ah,p=h,t=k;if(!u[a]){e=Ha(e);var v=ff(a,u,e);h=v.B;k=v.w}return function(){u[a](p,t)}}return e}
function ff(a,b,c){var d=[],e=[];b[a]=gf(d,e,c);return{B:function(){b[a]=hf;for(var f=0;f<d.length;f++)d[f]()},w:function(){b[a]=jf;for(var f=0;f<e.length;f++)e[f]()}}}function gf(a,b,c){return function(d,e){a.push(d);b.push(e);c()}}function hf(a){a()}function jf(a,b){b()};var mf=function(a,b){for(var c=[],d=0;d<vb.length;d++)if(a.kb[d]){var e=vb[d];var f=b.add();try{var h=df(d,{B:f,w:f,terminate:f},a,d);h?c.push({Ee:d,ze:Fb(e),Xf:h}):(kf(d,a),f())}catch(l){f()}}b.yf();c.sort(lf);for(var k=0;k<c.length;k++)c[k].Xf();return 0<c.length};function lf(a,b){var c,d=b.ze,e=a.ze;c=d>e?1:d<e?-1:0;var f;if(0!==c)f=c;else{var h=a.Ee,k=b.Ee;f=h>k?1:h<k?-1:0}return f}
function kf(a,b){if(!Ad)return;var c=function(d){var e=b.Lc(vb[d])?"3":"4",f=Db(vb[d][Ib.Ld],b,[]);f&&f.length&&c(f[0].index);Dd(b.id,vb[d],e);var h=Db(vb[d][Ib.Od],b,[]);h&&h.length&&c(h[0].index)};c(a);}
var nf=!1,of=function(a,b,c,d,e){if("gtm.js"==b){if(nf)return!1;nf=!0}Cd(a,b);var f=Ge(a,d,e);Rd(a,"event",1);Rd(a,"ecommerce",1);Rd(a,"gtm");var h={id:a,name:b,Lc:oe(c),kb:[],ah:[],te:function(){I("GTM",6)}};h.kb=Mb(h);var k=mf(h,f);"gtm.js"!==b&&"gtm.sync"!==b||Re(Uc.s);if(!k)return k;for(var l=0;l<h.kb.length;l++)if(h.kb[l]){var m=vb[l];if(m&&!Xc[String(m[Ib.ra])])return!0}return!1};var qf=/^https?:\/\/www\.googletagmanager\.com/;function rf(){var a;return a}function tf(a,b){}
function sf(a){0!==a.indexOf("http://")&&0!==a.indexOf("https://")&&(a="https://"+a);"/"===a[a.length-1]&&(a=a.substring(0,a.length-1));return a}function uf(){var a=!1;return a};var vf=function(){this.eventModel={};this.targetConfig={};this.containerConfig={};this.h={};this.globalConfig={};this.B=function(){};this.w=function(){}},wf=function(a){var b=new vf;b.eventModel=a;return b},xf=function(a,b){a.targetConfig=b;return a},yf=function(a,b){a.containerConfig=b;return a},zf=function(a,b){a.h=b;return a},Af=function(a,b){a.globalConfig=b;return a},Bf=function(a,b){a.B=b;return a},Cf=function(a,b){a.w=b;return a};
vf.prototype.getWithConfig=function(a){if(void 0!==this.eventModel[a])return this.eventModel[a];if(void 0!==this.targetConfig[a])return this.targetConfig[a];if(void 0!==this.containerConfig[a])return this.containerConfig[a];if(void 0!==this.h[a])return this.h[a];if(void 0!==this.globalConfig[a])return this.globalConfig[a]};
var Df=function(a){function b(e){za(e,function(f){c[f]=null})}var c={};b(a.eventModel);b(a.targetConfig);b(a.containerConfig);b(a.globalConfig);var d=[];za(c,function(e){d.push(e)});return d};var Ef={},Ff=["G"];Ef.Fe="";var Gf=Ef.Fe.split(",");function Hf(){var a=Vc;return a.gcq=a.gcq||new If}
var Jf=function(a,b,c){Hf().register(a,b,c)},Kf=function(a,b,c,d){Hf().push("event",[b,a],c,d)},Lf=function(a,b){Hf().push("config",[a],b)},Mf={},Nf=function(){this.status=1;this.containerConfig={};this.targetConfig={};this.i={};this.m=null;this.h=!1},Of=function(a,b,c,d,e){this.type=a;this.m=b;this.N=c||"";this.h=d;this.i=e},If=function(){this.i={};this.m={};this.h=[]},Pf=function(a,b){var c=Rc(b);return a.i[c.containerId]=a.i[c.containerId]||new Nf},Qf=function(a,b,c,d){if(d.N){var e=Pf(a,d.N),
f=e.m;if(f){var h=B(c),k=B(e.targetConfig[d.N]),l=B(e.containerConfig),m=B(e.i),n=B(a.m),q=Kd("gtm.uniqueEventId"),u=Rc(d.N).prefix,p=Cf(Bf(Af(zf(yf(xf(wf(h),k),l),m),n),function(){Ed(q,u,"2");}),function(){Ed(q,u,"3");});try{Ed(q,u,"1");f(d.N,b,d.m,p)}catch(t){
Ed(q,u,"4");}}}};
If.prototype.register=function(a,b,c){if(3!==Pf(this,a).status){Pf(this,a).m=b;Pf(this,a).status=3;c&&(Pf(this,a).i=c);var d=Rc(a),e=Mf[d.containerId];if(void 0!==e){var f=Vc[d.containerId].bootstrap,h=d.prefix.toUpperCase();Vc[d.containerId]._spx&&(h=h.toLowerCase());var k=Kd("gtm.uniqueEventId"),l=h,m=Fa()-f;if(Ad&&!rd[k]){k!==nd&&(ld(),nd=k);var n=l+"."+Math.floor(f-e)+"."+Math.floor(m);wd=wd?wd+","+n:"&cl="+n}delete Mf[d.containerId]}this.flush()}};
If.prototype.push=function(a,b,c,d){var e=Math.floor(Fa()/1E3);if(c){var f=Rc(c),h;if(h=f){var k;if(k=1===Pf(this,c).status)a:{var l=f.prefix;k=!0}h=k}if(h&&(Pf(this,c).status=2,this.push("require",[],f.containerId),Mf[f.containerId]=Fa(),!Ud())){var m=encodeURIComponent(f.containerId),n=("http:"!=D.location.protocol?"https:":"http:")+
"//www.googletagmanager.com";jc(n+"/gtag/js?id="+m+"&l=dataLayer&cx=c")}}this.h.push(new Of(a,e,c,b,d));d||this.flush()};
If.prototype.flush=function(a){for(var b=this;this.h.length;){var c=this.h[0];if(c.i)c.i=!1,this.h.push(c);else switch(c.type){case "require":if(3!==Pf(this,c.N).status&&!a)return;break;case "set":za(c.h[0],function(l,m){B(La(l,m),b.m)});break;case "config":var d=c.h[0],e=!!d[H.Qb];delete d[H.Qb];var f=Pf(this,c.N),h=Rc(c.N),k=h.containerId===h.id;e||(k?f.containerConfig={}:f.targetConfig[c.N]={});f.h&&e||Qf(this,H.D,d,c);f.h=!0;delete d[H.qa];k?B(d,f.containerConfig):B(d,f.targetConfig[c.N]);break;
case "event":Qf(this,c.h[1],c.h[0],c)}this.h.shift()}};var Rf=function(a,b,c){for(var d=[],e=String(b||document.cookie).split(";"),f=0;f<e.length;f++){var h=e[f].split("="),k=h[0].replace(/^\s*|\s*$/g,"");if(k&&k==a){var l=h.slice(1).join("=").replace(/^\s*|\s*$/g,"");l&&c&&(l=decodeURIComponent(l));d.push(l)}}return d},Uf=function(a,b,c,d){var e=Sf(a,d);if(1===e.length)return e[0].id;if(0!==e.length){e=Tf(e,function(f){return f.Jb},b);if(1===e.length)return e[0].id;e=Tf(e,function(f){return f.lb},c);return e[0]?e[0].id:void 0}};
function Vf(a,b,c){var d=document.cookie;document.cookie=a;var e=document.cookie;return d!=e||void 0!=c&&0<=Rf(b,e).indexOf(c)}
var Zf=function(a,b,c,d,e,f){d=d||"auto";var h={path:c||"/"};e&&(h.expires=e);"none"!==d&&(h.domain=d);var k;a:{var l=b,m;if(void 0==l)m=a+"=deleted; expires="+(new Date(0)).toUTCString();else{f&&(l=encodeURIComponent(l));var n=l;n&&1200<n.length&&(n=n.substring(0,1200));l=n;m=a+"="+l}var q=void 0,u=void 0,p;for(p in h)if(h.hasOwnProperty(p)){var t=h[p];if(null!=t)switch(p){case "secure":t&&(m+="; secure");break;case "domain":q=t;break;default:"path"==p&&(u=t),"expires"==p&&t instanceof Date&&(t=
t.toUTCString()),m+="; "+p+"="+t}}if("auto"===q){for(var v=Wf(),w=0;w<v.length;++w){var y="none"!=v[w]?v[w]:void 0;if(!Yf(y,u)&&Vf(m+(y?"; domain="+y:""),a,l)){k=!0;break a}}k=!1}else q&&"none"!=q&&(m+="; domain="+q),k=!Yf(q,u)&&Vf(m,a,l)}return k};function Tf(a,b,c){for(var d=[],e=[],f,h=0;h<a.length;h++){var k=a[h],l=b(k);l===c?d.push(k):void 0===f||l<f?(e=[k],f=l):l===f&&e.push(k)}return 0<d.length?d:e}
function Sf(a,b){for(var c=[],d=Rf(a),e=0;e<d.length;e++){var f=d[e].split("."),h=f.shift();if(!b||-1!==b.indexOf(h)){var k=f.shift();k&&(k=k.split("-"),c.push({id:f.join("."),Jb:1*k[0]||1,lb:1*k[1]||1}))}}return c}
var $f=/^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,ag=/(^|\.)doubleclick\.net$/i,Yf=function(a,b){return ag.test(document.location.hostname)||"/"===b&&$f.test(a)},Wf=function(){var a=[],b=document.location.hostname.split(".");if(4===b.length){var c=b[b.length-1];if(parseInt(c,10).toString()===c)return["none"]}for(var d=b.length-2;0<=d;d--)a.push(b.slice(d).join("."));var e=document.location.hostname;ag.test(e)||$f.test(e)||a.push("none");return a};var bg="G".split(/,/),cg=!1;cg=!0;var dg=null,eg={},fg={},gg;function hg(a,b){var c={event:a};b&&(c.eventModel=B(b),b[H.nc]&&(c.eventCallback=b[H.nc]),b[H.tb]&&(c.eventTimeout=b[H.tb]));return c}
var ng={config:function(a){},
event:function(a){var b=a[1];if(g(b)&&!(3<a.length)){var c;if(2<a.length){if(!Ra(a[2])&&void 0!=a[2])return;c=a[2]}var d=hg(b,c);return d}},js:function(a){if(2==a.length&&a[1].getTime)return{event:"gtm.js","gtm.start":a[1].getTime()}},policy:function(){},set:function(a){var b;2==a.length&&Ra(a[1])?b=B(a[1]):3==a.length&&g(a[1])&&(b={},Ra(a[2])||ua(a[2])?b[a[1]]=B(a[2]):b[a[1]]=a[2]);
if(b){b._clear=!0;return b}}},og={policy:!0};var pg=function(a,b){var c=a.hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;for(e in c)if(c.hasOwnProperty(e)&&!0===c[e]){d=!1;break}d&&(c.end(),c.end=null)}},rg=function(a){var b=qg(),c=b&&b.hide;c&&c.end&&(c[a]=!0)};var sg=!1,tg=[];function ug(){if(!sg){sg=!0;for(var a=0;a<tg.length;a++)G(tg[a])}}var vg=function(a){sg?G(a):tg.push(a)};var Kg=function(a){if(Jg(a))return a;this.h=a};Kg.prototype.dg=function(){return this.h};var Jg=function(a){return!a||"object"!==Pa(a)||Ra(a)?!1:"getUntrustedUpdateValue"in a};Kg.prototype.getUntrustedUpdateValue=Kg.prototype.dg;var Lg=[],Mg=!1,Ng=function(a){return D["dataLayer"].push(a)},Og=function(a){var b=Vc["dataLayer"],c=b?b.subscribers:1,d=0;return function(){++d===c&&a()}};
function Pg(a){var b=a._clear;za(a,function(f,h){"_clear"!==f&&(b&&Qd(f,void 0),Qd(f,h))});ad||(ad=a["gtm.start"]);var c=a.event;if(!c)return!1;var d=a["gtm.uniqueEventId"];d||(d=gd(),a["gtm.uniqueEventId"]=d,Qd("gtm.uniqueEventId",d));cd=c;var e=
Qg(a);cd=null;switch(c){case "gtm.init":I("GTM",19),e&&I("GTM",20)}return e}function Qg(a){var b=a.event,c=a["gtm.uniqueEventId"],d,e=Vc.zones;d=e?e.checkState(Uc.s,c):qe;return d.active?of(c,b,d.isWhitelisted,a.eventCallback,a.eventTimeout)?!0:!1:!1}
function Rg(){for(var a=!1;!Mg&&0<Lg.length;){Mg=!0;delete Hd.eventModel;Jd();var b=Lg.shift();if(null!=b){var c=Jg(b);if(c){var d=b;b=Jg(d)?d.getUntrustedUpdateValue():void 0;for(var e=["gtm.whitelist","gtm.blacklist","tagTypeBlacklist"],f=0;f<e.length;f++){var h=e[f],k=Kd(h,1);if(ua(k)||Ra(k))k=B(k);Id[h]=k}}try{if(qa(b))try{b.call(Ld)}catch(v){}else if(ua(b)){var l=b;if(g(l[0])){var m=
l[0].split("."),n=m.pop(),q=l.slice(1),u=Kd(m.join("."),2);if(void 0!==u&&null!==u)try{u[n].apply(u,q)}catch(v){}}}else{var p=b;if(p&&("[object Arguments]"==Object.prototype.toString.call(p)||Object.prototype.hasOwnProperty.call(p,"callee"))){a:{if(b.length&&g(b[0])){var t=ng[b[0]];if(t&&(!c||!og[b[0]])){b=t(b);break a}}b=void 0}if(!b){Mg=!1;continue}}a=Pg(b)||a}}finally{c&&Jd(!0)}}Mg=!1}
return!a}function Sg(){var a=Rg();try{pg(D["dataLayer"],Uc.s)}catch(b){}return a}
var Ug=function(){var a=hc("dataLayer",[]),b=hc("google_tag_manager",{});b=b["dataLayer"]=b["dataLayer"]||{};ye(function(){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))});vg(function(){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))});b.subscribers=(b.subscribers||0)+1;var c=a.push;a.push=function(){var d;if(0<Vc.SANDBOXED_JS_SEMAPHORE){d=[];for(var e=0;e<arguments.length;e++)d[e]=new Kg(arguments[e])}else d=[].slice.call(arguments,0);var f=c.apply(a,d);Lg.push.apply(Lg,d);if(300<
this.length)for(I("GTM",4);300<this.length;)this.shift();var h="boolean"!==typeof f||f;return Rg()&&h};Lg.push.apply(Lg,a.slice(0));Tg()&&G(Sg)},Tg=function(){var a=!0;return a};var Vg={};Vg.ub=new String("undefined");
var Wg=function(a){this.h=function(b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]===Vg.ub?b:a[d]);return c.join("")}};Wg.prototype.toString=function(){return this.h("undefined")};Wg.prototype.valueOf=Wg.prototype.toString;Vg.jf=Wg;Vg.xc={};Vg.Pf=function(a){return new Wg(a)};var Xg={};Vg.Tg=function(a,b){var c=gd();Xg[c]=[a,b];return c};Vg.be=function(a){var b=a?0:1;return function(c){var d=Xg[c];if(d&&"function"===typeof d[b])d[b]();Xg[c]=void 0}};Vg.mg=function(a){for(var b=!1,c=!1,d=2;d<a.length;d++)b=
b||8===a[d],c=c||16===a[d];return b&&c};Vg.Jg=function(a){if(a===Vg.ub)return a;var b=gd();Vg.xc[b]=a;return'google_tag_manager["'+Uc.s+'"].macro('+b+")"};Vg.xg=function(a,b,c){a instanceof Vg.jf&&(a=a.h(Vg.Tg(b,c)),b=pa);return{Jc:a,B:b}};var Yg=function(a,b,c){function d(f,h){var k=f[h];return k}var e={event:b,"gtm.element":a,"gtm.elementClasses":d(a,"className"),"gtm.elementId":a["for"]||qc(a,"id")||"","gtm.elementTarget":a.formTarget||d(a,"target")||""};c&&(e["gtm.triggers"]=c.join(","));e["gtm.elementUrl"]=(a.attributes&&a.attributes.formaction?a.formAction:"")||a.action||d(a,"href")||a.src||a.code||a.codebase||
"";return e},Zg=function(a){Vc.hasOwnProperty("autoEventsSettings")||(Vc.autoEventsSettings={});var b=Vc.autoEventsSettings;b.hasOwnProperty(a)||(b[a]={});return b[a]},$g=function(a,b,c){Zg(a)[b]=c},ah=function(a,b,c,d){var e=Zg(a),f=Ga(e,b,d);e[b]=c(f)},bh=function(a,b,c){var d=Zg(a);return Ga(d,b,c)};function ch(){for(var a=dh,b={},c=0;c<a.length;++c)b[a[c]]=c;return b}function eh(){var a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";a+=a.toLowerCase()+"0123456789-_";return a+"."}var dh,fh;function gh(a){dh=dh||eh();fh=fh||ch();for(var b=[],c=0;c<a.length;c+=3){var d=c+1<a.length,e=c+2<a.length,f=a.charCodeAt(c),h=d?a.charCodeAt(c+1):0,k=e?a.charCodeAt(c+2):0,l=f>>2,m=(f&3)<<4|h>>4,n=(h&15)<<2|k>>6,q=k&63;e||(q=64,d||(n=64));b.push(dh[l],dh[m],dh[n],dh[q])}return b.join("")}
function hh(a){function b(l){for(;d<a.length;){var m=a.charAt(d++),n=fh[m];if(null!=n)return n;if(!/^[\s\xa0]*$/.test(m))throw Error("Unknown base64 encoding at char: "+m);}return l}dh=dh||eh();fh=fh||ch();for(var c="",d=0;;){var e=b(-1),f=b(0),h=b(64),k=b(64);if(64===k&&-1===e)return c;c+=String.fromCharCode(e<<2|f>>4);64!=h&&(c+=String.fromCharCode(f<<4&240|h>>2),64!=k&&(c+=String.fromCharCode(h<<6&192|k)))}};var ih;var mh=function(){var a=jh,b=kh,c=lh(),d=function(h){a(h.target||h.srcElement||{})},e=function(h){b(h.target||h.srcElement||{})};if(!c.init){nc(F,"mousedown",d);nc(F,"keyup",d);nc(F,"submit",e);var f=HTMLFormElement.prototype.submit;HTMLFormElement.prototype.submit=function(){b(this);f.call(this)};c.init=!0}},nh=function(a,b,c){for(var d=lh().decorators,e={},f=0;f<d.length;++f){var h=d[f],k;if(k=!c||h.forms)a:{var l=h.domains,m=a;if(l&&(h.sameHost||m!==F.location.hostname))for(var n=0;n<l.length;n++)if(l[n]instanceof
RegExp){if(l[n].test(m)){k=!0;break a}}else if(0<=m.indexOf(l[n])){k=!0;break a}k=!1}if(k){var q=h.placement;void 0==q&&(q=h.fragment?2:1);q===b&&Ia(e,h.callback())}}return e},lh=function(){var a=hc("google_tag_data",{}),b=a.gl;b&&b.decorators||(b={decorators:[]},a.gl=b);return b};var oh=/(.*?)\*(.*?)\*(.*)/,ph=/^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,qh=/^(?:www\.|m\.|amp\.)+/,rh=/([^?#]+)(\?[^#]*)?(#.*)?/;function sh(a){return new RegExp("(.*?)(^|&)"+a+"=([^&]*)&?(.*)")}
var uh=function(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];void 0!==d&&d===d&&null!==d&&"[object Object]"!==d.toString()&&(b.push(c),b.push(gh(String(d))))}var e=b.join("*");return["1",th(e),e].join("*")},th=function(a,b){var c=[window.navigator.userAgent,(new Date).getTimezoneOffset(),window.navigator.userLanguage||window.navigator.language,Math.floor((new Date).getTime()/60/1E3)-(void 0===b?0:b),a].join("*"),d;if(!(d=ih)){for(var e=Array(256),f=0;256>f;f++){for(var h=f,k=0;8>k;k++)h=
h&1?h>>>1^3988292384:h>>>1;e[f]=h}d=e}ih=d;for(var l=4294967295,m=0;m<c.length;m++)l=l>>>8^ih[(l^c.charCodeAt(m))&255];return((l^-1)>>>0).toString(36)},wh=function(){return function(a){var b=Ze(D.location.href),c=b.search.replace("?",""),d=Ve(c,"_gl",!0)||"";a.query=vh(d)||{};var e=Ye(b,"fragment").match(sh("_gl"));a.fragment=vh(e&&e[3]||"")||{}}},xh=function(){var a=wh(),b=lh();b.data||(b.data={query:{},fragment:{}},a(b.data));var c={},d=b.data;d&&(Ia(c,d.query),Ia(c,d.fragment));return c},vh=function(a){var b;
b=void 0===b?3:b;try{if(a){var c;a:{for(var d=a,e=0;3>e;++e){var f=oh.exec(d);if(f){c=f;break a}d=decodeURIComponent(d)}c=void 0}var h=c;if(h&&"1"===h[1]){var k=h[3],l;a:{for(var m=h[2],n=0;n<b;++n)if(m===th(k,n)){l=!0;break a}l=!1}if(l){for(var q={},u=k?k.split("*"):[],p=0;p<u.length;p+=2)q[u[p]]=hh(u[p+1]);return q}}}}catch(t){}};
function yh(a,b,c,d){function e(n){var q=n,u=sh(a).exec(q),p=q;if(u){var t=u[2],v=u[4];p=u[1];v&&(p=p+t+v)}n=p;var w=n.charAt(n.length-1);n&&"&"!==w&&(n+="&");return n+m}d=void 0===d?!1:d;var f=rh.exec(c);if(!f)return"";var h=f[1],k=f[2]||"",l=f[3]||"",m=a+"="+b;d?l="#"+e(l.substring(1)):k="?"+e(k.substring(1));return""+h+k+l}
function zh(a,b){var c="FORM"===(a.tagName||"").toUpperCase(),d=nh(b,1,c),e=nh(b,2,c),f=nh(b,3,c);if(Ja(d)){var h=uh(d);c?Ah("_gl",h,a):Bh("_gl",h,a,!1)}if(!c&&Ja(e)){var k=uh(e);Bh("_gl",k,a,!0)}for(var l in f)if(f.hasOwnProperty(l))a:{var m=l,n=f[l],q=a;if(q.tagName){if("a"===q.tagName.toLowerCase()){Bh(m,n,q,void 0);break a}if("form"===q.tagName.toLowerCase()){Ah(m,n,q);break a}}"string"==typeof q&&yh(m,n,q,void 0)}}
function Bh(a,b,c,d){if(c.href){var e=yh(a,b,c.href,void 0===d?!1:d);Te.test(e)&&(c.href=e)}}
function Ah(a,b,c){if(c&&c.action){var d=(c.method||"").toLowerCase();if("get"===d){for(var e=c.childNodes||[],f=!1,h=0;h<e.length;h++){var k=e[h];if(k.name===a){k.setAttribute("value",b);f=!0;break}}if(!f){var l=F.createElement("input");l.setAttribute("type","hidden");l.setAttribute("name",a);l.setAttribute("value",b);c.appendChild(l)}}else if("post"===d){var m=yh(a,b,c.action);Te.test(m)&&(c.action=m)}}}
var jh=function(a){try{var b;a:{for(var c=a,d=100;c&&0<d;){if(c.href&&c.nodeName.match(/^a(?:rea)?$/i)){b=c;break a}c=c.parentNode;d--}b=null}var e=b;if(e){var f=e.protocol;"http:"!==f&&"https:"!==f||zh(e,e.hostname)}}catch(h){}},kh=function(a){try{if(a.action){var b=Ye(Ze(a.action),"host");zh(a,b)}}catch(c){}},Ch=function(a,b,c,d){mh();var e="fragment"===c?2:1,f={callback:a,domains:b,fragment:2===e,placement:e,forms:!!d,sameHost:!1};lh().decorators.push(f)},Dh=function(){var a=F.location.hostname,
b=ph.exec(F.referrer);if(!b)return!1;var c=b[2],d=b[1],e="";if(c){var f=c.split("/"),h=f[1];e="s"===h?decodeURIComponent(f[2]):decodeURIComponent(h)}else if(d){if(0===d.indexOf("xn--"))return!1;e=d.replace(/-/g,".").replace(/\.\./g,"-")}var k=a.replace(qh,""),l=e.replace(qh,""),m;if(!(m=k===l)){var n="."+l;m=k.substring(k.length-n.length,k.length)===n}return m},Eh=function(a,b){return!1===a?!1:a||b||Dh()};var Fh={};var Gh=/^\w+$/,Hh=/^[\w-]+$/,Ih=/^~?[\w-]+$/,Jh={aw:"_aw",dc:"_dc",gf:"_gf",ha:"_ha",gp:"_gp"};function Kh(a){return a&&"string"==typeof a&&a.match(Gh)?a:"_gcl"}
var Mh=function(){var a=Ze(D.location.href),b=Ye(a,"query",!1,void 0,"gclid"),c=Ye(a,"query",!1,void 0,"gclsrc"),d=Ye(a,"query",!1,void 0,"dclid");if(!b||!c){var e=a.hash.replace("#","");b=b||Ve(e,"gclid",void 0);c=c||Ve(e,"gclsrc",void 0)}return Lh(b,c,d)},Lh=function(a,b,c){var d={},e=function(f,h){d[h]||(d[h]=[]);d[h].push(f)};d.gclid=a;d.gclsrc=b;d.dclid=c;if(void 0!==a&&a.match(Hh))switch(b){case void 0:e(a,"aw");break;case "aw.ds":e(a,"aw");e(a,"dc");break;case "ds":e(a,"dc");break;case "3p.ds":(void 0==
Fh.gtm_3pds?0:Fh.gtm_3pds)&&e(a,"dc");break;case "gf":e(a,"gf");break;case "ha":e(a,"ha");break;case "gp":e(a,"gp")}c&&e(c,"dc");return d},Oh=function(a){var b=Mh();Nh(b,a)};
function Nh(a,b,c){function d(q,u){var p=Ph(q,e);p&&Zf(p,u,h,f,l,!0)}b=b||{};var e=Kh(b.prefix),f=b.domain||"auto",h=b.path||"/",k=void 0==b.Ka?7776E3:b.Ka;c=c||Fa();var l=0==k?void 0:new Date(c+1E3*k),m=Math.round(c/1E3),n=function(q){return["GCL",m,q].join(".")};a.aw&&(!0===b.Lh?d("aw",n("~"+a.aw[0])):d("aw",n(a.aw[0])));a.dc&&d("dc",n(a.dc[0]));a.gf&&d("gf",n(a.gf[0]));a.ha&&d("ha",n(a.ha[0]));a.gp&&d("gp",n(a.gp[0]))}
var Rh=function(a,b,c,d,e){for(var f=xh(),h=Kh(b),k=0;k<a.length;++k){var l=a[k];if(void 0!==Jh[l]){var m=Ph(l,h),n=f[m];if(n){var q=Math.min(Qh(n),Fa()),u;b:{for(var p=q,t=Rf(m,F.cookie),v=0;v<t.length;++v)if(Qh(t[v])>p){u=!0;break b}u=!1}u||Zf(m,n,c,d,0==e?void 0:new Date(q+1E3*(null==e?7776E3:e)),!0)}}}var w={prefix:b,path:c,domain:d};Nh(Lh(f.gclid,f.gclsrc),w)},Ph=function(a,b){var c=Jh[a];if(void 0!==c)return b+c},Qh=function(a){var b=a.split(".");return 3!==b.length||"GCL"!==b[0]?0:1E3*(Number(b[1])||
0)};function Sh(a){var b=a.split(".");if(3==b.length&&"GCL"==b[0]&&b[1])return b[2]}
var Th=function(a,b,c,d,e){if(ua(b)){var f=Kh(e);Ch(function(){for(var h={},k=0;k<a.length;++k){var l=Ph(a[k],f);if(l){var m=Rf(l,F.cookie);m.length&&(h[l]=m.sort()[m.length-1])}}return h},b,c,d)}},Uh=function(a){return a.filter(function(b){return Ih.test(b)})},Vh=function(a,b){for(var c=Kh(b&&b.prefix),d={},e=0;e<a.length;e++)Jh[a[e]]&&(d[a[e]]=Jh[a[e]]);za(d,function(f,h){var k=Rf(c+h,F.cookie);if(k.length){var l=k[0],m=Qh(l),n={};n[f]=[Sh(l)];Nh(n,b,m)}})};var Wh=function(){for(var a=fc.userAgent+(F.cookie||"")+(F.referrer||""),b=a.length,c=D.history.length;0<c;)a+=c--^b++;var d=1,e,f,h;if(a)for(d=0,f=a.length-1;0<=f;f--)h=a.charCodeAt(f),d=(d<<6&268435455)+h+(h<<14),e=d&266338304,d=0!=e?d^e>>21:d;return[Math.round(2147483647*Math.random())^d&2147483647,Math.round(Fa()/1E3)].join(".")},Zh=function(a,b,c,d){var e=Xh(b);return Uf(a,e,Yh(c),d)},$h=function(a,b,c,d){var e=""+Xh(c),f=Yh(d);1<f&&(e+="-"+f);return[b,e,a].join(".")},Xh=function(a){if(!a)return 1;
a=0===a.indexOf(".")?a.substr(1):a;return a.split(".").length},Yh=function(a){if(!a||"/"===a)return 1;"/"!==a[0]&&(a="/"+a);"/"!==a[a.length-1]&&(a+="/");return a.split("/").length-1};var ai=["1"],bi={},fi=function(a,b,c,d){var e=ci(a);bi[e]||di(e,b,c)||(ei(e,Wh(),b,c,d),di(e,b,c))};function ei(a,b,c,d,e){var f=$h(b,"1",d,c);Zf(a,f,c,d,0==e?void 0:new Date(Fa()+1E3*(void 0==e?7776E3:e)))}function di(a,b,c){var d=Zh(a,b,c,ai);d&&(bi[a]=d);return d}function ci(a){return(a||"_gcl")+"_au"};var gi=function(){for(var a=[],b=F.cookie.split(";"),c=/^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/,d=0;d<b.length;d++){var e=b[d].match(c);e&&a.push({dd:e[1],value:e[2]})}var f={};if(!a||!a.length)return f;for(var h=0;h<a.length;h++){var k=a[h].value.split(".");"1"==k[0]&&3==k.length&&k[1]&&(f[a[h].dd]||(f[a[h].dd]=[]),f[a[h].dd].push({timestamp:k[1],$f:k[2]}))}return f};var hi=/^\d+\.fls\.doubleclick\.net$/;function ii(a){var b=Ze(D.location.href),c=Ye(b,"host",!1);if(c&&c.match(hi)){var d=Ye(b,"path").split(a+"=");if(1<d.length)return d[1].split(";")[0].split("?")[0]}}
function ji(a,b){if("aw"==a||"dc"==a){var c=ii("gcl"+a);if(c)return c.split(".")}var d=Kh(b);if("_gcl"==d){var e;e=Mh()[a]||[];if(0<e.length)return e}var f=Ph(a,d),h;if(f){var k=[];if(F.cookie){var l=Rf(f,F.cookie);if(l&&0!=l.length){for(var m=0;m<l.length;m++){var n=Sh(l[m]);n&&-1===r(k,n)&&k.push(n)}h=Uh(k)}else h=k}else h=k}else h=[];return h}
var ki=function(){var a=ii("gac");if(a)return decodeURIComponent(a);var b=gi(),c=[];za(b,function(d,e){for(var f=[],h=0;h<e.length;h++)f.push(e[h].$f);f=Uh(f);f.length&&c.push(d+":"+f.join(","))});return c.join(";")},li=function(a,b,c,d,e){fi(b,c,d,e);var f=bi[ci(b)],h=Mh().dc||[],k=!1;if(f&&0<h.length){var l=Vc.joined_au=Vc.joined_au||{},m=b||"_gcl";if(!l[m])for(var n=0;n<h.length;n++){var q="https://adservice.google.com/ddm/regclk",u=q=q+"?gclid="+h[n]+"&auiddc="+f;fc.sendBeacon&&fc.sendBeacon(u)||mc(u);k=l[m]=
!0}}null==a&&(a=k);if(a&&f){var p=ci(b),t=bi[p];t&&ei(p,t,c,d,e)}};var mi;if(3===Uc.yb.length)mi="g";else{var ni="G";mi=ni}
var oi={"":"n",UA:"u",AW:"a",DC:"d",G:"e",GF:"f",HA:"h",GTM:mi,OPT:"o"},pi=function(a){var b=Uc.s.split("-"),c=b[0].toUpperCase(),d=oi[c]||"i",e=a&&"GTM"===c?b[1]:"OPT"===c?b[1]:"",f;if(3===Uc.yb.length){var h=void 0;f="2"+(h||"w")}else f=
"";return f+d+Uc.yb+e};var ui=["input","select","textarea"],vi=["button","hidden","image","reset","submit"],wi=function(a){var b=a.tagName.toLowerCase();return!va(ui,function(c){return c===b})||"input"===b&&va(vi,function(c){return c===a.type.toLowerCase()})?!1:!0},xi=function(a){return a.form?a.form.tagName?a.form:F.getElementById(a.form):tc(a,["form"],100)},yi=function(a,b,c){if(!a.elements)return 0;for(var d=b.getAttribute(c),e=0,f=1;e<a.elements.length;e++){var h=a.elements[e];if(wi(h)){if(h.getAttribute(c)===d)return f;
f++}}return 0};var Bi=!!D.MutationObserver,Ci=void 0,Di=function(a){if(!Ci){var b=function(){var c=F.body;if(c)if(Bi)(new MutationObserver(function(){for(var e=0;e<Ci.length;e++)G(Ci[e])})).observe(c,{childList:!0,subtree:!0});else{var d=!1;nc(c,"DOMNodeInserted",function(){d||(d=!0,G(function(){d=!1;for(var e=0;e<Ci.length;e++)G(Ci[e])}))})}};Ci=[];F.body?b():G(b)}Ci.push(a)};var Zi=D.clearTimeout,$i=D.setTimeout,R=function(a,b,c){if(Ud()){b&&G(b)}else return jc(a,b,c)},aj=function(){return D.location.href},bj=function(a){return Ye(Ze(a),"fragment")},cj=function(a){return Xe(Ze(a))},U=function(a,b){return Kd(a,b||2)},dj=function(a,b,c){var d;b?(a.eventCallback=b,c&&(a.eventTimeout=c),d=Ng(a)):d=Ng(a);return d},ej=function(a,b){D[a]=b},X=function(a,b,c){b&&(void 0===D[a]||c&&!D[a])&&(D[a]=
b);return D[a]},fj=function(a,b,c){return Rf(a,b,void 0===c?!0:!!c)},gj=function(a,b){if(Ud()){b&&G(b)}else lc(a,b)},hj=function(a){return!!bh(a,"init",!1)},ij=function(a){$g(a,"init",!0)},jj=function(a,b){var c=(void 0===b?0:b)?"www.googletagmanager.com/gtag/js":$c;c+="?id="+encodeURIComponent(a)+"&l=dataLayer";R(Q("https://","http://",c))},kj=function(a,b){var c=a[b];return c};
var lj=Vg.xg;var mj;var Jj=new xa;function Kj(a,b){function c(h){var k=Ze(h),l=Ye(k,"protocol"),m=Ye(k,"host",!0),n=Ye(k,"port"),q=Ye(k,"path").toLowerCase().replace(/\/$/,"");if(void 0===l||"http"==l&&"80"==n||"https"==l&&"443"==n)l="web",n="default";return[l,m,n,q]}for(var d=c(String(a)),e=c(String(b)),f=0;f<d.length;f++)if(d[f]!==e[f])return!1;return!0}
function Lj(a){return Mj(a)?1:0}
function Mj(a){var b=a.arg0,c=a.arg1;if(a.any_of&&ua(c)){for(var d=0;d<c.length;d++)if(Lj({"function":a["function"],arg0:b,arg1:c[d]}))return!0;return!1}switch(a["function"]){case "_cn":return 0<=String(b).indexOf(String(c));case "_css":var e;a:{if(b){var f=["matches","webkitMatchesSelector","mozMatchesSelector","msMatchesSelector","oMatchesSelector"];try{for(var h=0;h<f.length;h++)if(b[f[h]]){e=b[f[h]](c);break a}}catch(v){}}e=!1}return e;case "_ew":var k,l;k=String(b);l=String(c);var m=k.length-
l.length;return 0<=m&&k.indexOf(l,m)==m;case "_eq":return String(b)==String(c);case "_ge":return Number(b)>=Number(c);case "_gt":return Number(b)>Number(c);case "_lc":var n;n=String(b).split(",");return 0<=r(n,String(c));case "_le":return Number(b)<=Number(c);case "_lt":return Number(b)<Number(c);case "_re":var q;var u=a.ignore_case?"i":void 0;try{var p=String(c)+u,t=Jj.get(p);t||(t=new RegExp(c,u),Jj.set(p,t));q=t.test(b)}catch(v){q=!1}return q;case "_sw":return 0==String(b).indexOf(String(c));case "_um":return Kj(b,
c)}return!1};var Nj=function(a,b){var c=function(){};c.prototype=a.prototype;var d=new c;a.apply(d,Array.prototype.slice.call(arguments,1));return d};var Oj={},Pj=encodeURI,Y=encodeURIComponent,Qj=mc;var Rj=function(a,b){if(!a)return!1;var c=Ye(Ze(a),"host");if(!c)return!1;for(var d=0;b&&d<b.length;d++){var e=b[d]&&b[d].toLowerCase();if(e){var f=c.length-e.length;0<f&&"."!=e.charAt(0)&&(f--,e="."+e);if(0<=f&&c.indexOf(e,f)==f)return!0}}return!1};
var Sj=function(a,b,c){for(var d={},e=!1,f=0;a&&f<a.length;f++)a[f]&&a[f].hasOwnProperty(b)&&a[f].hasOwnProperty(c)&&(d[a[f][b]]=a[f][c],e=!0);return e?d:null};Oj.ng=function(){var a=!1;return a};var el=function(){var a=D.gaGlobal=D.gaGlobal||{};a.hid=a.hid||wa();return a.hid};var pl=window,ql=document,rl=function(a){var b=pl._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a&&!0===pl["ga-disable-"+a])return!0;try{var c=pl.external;if(c&&c._gaUserPrefs&&"oo"==c._gaUserPrefs)return!0}catch(f){}for(var d=Rf("AMP_TOKEN",ql.cookie,!0),e=0;e<d.length;e++)if("$OPT_OUT"==d[e])return!0;return ql.getElementById("__gaOptOutExtension")?!0:!1};var ul=function(a){za(a,function(c){"_"===c.charAt(0)&&delete a[c]});var b=a[H.ca]||{};za(b,function(c){"_"===c.charAt(0)&&delete b[c]})};var yl=function(a,b,c){Kf(b,c,a)},zl=function(a,b,c){Kf(b,c,a,!0)},Bl=function(a,b){};
function Al(a,b){}var Z={a:{}};


Z.a.jsm=["customScripts"],function(){(function(a){Z.__jsm=a;Z.__jsm.b="jsm";Z.__jsm.g=!0;Z.__jsm.priorityOverride=0})(function(a){if(void 0!==a.vtp_javascript){var b=a.vtp_javascript;try{var c=X("google_tag_manager");return c&&c.e&&c.e(b)}catch(d){}}})}();
Z.a.sp=["google"],function(){(function(a){Z.__sp=a;Z.__sp.b="sp";Z.__sp.g=!0;Z.__sp.priorityOverride=0})(function(a){var b=-1==navigator.userAgent.toLowerCase().indexOf("firefox")?"//www.googleadservices.com/pagead/conversion_async.js":"https://www.google.com/pagead/conversion_async.js",c=a.vtp_gtmOnFailure;He();R(b,function(){var d=X("google_trackConversion");if(qa(d)){var e={};"DATA_LAYER"==a.vtp_customParamsFormat?e=a.vtp_dataLayerVariable:"USER_SPECIFIED"==a.vtp_customParamsFormat&&(e=Sj(a.vtp_customParams,
"key","value"));var f={};a.vtp_enableDynamicRemarketing&&(a.vtp_eventName&&(e.event=a.vtp_eventName),a.vtp_eventValue&&(f.value=a.vtp_eventValue),a.vtp_eventItems&&(f.items=a.vtp_eventItems));var h={google_conversion_id:a.vtp_conversionId,google_conversion_label:a.vtp_conversionLabel,google_custom_params:e,google_gtag_event_data:f,google_remarketing_only:!0,onload_callback:a.vtp_gtmOnSuccess,google_gtm:pi()};a.vtp_rdp&&(h.google_restricted_data_processing=!0);d(h)||c()}else c()},c)})}();

Z.a.e=["google"],function(){(function(a){Z.__e=a;Z.__e.b="e";Z.__e.g=!0;Z.__e.priorityOverride=0})(function(a){return String(Sd(a.vtp_gtmEventId,"event"))})}();
Z.a.f=["google"],function(){(function(a){Z.__f=a;Z.__f.b="f";Z.__f.g=!0;Z.__f.priorityOverride=0})(function(a){var b=U("gtm.referrer",1)||F.referrer;return b?a.vtp_component&&"URL"!=a.vtp_component?Ye(Ze(String(b)),a.vtp_component,a.vtp_stripWww,a.vtp_defaultPages,a.vtp_queryKey):cj(String(b)):String(b)})}();
Z.a.cl=["google"],function(){function a(b){var c=b.target;if(c){var d=Yg(c,"gtm.click");dj(d)}}(function(b){Z.__cl=b;Z.__cl.b="cl";Z.__cl.g=!0;Z.__cl.priorityOverride=0})(function(b){if(!hj("cl")){var c=X("document");nc(c,"click",a,!0);ij("cl")}G(b.vtp_gtmOnSuccess)})}();
Z.a.j=["google"],function(){(function(a){Z.__j=a;Z.__j.b="j";Z.__j.g=!0;Z.__j.priorityOverride=0})(function(a){for(var b=String(a.vtp_name).split("."),c=X(b.shift()),d=0;d<b.length;d++)c=c&&c[b[d]];return c})}();Z.a.k=["google"],function(){(function(a){Z.__k=a;Z.__k.b="k";Z.__k.g=!0;Z.__k.priorityOverride=0})(function(a){return fj(a.vtp_name,U("gtm.cookie",1),!!a.vtp_decodeCookie)[0]})}();

Z.a.u=["google"],function(){var a=function(b){return{toString:function(){return b}}};(function(b){Z.__u=b;Z.__u.b="u";Z.__u.g=!0;Z.__u.priorityOverride=0})(function(b){var c;b.vtp_customUrlSource?c=b.vtp_customUrlSource:c=U("gtm.url",1);c=c||aj();var d=b[a("vtp_component")];if(!d||"URL"==d)return cj(String(c));var e=Ze(String(c)),f;if("QUERY"===d)a:{var h=b[a("vtp_multiQueryKeys").toString()],k=b[a("vtp_queryKey").toString()]||"",l=b[a("vtp_ignoreEmptyQueryParam").toString()],m;h?ua(k)?m=k:m=String(k).replace(/\s+/g,
"").split(","):m=[String(k)];for(var n=0;n<m.length;n++){var q=Ye(e,"QUERY",void 0,void 0,m[n]);if(void 0!=q&&(!l||""!==q)){f=q;break a}}f=void 0}else f=Ye(e,d,"HOST"==d?b[a("vtp_stripWww")]:void 0,"PATH"==d?b[a("vtp_defaultPages")]:void 0,void 0);return f})}();
Z.a.v=["google"],function(){(function(a){Z.__v=a;Z.__v.b="v";Z.__v.g=!0;Z.__v.priorityOverride=0})(function(a){var b=a.vtp_name;if(!b||!b.replace)return!1;var c=U(b.replace(/\\\./g,"."),a.vtp_dataLayerVersion||1);return void 0!==c?c:a.vtp_defaultValue})}();
Z.a.tl=["google"],function(){function a(b){return function(){if(b.Oc&&b.Qc>=b.Oc)b.Kc&&X("self").clearInterval(b.Kc);else{b.Qc++;var c=(new Date).getTime();dj({event:b.Z,"gtm.timerId":b.Kc,"gtm.timerEventNumber":b.Qc,"gtm.timerInterval":b.interval,"gtm.timerLimit":b.Oc,"gtm.timerStartTime":b.De,"gtm.timerCurrentTime":c,"gtm.timerElapsedTime":c-b.De,"gtm.triggers":b.fh})}}}(function(b){Z.__tl=b;Z.__tl.b="tl";Z.__tl.g=!0;Z.__tl.priorityOverride=0})(function(b){G(b.vtp_gtmOnSuccess);if(!isNaN(b.vtp_interval)){var c=
{Z:b.vtp_eventName,Qc:0,interval:Number(b.vtp_interval),Oc:isNaN(b.vtp_limit)?0:Number(b.vtp_limit),fh:String(b.vtp_uniqueTriggerId||"0"),De:(new Date).getTime()};c.Kc=X("self").setInterval(a(c),0>Number(b.vtp_interval)?0:Number(b.vtp_interval))}})}();
Z.a.ua=["google"],function(){var a,b={},c=function(d){var e={},f={},h={},k={},l={},m=void 0;if(d.vtp_gaSettings){var n=d.vtp_gaSettings;B(Sj(n.vtp_fieldsToSet,"fieldName","value"),f);B(Sj(n.vtp_contentGroup,"index","group"),h);B(Sj(n.vtp_dimension,"index","dimension"),k);B(Sj(n.vtp_metric,"index","metric"),l);d.vtp_gaSettings=null;n.vtp_fieldsToSet=void 0;n.vtp_contentGroup=void 0;n.vtp_dimension=void 0;n.vtp_metric=void 0;var q=B(n);d=B(d,q)}B(Sj(d.vtp_fieldsToSet,"fieldName","value"),f);B(Sj(d.vtp_contentGroup,
"index","group"),h);B(Sj(d.vtp_dimension,"index","dimension"),k);B(Sj(d.vtp_metric,"index","metric"),l);var u=Oe(d.vtp_functionName);if(qa(u)){var p="",t="";d.vtp_setTrackerName&&"string"==typeof d.vtp_trackerName?""!==d.vtp_trackerName&&(t=d.vtp_trackerName,p=t+"."):(t="gtm"+gd(),p=t+".");var v={name:!0,clientId:!0,sampleRate:!0,siteSpeedSampleRate:!0,alwaysSendReferrer:!0,allowAnchor:!0,allowLinker:!0,cookieName:!0,cookieDomain:!0,cookieExpires:!0,cookiePath:!0,cookieUpdate:!0,legacyCookieDomain:!0,
legacyHistoryImport:!0,storage:!0,useAmpClientId:!0,storeGac:!0},w={allowAnchor:!0,allowLinker:!0,alwaysSendReferrer:!0,anonymizeIp:!0,cookieUpdate:!0,exFatal:!0,forceSSL:!0,javaEnabled:!0,legacyHistoryImport:!0,nonInteraction:!0,useAmpClientId:!0,useBeacon:!0,storeGac:!0,allowAdFeatures:!0,allowAdPersonalizationSignals:!0},y=function(O){var K=[].slice.call(arguments,0);K[0]=p+K[0];u.apply(window,K)},x=function(O,K){return void 0===K?K:O(K)},z=function(O,K){if(K)for(var sa in K)K.hasOwnProperty(sa)&&
y("set",O+sa,K[sa])},C=function(){},A=function(O,K,sa){var Gb=0;if(O)for(var Da in O)if(O.hasOwnProperty(Da)&&(sa&&v[Da]||!sa&&void 0===v[Da])){var $a=w[Da]?Ba(O[Da]):O[Da];"anonymizeIp"!=Da||$a||($a=void 0);K[Da]=$a;Gb++}return Gb},E={name:t};A(f,E,
!0);u("create",d.vtp_trackingId||e.trackingId,E);y("set","&gtm",pi(!0));d.vtp_enableRecaptcha&&y("require","recaptcha","recaptcha.js");(function(O,K){void 0!==d[K]&&y("set",O,d[K])})("nonInteraction","vtp_nonInteraction");z("contentGroup",h);z("dimension",k);z("metric",l);var J={};A(f,J,!1)&&y("set",J);var M;d.vtp_enableLinkId&&y("require","linkid","linkid.js");y("set","hitCallback",function(){var O=f&&f.hitCallback;qa(O)&&O();d.vtp_gtmOnSuccess()});if("TRACK_EVENT"==d.vtp_trackType){d.vtp_enableEcommerce&&(y("require","ec","ec.js"),C());var V={hitType:"event",eventCategory:String(d.vtp_eventCategory||e.category),eventAction:String(d.vtp_eventAction||
e.action),eventLabel:x(String,d.vtp_eventLabel||e.label),eventValue:x(Aa,d.vtp_eventValue||e.value)};A(M,V,!1);y("send",V);}else if("TRACK_SOCIAL"==d.vtp_trackType){}else if("TRACK_TRANSACTION"==
d.vtp_trackType){}else if("TRACK_TIMING"==d.vtp_trackType){}else if("DECORATE_LINK"==
d.vtp_trackType){}else if("DECORATE_FORM"==d.vtp_trackType){}else if("TRACK_DATA"==d.vtp_trackType){}else{d.vtp_enableEcommerce&&
(y("require","ec","ec.js"),C());if(d.vtp_doubleClick||"DISPLAY_FEATURES"==d.vtp_advertisingFeaturesType){var oa="_dc_gtm_"+String(d.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");y("require","displayfeatures",void 0,{cookieName:oa})}if("DISPLAY_FEATURES_WITH_REMARKETING_LISTS"==d.vtp_advertisingFeaturesType){var ka="_dc_gtm_"+String(d.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");y("require","adfeatures",{cookieName:ka})}M?y("send","pageview",M):y("send","pageview");}if(!a){var ta=d.vtp_useDebugVersion?"u/analytics_debug.js":"analytics.js";d.vtp_useInternalVersion&&!d.vtp_useDebugVersion&&(ta="internal/"+ta);a=!0;var bb=Q("https:","http:","//www.google-analytics.com/"+ta,f&&f.forceSSL);
R(bb,function(){var O=Me();O&&O.loaded||d.vtp_gtmOnFailure();},d.vtp_gtmOnFailure)}}else G(d.vtp_gtmOnFailure)};Z.__ua=c;Z.__ua.b="ua";Z.__ua.g=!0;Z.__ua.priorityOverride=0}();





Z.a.gclidw=["google"],function(){var a=["aw","dc","gf","ha","gp"];(function(b){Z.__gclidw=b;Z.__gclidw.b="gclidw";Z.__gclidw.g=!0;Z.__gclidw.priorityOverride=100})(function(b){G(b.vtp_gtmOnSuccess);var c,d,e;b.vtp_enableCookieOverrides&&(e=b.vtp_cookiePrefix,c=b.vtp_path,d=b.vtp_domain);var f=null;b.vtp_enableCookieUpdateFeature&&(f=!0,void 0!==b.vtp_cookieUpdate&&(f=!!b.vtp_cookieUpdate));var h=e,k=c,l=d;if(b.vtp_enableCrossDomainFeature&&(!b.vtp_enableCrossDomain||!1!==b.vtp_acceptIncoming)&&(b.vtp_enableCrossDomain||
Dh())){Rh(a,h,k,l,void 0);}var m={prefix:e,path:c,domain:d,Ka:void 0};Oh(m);Vh(["aw","dc"],m);li(f,e,c,d);var n=e;if(b.vtp_enableCrossDomainFeature&&b.vtp_enableCrossDomain&&b.vtp_linkerDomains){var q=b.vtp_linkerDomains.toString().replace(/\s+/g,"").split(","),u=b.vtp_urlPosition,p=!!b.vtp_formDecoration;Th(a,q,u,p,n);}})}();


Z.a.aev=["google"],function(){function a(p,t){var v=Sd(p,"gtm");if(v)return v[t]}function b(p,t,v,w){w||(w="element");var y=p+"."+t,x;if(n.hasOwnProperty(y))x=n[y];else{var z=a(p,w);if(z&&(x=v(z),n[y]=x,q.push(y),35<q.length)){var C=q.shift();delete n[C]}}return x}function c(p,t,v){var w=a(p,u[t]);return void 0!==w?w:v}function d(p,t){if(!p)return!1;var v=e(aj());ua(t)||(t=String(t||"").replace(/\s+/g,"").split(","));for(var w=[v],y=0;y<t.length;y++)if(t[y]instanceof RegExp){if(t[y].test(p))return!1}else{var x=
t[y];if(0!=x.length){if(0<=e(p).indexOf(x))return!1;w.push(e(x))}}return!Rj(p,w)}function e(p){m.test(p)||(p="http://"+p);return Ye(Ze(p),"HOST",!0)}function f(p,t,v){switch(p){case "SUBMIT_TEXT":return b(t,"FORM."+p,h,"formSubmitElement")||v;case "LENGTH":var w=b(t,"FORM."+p,k);return void 0===w?v:w;case "INTERACTED_FIELD_ID":return l(t,"id",v);case "INTERACTED_FIELD_NAME":return l(t,"name",v);case "INTERACTED_FIELD_TYPE":return l(t,"type",v);case "INTERACTED_FIELD_POSITION":var y=a(t,"interactedFormFieldPosition");
return void 0===y?v:y;case "INTERACT_SEQUENCE_NUMBER":var x=a(t,"interactSequenceNumber");return void 0===x?v:x;default:return v}}function h(p){switch(p.tagName.toLowerCase()){case "input":return qc(p,"value");case "button":return rc(p);default:return null}}function k(p){if("form"===p.tagName.toLowerCase()&&p.elements){for(var t=0,v=0;v<p.elements.length;v++)wi(p.elements[v])&&t++;return t}}function l(p,t,v){var w=a(p,"interactedFormField");return w&&qc(w,t)||v}var m=/^https?:\/\//i,n={},q=[],u={ATTRIBUTE:"elementAttribute",
CLASSES:"elementClasses",ELEMENT:"element",ID:"elementId",HISTORY_CHANGE_SOURCE:"historyChangeSource",HISTORY_NEW_STATE:"newHistoryState",HISTORY_NEW_URL_FRAGMENT:"newUrlFragment",HISTORY_OLD_STATE:"oldHistoryState",HISTORY_OLD_URL_FRAGMENT:"oldUrlFragment",TARGET:"elementTarget"};(function(p){Z.__aev=p;Z.__aev.b="aev";Z.__aev.g=!0;Z.__aev.priorityOverride=0})(function(p){var t=p.vtp_gtmEventId,v=p.vtp_defaultValue,w=p.vtp_varType;switch(w){case "TAG_NAME":var y=a(t,"element");return y&&y.tagName||
v;case "TEXT":return b(t,w,rc)||v;case "URL":var x;a:{var z=String(a(t,"elementUrl")||v||""),C=Ze(z),A=String(p.vtp_component||"URL");switch(A){case "URL":x=z;break a;case "IS_OUTBOUND":x=d(z,p.vtp_affiliatedDomains);break a;default:x=Ye(C,A,p.vtp_stripWww,p.vtp_defaultPages,p.vtp_queryKey)}}return x;case "ATTRIBUTE":var E;if(void 0===p.vtp_attribute)E=c(t,w,v);else{var J=p.vtp_attribute,M=a(t,"element");E=M&&qc(M,J)||v||""}return E;case "MD":var V=p.vtp_mdValue,W=b(t,"MD",Ki);return V&&W?Ni(W,V)||
v:W||v;case "FORM":return f(String(p.vtp_component||"SUBMIT_TEXT"),t,v);default:return c(t,w,v)}})}();
Z.a.gas=["google"],function(){(function(a){Z.__gas=a;Z.__gas.b="gas";Z.__gas.g=!0;Z.__gas.priorityOverride=0})(function(a){var b=B(a),c=b;c[Ib.ra]=null;c[Ib.Qe]=null;var d=b=c;d.vtp_fieldsToSet=d.vtp_fieldsToSet||[];var e=d.vtp_cookieDomain;void 0!==e&&(d.vtp_fieldsToSet.push({fieldName:"cookieDomain",value:e}),delete d.vtp_cookieDomain);return b})}();

Z.a.hl=["google"],function(){function a(f){return f.target&&f.target.location&&f.target.location.href?f.target.location.href:aj()}function b(f,h){nc(f,"hashchange",function(k){var l=a(k);h({source:"hashchange",state:null,url:cj(l),J:bj(l)})})}function c(f,h){nc(f,"popstate",function(k){var l=a(k);h({source:"popstate",state:k.state,url:cj(l),J:bj(l)})})}function d(f,h,k){var l=h.history,m=l[f];if(qa(m))try{l[f]=function(n,q,u){m.apply(l,[].slice.call(arguments,0));k({source:f,state:n,url:cj(aj()),
J:bj(aj())})}}catch(n){}}function e(){var f={source:null,state:X("history").state||null,url:cj(aj()),J:bj(aj())};return function(h){var k=f,l={};l[k.source]=!0;l[h.source]=!0;if(!l.popstate||!l.hashchange||k.J!=h.J){var m={event:"gtm.historyChange","gtm.historyChangeSource":h.source,"gtm.oldUrlFragment":f.J,"gtm.newUrlFragment":h.J,"gtm.oldHistoryState":f.state,"gtm.newHistoryState":h.state};m["gtm.oldUrl"]=f.url,m["gtm.newUrl"]=h.url;
f=h;dj(m)}}}(function(f){Z.__hl=f;Z.__hl.b="hl";Z.__hl.g=!0;Z.__hl.priorityOverride=0})(function(f){var h=X("self");if(!hj("hl")){var k=e();b(h,k);c(h,k);d("pushState",h,k);d("replaceState",h,k);ij("hl")}G(f.vtp_gtmOnSuccess)})}();
Z.a.awct=["google"],function(){var a=!1,b=[],c=function(k){var l=X("google_trackConversion"),m=k.gtm_onFailure;"function"==typeof l?l(k)||m():m()},d=function(){for(;0<b.length;)c(b.shift())},e=function(){return function(){d();a=!1}},f=function(){return function(){d();b={push:c};}},h=function(k){He();var l={google_basket_transaction_type:"purchase",google_conversion_domain:"",google_conversion_id:k.vtp_conversionId,google_conversion_label:k.vtp_conversionLabel,
google_conversion_value:k.vtp_conversionValue||0,google_remarketing_only:!1,onload_callback:k.vtp_gtmOnSuccess,gtm_onFailure:k.vtp_gtmOnFailure,google_gtm:pi()};k.vtp_rdp&&(l.google_restricted_data_processing=!0);var m=function(v){return function(w,y,x){var z="DATA_LAYER"==v?U(x):k[y];z&&(l[w]=z)}},n=m("JSON");n("google_conversion_currency","vtp_currencyCode");n("google_conversion_order_id","vtp_orderId");k.vtp_enableProductReporting&&(n=m(k.vtp_productReportingDataSource),n("google_conversion_merchant_id",
"vtp_awMerchantId","aw_merchant_id"),n("google_basket_feed_country","vtp_awFeedCountry","aw_feed_country"),n("google_basket_feed_language","vtp_awFeedLanguage","aw_feed_language"),n("google_basket_discount","vtp_discount","discount"),n("google_conversion_items","vtp_items","items"),l.google_conversion_items=l.google_conversion_items.map(function(v){return{value:v.price,quantity:v.quantity,item_id:v.id}}));var q=function(v,w){(l.google_additional_conversion_params=l.google_additional_conversion_params||
{})[v]=w},u=function(v){return function(w,y,x,z){var C="DATA_LAYER"==v?U(x):k[y];z(C)&&q(w,C)}},p=-1==navigator.userAgent.toLowerCase().indexOf("firefox")?"//www.googleadservices.com/pagead/conversion_async.js":"https://www.google.com/pagead/conversion_async.js";k.vtp_enableNewCustomerReporting&&(n=u(k.vtp_newCustomerReportingDataSource),n("vdnc","vtp_awNewCustomer","new_customer",function(v){return void 0!=v&&""!==v}),n("vdltv","vtp_awCustomerLTV","customer_lifetime_value",function(v){return void 0!=
v&&""!==v}));!k.hasOwnProperty("vtp_enableConversionLinker")||k.vtp_enableConversionLinker?(k.vtp_conversionCookiePrefix&&(l.google_gcl_cookie_prefix=k.vtp_conversionCookiePrefix),l.google_read_gcl_cookie_opt_out=!1):l.google_read_gcl_cookie_opt_out=!0;var t=!0;t&&b.push(l);a||(a=!0,R(p,f(),e(p)))};Z.__awct=h;Z.__awct.b="awct";Z.__awct.g=!0;Z.__awct.priorityOverride=0}();
Z.a.bzi=["nonGoogleScripts"],function(){(function(a){Z.__bzi=a;Z.__bzi.b="bzi";Z.__bzi.g=!0;Z.__bzi.priorityOverride=0})(function(a){try{D._bizo_data_partner_id=a.vtp_id,D._bizo_data_partner_title=a.vtp_title,D._bizo_data_partner_domain=a.vtp_domain,D._bizo_data_partner_company=a.vtp_company,D._bizo_data_partner_location=a.vtp_location,D._bizo_data_partner_employee_range=a.vtp_employeeRange,D._bizo_data_partner_sics=a.vtp_standardIndustrialClassification,D._bizo_data_partner_email=a.vtp_email,R(Q("https://sjs",
"http://js",".bizographics.com/insight.min.js"),a.vtp_gtmOnSuccess,a.vtp_gtmOnFailure)}catch(b){G(a.vtp_gtmOnFailure)}})}();Z.a.remm=["google"],function(){(function(a){Z.__remm=a;Z.__remm.b="remm";Z.__remm.g=!0;Z.__remm.priorityOverride=0})(function(a){for(var b=a.vtp_input,c=a.vtp_map||[],d=a.vtp_fullMatch,e=a.vtp_ignoreCase?"gi":"g",f=0;f<c.length;f++){var h=c[f].key||"";d&&(h="^"+h+"$");var k=new RegExp(h,e);if(k.test(b)){var l=c[f].value;a.vtp_replaceAfterMatch&&(l=String(b).replace(k,l));return l}}return a.vtp_defaultValue})}();





Z.a.paused=[],function(){(function(a){Z.__paused=a;Z.__paused.b="paused";Z.__paused.g=!0;Z.__paused.priorityOverride=0})(function(a){G(a.vtp_gtmOnFailure)})}();
Z.a.twitter_website_tag=["nonGoogleScripts"],function(){(function(a){Z.__twitter_website_tag=a;Z.__twitter_website_tag.b="twitter_website_tag";Z.__twitter_website_tag.g=!0;Z.__twitter_website_tag.priorityOverride=0})(function(a){(function(c,d){c.twq||(d=c.twq=function(){d.exe?d.exe.apply(d,arguments):d.queue.push(arguments)},d.version="1",d.queue=[],R("//static.ads-twitter.com/uwt.js"))})(window,void 0);window.twq("init",String(a.vtp_twitter_pixel_id));var b=Sj(a.vtp_event_parameters,"param_table_key_column",
"param_table_value_column");b&&void 0!==b.content_ids&&(b.content_ids=JSON.parse(b.content_ids.replace(/'/g,'"')));window.twq("track",String(a.vtp_event_type),b);G(a.vtp_gtmOnSuccess)})}();
Z.a.html=["customScripts"],function(){function a(d,e,f,h){return function(){try{if(0<e.length){var k=e.shift(),l=a(d,e,f,h);if("SCRIPT"==String(k.nodeName).toUpperCase()&&"text/gtmscript"==k.type){var m=F.createElement("script");m.async=!1;m.type="text/javascript";m.id=k.id;m.text=k.text||k.textContent||k.innerHTML||"";k.charset&&(m.charset=k.charset);var n=k.getAttribute("data-gtmsrc");n&&(m.src=n,ic(m,l));d.insertBefore(m,null);n||l()}else if(k.innerHTML&&0<=k.innerHTML.toLowerCase().indexOf("<script")){for(var q=
[];k.firstChild;)q.push(k.removeChild(k.firstChild));d.insertBefore(k,null);a(k,q,l,h)()}else d.insertBefore(k,null),l()}else f()}catch(u){G(h)}}}var c=function(d){if(F.body){var e=
d.vtp_gtmOnFailure,f=lj(d.vtp_html,d.vtp_gtmOnSuccess,e),h=f.Jc,k=f.B;if(d.vtp_useIframe){}else d.vtp_supportDocumentWrite?b(h,k,e):a(F.body,sc(h),k,e)()}else $i(function(){c(d)},
200)};Z.__html=c;Z.__html.b="html";Z.__html.g=!0;Z.__html.priorityOverride=0}();






Z.a.lcl=[],function(){function a(){var e=X("document"),f=0,h=function(k){var l=k.target;if(l&&3!==k.which&&!(k.lg||k.timeStamp&&k.timeStamp===f)){f=k.timeStamp;l=tc(l,["a","area"],100);if(!l)return k.returnValue;var m=k.defaultPrevented||!1===k.returnValue,n=bh("lcl",m?"nv.mwt":"mwt",0),q;q=m?bh("lcl","nv.ids",[]):bh("lcl","ids",[]);if(q.length){var u=Yg(l,"gtm.linkClick",q);if(b(k,l,e)&&!m&&n&&l.href){var p=String(kj(l,"rel")||""),t=!!va(p.split(" "),function(y){return"noreferrer"===y.toLowerCase()});
t&&I("GTM",36);var v=X((kj(l,"target")||"_self").substring(1)),w=!0;if(dj(u,Og(function(){var y;if(y=w&&v){var x;a:if(t&&d){var z;try{z=new MouseEvent(k.type)}catch(C){if(!e.createEvent){x=!1;break a}z=e.createEvent("MouseEvents");z.initEvent(k.type,!0,!0)}z.lg=!0;k.target.dispatchEvent(z);x=!0}else x=!1;y=!x}y&&(v.location.href=kj(l,"href"))}),n))w=!1;else return k.preventDefault&&k.preventDefault(),k.returnValue=!1}else dj(u,function(){},n||2E3);return!0}}};nc(e,"click",h,!1);nc(e,"auxclick",h,
!1)}function b(e,f,h){if(2===e.which||e.ctrlKey||e.shiftKey||e.altKey||e.metaKey)return!1;var k=kj(f,"href"),l=k.indexOf("#"),m=kj(f,"target");if(m&&"_self"!==m&&"_parent"!==m&&"_top"!==m||0===l)return!1;if(0<l){var n=cj(k),q=cj(h.location);return n!==q}return!0}function c(e){var f=void 0===e.vtp_waitForTags?!0:e.vtp_waitForTags,h=void 0===e.vtp_checkValidation?!0:e.vtp_checkValidation,k=Number(e.vtp_waitForTagsTimeout);if(!k||0>=k)k=2E3;var l=e.vtp_uniqueTriggerId||"0";if(f){var m=function(q){return Math.max(k,
q)};ah("lcl","mwt",m,0);h||ah("lcl","nv.mwt",m,0)}var n=function(q){q.push(l);return q};ah("lcl","ids",n,[]);h||ah("lcl","nv.ids",n,[]);hj("lcl")||(a(),ij("lcl"));G(e.vtp_gtmOnSuccess)}var d=!1;d=!0;Z.__lcl=c;Z.__lcl.b="lcl";Z.__lcl.g=!0;Z.__lcl.priorityOverride=0;}();


var wm={};wm.macro=function(a){if(Vg.xc.hasOwnProperty(a))return Vg.xc[a]},wm.onHtmlSuccess=Vg.be(!0),wm.onHtmlFailure=Vg.be(!1);wm.dataLayer=Ld;wm.callback=function(a){ed.hasOwnProperty(a)&&qa(ed[a])&&ed[a]();delete ed[a]};function xm(){Vc[Uc.s]=wm;Ia(fd,Z.a);zb=zb||Vg;Ab=pe}
function ym(){Fh.gtm_3pds=!0;Vc=D.google_tag_manager=D.google_tag_manager||{};if(Vc[Uc.s]){var a=Vc.zones;a&&a.unregisterChild(Uc.s)}else{for(var b=data.resource||{},c=b.macros||[],d=0;d<c.length;d++)rb.push(c[d]);for(var e=b.tags||[],f=0;f<e.length;f++)vb.push(e[f]);for(var h=b.predicates||[],k=0;k<
h.length;k++)tb.push(h[k]);for(var l=b.rules||[],m=0;m<l.length;m++){for(var n=l[m],q={},u=0;u<n.length;u++)q[n[u][0]]=Array.prototype.slice.call(n[u],1);sb.push(q)}xb=Z;yb=Lj;xm();Ug();te=!1;ue=0;if("interactive"==F.readyState&&!F.createEventObject||"complete"==F.readyState)we();else{nc(F,"DOMContentLoaded",we);nc(F,"readystatechange",we);if(F.createEventObject&&F.documentElement.doScroll){var p=!0;try{p=!D.frameElement}catch(y){}p&&xe()}nc(D,"load",we)}sg=!1;"complete"===F.readyState?ug():nc(D,
"load",ug);a:{if(!Ad)break a;D.setInterval(Bd,864E5);}
bd=(new Date).getTime();
}}ym();

})()
