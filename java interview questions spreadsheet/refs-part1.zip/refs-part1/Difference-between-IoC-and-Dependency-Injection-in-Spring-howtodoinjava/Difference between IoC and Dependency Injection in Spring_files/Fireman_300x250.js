(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib.Fireman = function() {
	this.initialize(img.Fireman);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,550,500);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(255,0,0,0.498)","rgba(255,0,0,0)"],[0,1],0,0,0,0,0,64.7).s().p("AnGHGQi8i8AAkKQAAkJC8i9QC9i8EJAAQEKAAC8C8QC8C9ABEJQgBEKi8C8Qi8C8kKABQkJgBi9i8g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.2,-64.2,128.5,128.5);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Fireman();
	this.instance.parent = this;
	this.instance.setTransform(-120,-331,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-331,436.6,396.9);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIBFQgDgDAAgGQAAgFADgDQADgDAFgBQAFABADADQAEADAAAFQAAAGgEADQgDACgFABQgFgBgDgCgAgIAgIgDhmIAXgBIgEBng");
	this.shape.setTransform(40.8,12.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgEgJAAgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgCgJIAAgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_1.setTransform(31.7,14);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_2.setTransform(17.4,13.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgFgJABgOIAAghIAAgTIgCgOIAVgCIABAQIAAATIAAAfQAAAMAFAHQAFAGAKAAQAEAAAFgDQAFgCADgEIAIgHIAAhJIAUAAIAABDIAAASIABASIgTAAIgBgJIAAgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEg");
	this.shape_3.setTransform(-1.9,14);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgEgJAAgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAFgEIAGgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgBgJIgBgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_4.setTransform(38.1,-8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgNAwQgMgHgHgLQgHgNAAgRQAAgRAHgMQAHgLAMgHQALgFAPAAIANABQAIAAAGADIAAAQIgLgDQgGgCgIAAQgPAAgKAKQgIAKgBARQABARAJALQAJAKAPAAQAIAAAHgCIAKgEIAAAQIgOAEIgNACQgOgBgMgFg");
	this.shape_5.setTransform(27.5,-8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgFgJABgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIACASIgUAAIgBgJIAAgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_6.setTransform(11.8,-8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgWBGQgLgDgFgJQgHgKAAgQIAAg/QABgUAKgLQALgLAWAAQAMAAAKAFQAJAEAEAJQAFAIAAALQAAAMgGAJQgGAIgNADQAPADAIAIQAIAJAAAQQAAAUgMALQgNALgVAAIgDAAQgKAAgIgEgAgZADIAAAgQAAAKAGAHQAGAHANAAQAMAAAGgHQAGgHABgOQAAgNgFgHQgGgGgKgCIgMgBIgRABgAgTg0QgFAGgBANIAAAXQAYACAKgGQALgGgBgPQABgMgGgGQgGgFgJAAQgMAAgGAGg");
	this.shape_7.setTransform(0.6,-10);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgEgGQgEgHgBgKQAAgMAGgHQAGgHAJgDQAJgDAMAAIALABIAMABIAAgKQgBgLgFgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAJADAEAIQAEAIABAPIAAAsIAAAMIABALIgTAAIAAgHIgBgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgQAIQgGAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgMAAgIAFg");
	this.shape_8.setTransform(-11,-8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgtgpIgBgOIgCgOIAUgBIABAOQAGgHAIgEQAJgDAJAAQAPgBAKAIQAJAIAFAMQAEAMABAPQgBAPgEALQgFALgKAIQgJAGgQABQgLgBgHgDQgHgCgDgEIAAAsIgVACgAgOgzQgHACgEAFIABA5IAEADIAHADIALABQAPAAAIgKQAHgJAAgRQAAgTgHgKQgIgKgNAAQgIAAgGAEg");
	this.shape_9.setTransform(-22,-6.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAZA1IgBgRIAAgTIAAgcQAAgNgGgGQgFgGgKAAQgEAAgFACQgEACgEAEIgHAIIAABJIgUAAIAAhGIgBgQIgCgRIATgCIACAKIAAAJQAGgIAJgGQAIgFAKAAQAJAAAIAEQAIADAEAJQAFAIAAAOIAAAfIAAAUIABAQg");
	this.shape_10.setTransform(-34,-8.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgFgGQgDgHAAgKQgBgMAGgHQAGgHAJgDQAJgDAMAAIAMABIALABIAAgKQAAgLgGgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAIADAFAIQAEAIAAAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgPAIQgHAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgNAAgGAFg");
	this.shape_11.setTransform(-45.5,-8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAgBGIAAg8IhAAAIAAA8IgUAAIAAiLIAUAAIAAA+IBAAAIAAg+IAWAAIAACLg");
	this.shape_12.setTransform(-58.2,-9.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.6,-23.8,118.6,50);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E70000").s().p("AkUEVQh0hyABijQgBiiB0hyQByh0CiABQCjgBByB0QB0BygBCiQABCjh0ByQhyB0ijgBQiiABhyh0g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.2,-39.2,78.5,78.5);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAJQgEgDAAgGQAAgFAEgDQADgDAFgBQAGABADADQADADABAFQgBAGgDADQgDADgGABQgFgBgDgDg");
	this.shape.setTransform(108.6,17.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_1.setTransform(96.8,13.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZBBQgIgEgFgIQgFgJABgOIAAghIAAgTIgBgOIAUgCIABAQIAAATIAAAfQAAAMAFAHQAFAGAKAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABFIAAARIABARIgTAAIgBgJIAAgJQgGAJgIAFQgJAFgKAAIgCABQgIAAgGgEgAgOg1IgLgDIAAgMIAMADIANABIANgBIALgDIABAMIgMADIgNABIgOgBg");
	this.shape_2.setTransform(82.4,12.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgEgGQgEgHgBgKQAAgMAGgHQAGgHAJgDQAJgDAMAAIALABIAMABIAAgKQgBgLgFgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAJADAEAIQAEAIABAPIAAAsIAAAMIABALIgTAAIAAgHIgBgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgQAIQgGAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgMAAgIAFg");
	this.shape_3.setTransform(70.9,13.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAvQgLgFgHgNQgHgLAAgSQAAgRAHgMQAHgMALgFQAMgHAOABIAPABQAHABAGACIgBAQIgKgDQgHgCgGAAQgQAAgJAKQgJAKAAARQAAASAJAKQAJAKAQAAQAHAAAGgCIALgEIAAAQIgNAFIgPABQgOAAgMgHg");
	this.shape_4.setTransform(60.8,13.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAFAxQgFgEgFgKIgHAIIgLAHQgGADgJAAQgOABgIgKQgJgJAAgVIAAgdIAAgVIgBgPIAUgCIAAAQIABATIAAAfQAAAMAFAGQAEAHAJAAQAHAAAFgDQAFgDAGgGIgBgHIgBgIIAAg+IAUAAIAABBQAAALAEAGQAFAHAIAAQAHAAAFgEQAGgDAEgFIAAhNIAUAAIAABLIABAOIACAOIgUABIgBgIIAAgIIgHAHQgFAEgFADQgGACgHAAIgBABQgIAAgHgFg");
	this.shape_5.setTransform(42.4,13.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgFgGQgDgHAAgKQgBgMAGgHQAGgHAJgDQAJgDAMAAIAMABIALABIAAgKQAAgLgGgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAIADAFAIQAEAIAAAPIAAAsIABAMIABALIgTAAIAAgHIgBgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgPAIQgHAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgNAAgGAFg");
	this.shape_6.setTransform(28.3,13.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAnA0IAAgPIAAgQIAAgMIAAgSIAAgTIAAAAIghBHIgOAAIgfhHIgBAAIABATIAAARIAAAsIgTAAIAAhnIAbAAIAfBGIAghGIAaAAIAABIIABARIABAOg");
	this.shape_7.setTransform(15.7,13.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgFgJABgOIAAghIAAgTIgBgOIAUgCIABAQIAAATIAAAfQAAAMAFAHQAFAGAKAAQAEAAAFgDQAEgCAEgEIAIgHIAAhJIAUAAIAABDIAAASIABASIgTAAIgBgJIAAgJQgGAJgIAFQgJAFgKAAIgCABQgIAAgGgEg");
	this.shape_8.setTransform(2.3,13.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgFgJAAgOIAAghIAAgTIgBgOIAVgCIABAQIAAATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAFgCAEgEIAHgHIAAhJIAUAAIAABDIAAASIABASIgTAAIAAgJIgBgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEg");
	this.shape_9.setTransform(-14.2,13.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgOAvQgMgFgGgNQgHgLAAgSQAAgRAHgMQAGgMAMgFQAMgHAOABIAPABQAHABAGACIgBAQIgKgDQgHgCgGAAQgRAAgIAKQgJAKAAARQAAASAJAKQAIAKARAAQAHAAAGgCIALgEIAAAQIgNAFIgPABQgOAAgMgHg");
	this.shape_10.setTransform(-24.9,13.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgEgGQgFgHAAgKQAAgMAGgHQAFgHAKgDQAKgDALAAIALABIAMABIAAgKQgBgLgFgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIATgBQANgBAJAEQAIADAFAIQAEAIABAPIAAAsIAAAMIABALIgTAAIAAgHIgBgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgQAIQgGAEAAAKQAAAGADAEQADAEAEACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgMAAgIAFg");
	this.shape_11.setTransform(-40.3,13.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgXBFQgKgCgJgEIAAgRIARAHQAKADAKAAQAIAAAHgDQAIgDAEgGQAEgGAAgKIAAgNQgFAHgIAEQgIAEgJAAQgLAAgJgFQgKgFgGgLQgGgLAAgRQAAgSAGgMQAGgLAKgFQAKgFAMAAQALAAAHADQAHAEAEAEIAAgKIAUgBIgBAZIAABIQAAAQgHAKQgGAKgLAEQgMAEgNAAQgKAAgKgCgAgSguQgIAJAAARQAAARAIAJQAHAJANAAQAGAAAFgCIAIgFIAGgFIAAgzIgEgCIgIgEQgEgBgHAAQgPAAgHAJg");
	this.shape_12.setTransform(-51.7,15.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgZAvQgLgGgGgMQgGgLAAgSQAAgRAGgLQAGgNALgFQALgHAOAAQAPAAALAHQALAFAGANQAGALAAARQAAASgGALQgGAMgLAGQgLAHgPgBQgOABgLgHgAgUgcQgHAKAAASQAAATAHAJQAIAKAMAAQANAAAIgKQAHgJAAgTQAAgSgHgKQgIgJgNAAQgMAAgIAJg");
	this.shape_13.setTransform(88.5,-10.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAZA1IgBgRIAAgTIAAgcQAAgNgGgGQgFgGgKAAQgEAAgFACQgEACgEAEIgHAIIAABJIgUAAIAAhGIgBgQIgCgRIATgCIACAKIAAAJQAGgIAJgGQAIgFAKAAQAJAAAIAEQAIADAEAJQAFAIAAAOIAAAfIAAAUIABAQg");
	this.shape_14.setTransform(76.9,-10.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgJAxQgKgEgGgJQgFgJAAgOIAAgzIgcAAIAAgOIAwAAIAAAZIAIgFIAJgEIANgCQALAAAJAFQAIAFAFAKQAGAKAAAPQAAAPgGALQgGAKgKAFQgKAFgNAAIgDAAQgLAAgJgEgAAEgXQgFABgDADIgGADIAAAfQAAANAHAGQAGAGALAAQALAAAHgIQAGgJABgQQAAgPgHgJQgGgIgMAAQgGAAgEACg");
	this.shape_15.setTransform(64.2,-10.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAVBKIgYgsIgRAAIAAAsIgUAAIAAh0IgBgQIgBgOIAUgBIACAOIAAARIAAA4IAQAAIAZgqIAVAAIgeAyIAfA0g");
	this.shape_16.setTransform(53.2,-12.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgNAvQgMgGgHgMQgHgLAAgSQAAgRAHgMQAHgMAMgFQALgHAPAAIANABQAIABAGADIAAARIgLgEQgGgCgIAAQgPAAgKAKQgIAKgBARQABARAJALQAIAKAQAAQAIAAAHgCIAKgEIAAARIgOADIgNABQgOABgMgHg");
	this.shape_17.setTransform(42.7,-10.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgQQAAgPAGgNQAGgLAKgHQALgGAOgBQAOAAAKAHQAKAFAFALQAFALAAAPIgBAFIgBAGIhFgBQABARAJAIQAIAIAPAAIARgDQAJgCAHgDIAAAPQgHAEgJACQgJABgLAAQgQAAgLgGgAgQgdQgHAIgBAQIAzgBQAAgOgGgJQgGgIgMgBQgMAAgHAJg");
	this.shape_18.setTransform(27.3,-10.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgQQAAgPAGgNQAGgLAKgHQALgGAOgBQAOAAAKAHQAKAFAFALQAFALAAAPIgBAFIgBAGIhFgBQABARAJAIQAIAIAPAAIARgDQAJgCAHgDIAAAPQgHAEgJACQgJABgLAAQgQAAgLgGgAgQgdQgHAIgBAQIAzgBQAAgOgGgJQgGgIgMgBQgMAAgHAJg");
	this.shape_19.setTransform(11.3,-10.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_20.setTransform(-0.2,-10.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgQQAAgPAGgNQAGgLAKgHQALgGAOgBQAOAAAKAHQAKAFAFALQAFALAAAPIgBAFIgBAGIhFgBQABARAJAIQAIAIAPAAIARgDQAJgCAHgDIAAAPQgHAEgJACQgJABgLAAQgQAAgLgGgAgQgdQgHAIgBAQIAzgBQAAgOgGgJQgGgIgMgBQgMAAgHAJg");
	this.shape_21.setTransform(-16.4,-10.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAWA1IAAgoIgMAFQgIADgIAAQgKABgIgEQgHgDgEgIQgFgHgBgNIAAgRIAAgLIgBgJIAUgCIABAJIAAALIAAARQABALAFAEQAEAGALAAQAGAAAHgDIAJgDIAAgyIAUAAIAABng");
	this.shape_22.setTransform(-27.7,-10.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgQQAAgPAGgNQAGgLAKgHQALgGAOgBQAOAAAKAHQAKAFAFALQAFALAAAPIgBAFIgBAGIhFgBQABARAJAIQAIAIAPAAIARgDQAJgCAHgDIAAAPQgHAEgJACQgJABgLAAQgQAAgLgGgAgQgdQgHAIgBAQIAzgBQAAgOgGgJQgGgIgMgBQgMAAgHAJg");
	this.shape_23.setTransform(-38.4,-10.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgyBGIAAiLIA3AAQATAAALAJQALAKAAARQAAAKgEAGQgDAHgGAEQgFAEgFABQAGABAHADQAGAEAEAHQAFAIAAALQAAAMgGAIQgFAIgJAEQgJAFgMAAgAgdA2IAjAAQALAAAGgHQAHgGAAgLQAAgGgDgGQgCgFgFgDQgGgDgIAAIgjAAgAgdgIIAhAAQALAAAFgGQAGgGAAgKQAAgLgHgGQgGgGgKAAIggAAg");
	this.shape_24.setTransform(-50.3,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59.4,-26,238.5,52);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgFgGQgDgHAAgKQgBgMAGgHQAFgHAKgDQAKgDALAAIAMABIAKABIAAgKQABgLgGgFQgEgFgMAAIgMABIgNADIgMADIAAgRQAKgDAKgBIAUgBQAMgBAJAEQAIADAFAIQAFAIgBAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgHAEQgJAFgLAAQgJAAgHgDgAgPAIQgHAEAAAKQAAAGACAEQAEAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgMAAgGAFg");
	this.shape.setTransform(-10.2,25.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_1.setTransform(-21.4,25.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgQQAAgPAGgNQAGgLAKgHQALgGAOgBQAOAAAKAHQAKAFAFALQAFALAAAPIgBAFIgBAGIhFgBQABARAJAIQAIAIAPAAIARgDQAJgCAHgDIAAAPQgHAEgJACQgJABgLAAQgQAAgLgGgAgQgdQgHAIgBAQIAzgBQAAgOgGgJQgGgIgMgBQgMAAgHAJg");
	this.shape_2.setTransform(-32.8,25.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAjBBIAAgYIgPABIgBgJIgBgIQgFAHgJAFQgHAFgMAAQgJABgIgEQgIgEgEgIQgFgJAAgOIAAgfIAAgUIgBgPIAUgCIABARIABASIAAAfQAAAMAFAHQAFAGAKAAQAFAAAEgCQAFgCADgDIAHgGIAAhMIAUAAIAABDIABALIAAALIAOAAIAAAmg");
	this.shape_3.setTransform(-43.9,26.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgFgGQgDgHAAgKQAAgMAFgHQAFgHAKgDQAJgDANAAIALABIAKABIAAgKQAAgLgEgFQgGgFgLAAIgMABIgNADIgMADIAAgRQAJgDALgBIATgBQANgBAJAEQAJADAEAIQAFAIgBAPIAAAsIABAMIACALIgUAAIgBgHIAAgIQgGAIgHAEQgJAFgKAAQgKAAgHgDgAgPAIQgHAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgMAAgGAFg");
	this.shape_4.setTransform(102.4,1.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_5.setTransform(91.2,1.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgXBFQgKgCgJgEIAAgRIARAHQAKADAKAAQAIAAAHgDQAIgDAEgGQAEgGAAgKIAAgNQgFAHgIAEQgIAEgJAAQgLAAgJgFQgKgFgGgLQgGgLAAgRQAAgSAGgMQAGgLAKgFQAKgFAMAAQALAAAHADQAHAEAEAEIAAgKIAUgBIgBAZIAABIQAAAQgHAKQgGAKgLAEQgMAEgNAAQgKAAgKgCgAgSguQgIAJAAARQAAARAIAJQAHAJANAAQAGAAAFgCIAIgFIAGgFIAAgzIgEgCIgIgEQgEgBgHAAQgPAAgHAJg");
	this.shape_6.setTransform(79.3,3.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZAwQgLgHgGgLQgGgNAAgRQAAgQAGgNQAGgLALgHQALgFAOAAQAPAAALAFQALAHAGALQAGANAAAQQAAARgGANQgGALgLAHQgLAFgPAAQgOAAgLgFgAgUgcQgHALAAARQAAASAHALQAIAJAMAAQANAAAIgJQAHgLAAgSQAAgRgHgLQgIgJgNAAQgMAAgIAJg");
	this.shape_7.setTransform(67.8,1.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSAyQgJgCgFgHQgGgFAAgLQAAgJAFgGQAEgGAHgDQAHgDAJgCIALgFQAGgCADgEQAEgDgBgGQABgHgGgDQgGgEgIAAQgHAAgFABIgMAEIgGACIgBgPQAEgCAGgBIAMgCIAMgBQALAAAJACQAIADAFAHQAFAFAAALQAAAKgGAHQgFAFgHADIgQAFQgKADgFAEQgGAEAAAIQAAAHAFADQAGAEAKAAQAGAAAHgCIANgEIAIgDIAAAQQgGACgKADQgKACgMAAQgKAAgJgDg");
	this.shape_8.setTransform(57.1,1.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQBGIgNgCIgMgFIAAgRQAHAEAKADQAJADAJAAQANAAAHgHQAIgHAAgNQAAgMgIgHQgIgHgMAAIgPAAIAAgMIAPAAQANgBAGgGQAHgGgBgKQAAgLgGgGQgHgGgLgBIgNACIgLADIgHACIAAgPQAGgDAKgBQAJgCAKAAQASAAALAJQALAJAAAQQAAAOgHAIQgHAIgKADQAHACAGADQAGAEAEAHQAEAHAAALQAAAOgHAIQgGAJgLAFQgKAEgMAAIgMgBg");
	this.shape_9.setTransform(47.2,3.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgEgJgBgOIAAghIAAgTIAAgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAFgEIAGgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgBgJIgBgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_10.setTransform(37.2,1.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgFgGQgDgHAAgKQAAgMAFgHQAFgHAKgDQAJgDANAAIALABIAKABIAAgKQAAgLgEgFQgGgFgLAAIgMABIgNADIgMADIAAgRQAJgDALgBIATgBQANgBAJAEQAJADAEAIQAFAIgBAPIAAAsIABAMIACALIgUAAIgBgHIAAgIQgGAIgHAEQgJAFgKAAQgKAAgHgDgAgPAIQgHAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgMAAgGAFg");
	this.shape_11.setTransform(20.9,1.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_12.setTransform(9.8,1.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_13.setTransform(-9.4,1.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgZBBQgIgEgFgIQgFgJABgOIAAghIAAgTIgBgOIAUgCIABAQIAAATIAAAfQAAAMAFAHQAFAGAKAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABFIAAARIABARIgTAAIgBgJIAAgJQgGAJgIAFQgJAFgKAAIgCABQgIAAgGgEgAgOg1IgLgDIAAgMIAMADIANABIANgBIALgDIABAMIgMADIgNABIgOgBg");
	this.shape_14.setTransform(-23.8,0.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgEgGQgEgHgBgKQAAgMAGgHQAGgHAJgDQAJgDAMAAIALABIAMABIAAgKQgBgLgFgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAJADAEAIQAEAIABAPIAAAsIAAAMIABALIgTAAIAAgHIgBgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgQAIQgGAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgMAAgIAFg");
	this.shape_15.setTransform(-35.3,1.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgOAwQgLgHgHgLQgHgNAAgRQAAgRAHgMQAHgLALgHQAMgFAOAAIAOABQAIAAAGADIgBARIgKgEQgHgCgGAAQgQAAgJAKQgJAKAAARQAAARAJALQAJAKAQAAQAHAAAGgCIALgEIAAARIgOADIgOABQgOAAgMgFg");
	this.shape_16.setTransform(-45.4,1.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_17.setTransform(102.8,-22.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgEgGQgFgHAAgKQABgMAFgHQAGgHAJgDQAKgDAMAAIAKABIALABIAAgKQAAgLgEgFQgGgFgLAAIgMABIgOADIgLADIAAgRQAKgDAKgBIATgBQANgBAJAEQAIADAFAIQAFAIAAAPIAAAsIAAAMIACALIgUAAIAAgHIgBgIQgGAIgIAEQgIAFgKAAQgKAAgHgDgAgQAIQgGAEAAAKQAAAGADAEQADAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgLAAgIAFg");
	this.shape_18.setTransform(88.6,-22.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAnA0IgBgPIAAgQIAAgMIAAgSIABgTIgBAAIgfBHIgOAAIgghHIgBAAIAAATIAAARIAAAsIgTAAIAAhnIAcAAIAfBGIAghGIAaAAIAABIIAAARIACAOg");
	this.shape_19.setTransform(76,-22.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgEgJgBgOIAAghIAAgTIgBgOIAVgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAFgEIAHgHIAAhJIAUAAIAABDIAAASIABASIgSAAIgBgJIgBgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEg");
	this.shape_20.setTransform(62.6,-22.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgEgJAAgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgCgJIAAgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_21.setTransform(46.1,-22.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgNAvQgMgFgHgNQgHgLAAgSQAAgRAHgMQAHgMAMgFQALgHAPABIANAAQAIACAGACIAAAQIgLgDQgGgCgIAAQgPAAgKAKQgIAKgBARQABASAJAKQAIAKAQAAQAIAAAHgCIAKgEIAAAQIgOAFIgNABQgOAAgMgHg");
	this.shape_22.setTransform(35.5,-22.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgPQAAgQAGgMQAGgMAKgHQALgGAOAAQAOgBAKAHQAKAFAFALQAFALAAAOIgBAGIgBAGIhFgBQABAQAJAJQAIAIAPAAIARgCQAJgDAHgEIAAAQQgHAEgJACQgJACgLAAQgQgBgLgGgAgQgeQgHAJgBAQIAzgBQAAgOgGgJQgGgJgMAAQgMAAgHAIg");
	this.shape_23.setTransform(20.1,-22.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_24.setTransform(6,-22.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgEgJAAgOIAAghIAAgTIgBgOIAUgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIACASIgTAAIgCgJIAAgJQgGAJgIAFQgJAFgJAAIgDABQgIAAgGgEg");
	this.shape_25.setTransform(-13.3,-22.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgZAvQgLgFgGgNQgGgLAAgSQAAgRAGgLQAGgMALgGQALgHAOABQAPgBALAHQALAGAGAMQAGALAAARQAAASgGALQgGANgLAFQgLAHgPAAQgOAAgLgHgAgUgbQgHAJAAASQAAATAHAJQAIAKAMAAQANAAAIgKQAHgJAAgTQAAgSgHgJQgIgKgNAAQgMAAgIAKg");
	this.shape_26.setTransform(-29.7,-22.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAgBGIAAg8IhAAAIAAA8IgUAAIAAiLIAUAAIAAA+IBAAAIAAg+IAWAAIAACLg");
	this.shape_27.setTransform(-43,-24);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.3,-38,205.6,76);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAJQgEgDAAgGQAAgFAEgDQADgDAFAAQAGAAADADQADADABAFQgBAGgDADQgDADgGAAQgFAAgDgDg");
	this.shape.setTransform(109.9,-33.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgFgJABgOIAAghIAAgTIgCgOIAVgCIABAQIAAATIAAAfQAAAMAFAHQAFAGAKAAQAEAAAFgDQAFgCADgEIAIgHIAAhJIAUAAIAABDIAAASIABASIgTAAIgBgJIAAgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEg");
	this.shape_1.setTransform(100.7,-37.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_2.setTransform(86.4,-37.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgWAvQgMgGgFgMQgGgMAAgQQAAgRAGgMQAGgMAKgGQALgHAOABQAOAAAKAFQAKAHAFAKQAFALAAAPIgBAGIgBAEIhFAAQABARAJAIQAIAIAPAAIARgCQAJgDAHgDIAAAQQgHADgJABQgJACgLAAQgQABgLgHgAgQgeQgHAJgBAQIAzAAQAAgPgGgJQgGgIgMgBQgMAAgHAIg");
	this.shape_3.setTransform(72.2,-37.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgEgGQgEgHgBgKQAAgMAGgHQAGgHAJgDQAJgDAMAAIALABIAMABIAAgKQgBgLgFgFQgEgFgMAAIgMABIgOADIgLADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAJADAEAIQAEAIABAPIAAAsIAAAMIABALIgTAAIAAgHIgBgIQgGAIgIAEQgHAFgMAAQgJAAgIgDgAgQAIQgGAEAAAKQAAAGADAEQACAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgMAAgIAFg");
	this.shape_4.setTransform(61,-37.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgQBGIgNgCIgMgFIAAgRQAHAEAKADQAJADAJAAQANAAAHgHQAIgHAAgNQAAgMgIgHQgIgHgMAAIgPAAIAAgMIAPAAQANgBAGgGQAHgGgBgKQAAgLgGgGQgHgGgLgBIgNACIgLADIgHACIAAgPQAGgDAKgBQAJgCAKAAQASAAALAJQALAJAAAQQAAAOgHAIQgHAIgKADQAHACAGADQAGAEAEAHQAEAHAAALQAAAOgHAIQgGAJgLAFQgKAEgMAAIgMgBg");
	this.shape_5.setTransform(50.6,-36);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgEgGQgFgHAAgKQABgMAFgHQAGgHAJgDQAKgDAMAAIAKABIALABIAAgKQAAgLgEgFQgGgFgLAAIgMABIgOADIgLADIAAgRQAKgDAKgBIATgBQANgBAJAEQAIADAFAIQAFAIAAAPIAAAsIAAAMIACALIgUAAIAAgHIgBgIQgGAIgIAEQgIAFgKAAQgKAAgHgDgAgQAIQgGAEAAAKQAAAGADAEQADAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgLAAgIAFg");
	this.shape_6.setTransform(36,-37.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOAwQgMgHgGgLQgHgNAAgRQAAgRAHgMQAGgLAMgHQAMgFAOAAIAPABQAHAAAGADIgBARIgKgEQgGgCgIAAQgQAAgIAKQgJAKAAARQAAARAJALQAJAKAPAAQAIAAAGgCIALgEIAAARIgNADIgPABQgNAAgNgFg");
	this.shape_7.setTransform(25.9,-37.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgZAwQgLgHgGgLQgGgNAAgRQAAgQAGgNQAGgLALgHQALgFAOAAQAPAAALAFQALAHAGALQAGANAAAQQAAARgGANQgGALgLAHQgLAFgPAAQgOAAgLgFgAgUgcQgHALAAARQAAASAHALQAIAJAMAAQANAAAIgJQAHgLAAgSQAAgRgHgLQgIgJgNAAQgMAAgIAJg");
	this.shape_8.setTransform(10.3,-37.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgSAyQgJgCgGgHQgEgFgBgLQABgJADgGQAFgGAHgDQAHgDAIgCIAMgFQAFgCAEgEQADgDABgGQgBgHgFgDQgGgEgIAAQgGAAgHABIgLAEIgHACIAAgPQAEgCAGgBIAMgCIAMgBQALAAAIACQAJADAFAHQAFAFAAALQAAAKgFAHQgGAFgIADIgQAFQgIADgGAEQgGAEAAAIQAAAHAGADQAFAEAJAAQAHAAAIgCIAMgEIAHgDIABAQQgGACgKADQgKACgMAAQgKAAgJgDg");
	this.shape_9.setTransform(-0.5,-37.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgZAwQgLgHgGgLQgGgNAAgRQAAgQAGgNQAGgLALgHQALgFAOAAQAPAAALAFQALAHAGALQAGANAAAQQAAARgGANQgGALgLAHQgLAFgPAAQgOAAgLgFgAgUgcQgHALAAARQAAASAHALQAIAJAMAAQANAAAIgJQAHgLAAgSQAAgRgHgLQgIgJgNAAQgMAAgIAJg");
	this.shape_10.setTransform(-11,-37.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_11.setTransform(-22.7,-37.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAyBGIAAhKIABgoIgpBkIgTAAIgqhkIAAAAIABAoIAABKIgUAAIAAiLIAeAAIApBjIAphjIAeAAIAACLg");
	this.shape_12.setTransform(-37.7,-39.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.8,-53.6,164.2,28);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAtQgDgDgBgGQABgGADgDQADgDAFgBQAFABAEADQADADABAGQgBAGgDADQgEADgFAAQgFAAgDgDgAgIgaQgDgDgBgGQABgGADgDQADgDAFAAQAFAAAEADQADADABAGQgBAGgDADQgEADgFAAQgFAAgDgDg");
	this.shape.setTransform(115.6,-9.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgWAvQgMgHgFgMQgGgMAAgQQAAgPAGgNQAGgLAKgHQALgGAOgBQAOAAAKAHQAKAFAFALQAFALAAAPIgBAFIgBAGIhFgBQABARAJAIQAIAIAPAAIARgDQAJgCAHgDIAAAPQgHAEgJACQgJABgLAAQgQAAgLgGgAgQgdQgHAIgBAQIAzgBQAAgOgGgJQgGgIgMgBQgMAAgHAJg");
	this.shape_1.setTransform(106.8,-10.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA0A1IgBgPIAAgRIAAggQAAgNgFgGQgFgGgJAAQgGAAgFACQgFADgGAHIABAGIAAAGIAABBIgTAAIAAhCQAAgLgEgGQgEgGgJAAQgHAAgGAEQgGAEgEAGIAABLIgUAAIAAhHIgBgQIgCgQIATgCIABAKIABAJQADgFAEgEQAFgEAGgDQAGgDAHAAQAKAAAHAFQAFAEAEAJIAIgJQAEgEAGgCQAGgDAIAAQAJAAAHAEQAHAEAEAJQAFAIAAAOIAAAiIAAASIABAOg");
	this.shape_2.setTransform(92.7,-10.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZAyQgIgEgFgIQgFgJABgOIAAghIAAgTIgBgOIAUgCIABAQIAAATIAAAfQAAAMAFAHQAFAGAKAAQAEAAAFgDQAEgCAEgEIAHgHIAAhJIAVAAIAABDIAAASIABASIgTAAIgBgJIAAgJQgGAJgIAFQgJAFgKAAIgCABQgIAAgGgEg");
	this.shape_3.setTransform(78.3,-10.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgtgqIgBgNIgCgOIAUgCIACAQQAFgIAIgDQAJgFAJAAQAPAAAKAIQAJAHAFAMQAEAMAAAPQAAAPgEALQgFANgKAGQgJAIgRgBQgKAAgHgCQgHgDgDgEIAAAsIgVABgAgOg0QgGAEgFADIABA6IAEADIAHADIALABQAPAAAIgKQAHgJAAgSQAAgSgHgKQgIgKgNAAQgIAAgGADg");
	this.shape_4.setTransform(66.7,-8.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaAzQgIgEgEgGQgFgHAAgKQABgMAFgHQAGgHAJgDQAKgDAMAAIAKABIALABIAAgKQAAgLgEgFQgGgFgLAAIgMABIgNADIgMADIAAgRQAKgDAKgBIATgBQANgBAJAEQAIADAFAIQAFAIAAAPIAAAsIAAAMIACALIgUAAIAAgHIgBgIQgGAIgIAEQgIAFgKAAQgKAAgHgDgAgQAIQgGAEAAAKQAAAGADAEQADAEAEACQAEACAFAAQAHAAAGgEQAGgDAFgHIAAgVIgJgBIgJgBQgLAAgIAFg");
	this.shape_5.setTransform(54.9,-10.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAWBKIgZgsIgRAAIAAAsIgUAAIAAh0IAAgQIgCgOIAVgBIABAOIAAARIAAA4IARAAIAYgqIAVAAIgeAyIAfA0g");
	this.shape_6.setTransform(44.9,-12.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgaAyQgHgEgFgIQgEgJgBgOIAAghIAAgTIgBgOIAVgCIAAAQIABATIAAAfQAAAMAFAHQAGAGAJAAQAEAAAFgDQAEgCAFgEIAHgHIAAhJIAUAAIAABDIAAASIABASIgSAAIgBgJIgBgJQgGAJgJAFQgIAFgKAAIgCABQgIAAgHgEg");
	this.shape_7.setTransform(33.4,-10.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAYA1IgBgRIAAgVIAAgHIgtAAIAAAtIgUAAIAAhHIAAgSIgCgOIAVgCIABARIAAAVIAAAIIAtAAIAAgsIAUAAIAABDIAAAUIACAQg");
	this.shape_8.setTransform(21.7,-10.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgtgqIAAgNIgCgOIATgCIABAQQAGgIAJgDQAIgFAKAAQAOAAAJAIQAKAHAFAMQAFAMAAAPQAAAPgFALQgFANgKAGQgKAIgPgBQgLAAgHgCQgHgDgEgEIAAAsIgUABgAgOg0QgGAEgFADIAAA6IAFADIAIADIALABQAOAAAHgKQAIgJAAgSQAAgSgIgKQgGgKgOAAQgIAAgGADg");
	this.shape_9.setTransform(10.1,-8.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgbAzQgHgEgFgGQgDgHAAgKQgBgMAGgHQAGgHAJgDQAJgDAMAAIAMABIALABIAAgKQAAgLgGgFQgEgFgMAAIgMABIgNADIgMADIAAgRQAJgDALgBIAUgBQAMgBAJAEQAIADAFAIQAEAIAAAPIAAAsIABAMIABALIgTAAIgBgHIAAgIQgGAIgHAEQgJAFgLAAQgJAAgIgDgAgPAIQgHAEAAAKQAAAGACAEQADAEAFACQAEACAFAAQAHAAAGgEQAGgDAGgHIAAgVIgJgBIgJgBQgNAAgGAFg");
	this.shape_10.setTransform(-1.8,-10.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AA0BKIgWgtIgUAAIAAAtIgTAAIAAgtIgUAAIgVAtIgXAAIAdg1IgcgyIAWAAIAWArIATAAIAAg7IgBgPIgBgMIATgBIACAPIAAASIAAA2IATAAIAXgrIAVAAIgbAyIAcA1g");
	this.shape_11.setTransform(-14.8,-12.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgZAvQgLgGgGgMQgGgLAAgSQAAgRAGgLQAGgNALgFQALgHAOAAQAPAAALAHQALAFAGANQAGALAAARQAAASgGALQgGAMgLAGQgLAHgPgBQgOABgLgHgAgUgcQgHAKAAASQAAATAHAJQAIAKAMAAQANAAAIgKQAHgJAAgTQAAgSgHgKQgIgJgNAAQgMAAgIAJg");
	this.shape_12.setTransform(-28.4,-10.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAgBGIAAh7Ig/AAIAAB7IgVAAIAAiLIBpAAIAACLg");
	this.shape_13.setTransform(-41.5,-12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.8,-26,171.8,28);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AIZAiQgMgLAAgWQAAgVAMgLQAMgMAVAAQAOAAAMAEIAAASQgNgFgKAAQgZAAgBAbQABAaAVAAIALgCIAAgQIgQAAIAAgNIAiAAIAAAqQgOAGgQAAQgTAAgMgKgAE8AiQgNgLAAgWQABgVALgLQANgMAUAAQAOAAAMAEIAAASQgMgFgLAAQgZAAAAAbQAAAaAVAAIALgCIAAgQIgQAAIAAgNIAhAAIAAAqQgOAGgPAAQgTAAgLgKgAhMAgQgKgMAAgUQAAgTAKgMQAKgMAUAAQAUAAAJAMQALAMAAATQAAAUgLAMQgJAMgUAAQgUAAgKgMgAhAAAQAAAbASAAQARAAAAgbQAAgagRAAQgSAAAAAagAn7AjQgIgIgBgPIgBg1IAWgBIAAA2QAAAPAOAAQANAAAAgPIAAg1IAVAAIAAA1QgBAPgIAIQgKAJgPAAQgRAAgJgJgAGNAfQAAgLAMAAQAMAAAAALQAAAMgMAAQgMAAAAgMgAAJAlIAAgTQAPAIAOAAQAMAAAAgHQAAgEgEgCIgMgEQgLgDgHgFQgHgGAAgLQAAgbAfAAQAQAAANAGIAAASQgPgHgMAAQgLAAAAAHQAAAFAEACIALAEQANAEAGAEQAGAGAAALQABAaghAAQgRAAgNgGgApVAlIAAgTQAQAIAOAAQAMAAAAgHQgBgEgEgCIgKgEQgNgDgFgFQgJgGAAgLQAAgbAfAAQASAAAMAGIAAASQgOgHgNAAQgMAAAAAHQAAAFAFACIALAEQAMAEAGAEQAHAGAAALQAAAaghAAQgQAAgOgGgAG8AqIgBhTIAmAAQAbAAAAAWQAAANgOAGQAQACAAARQAAALgHAGQgHAGgMAAgAHQAaIAQAAQAKAAAAgKQAAgJgJAAIgRAAgAHQgHIAPAAQAIAAABgJQgBgJgIAAIgPAAgAEHAqIgegxIAAAxIgUAAIgBhTIAWAAIAeAwIAAgwIAUAAIAABTgACoAqIgBhTIAWgBIAABUgABqAqIAAhDIgWAAIAAgQIBDAAIAAAQIgXAAIAABDgAh/AqIAAggIgcAAIAAAgIgVAAIgBhTIAWgBIAAAjIAcAAIAAgiIAWAAIAABTgAjbAqIgKgeIgNAAIAAAeIgVAAIgBhTIAoAAQAOAAAIAIQAHAHAAAMQAAARgPAHIANAggAjygDIAOAAQALAAAAgLQAAgLgLAAIgOAAgAlVAqIgBhTIA7AAIAAARIgkAAIAAASIAfAAIgBAPIgeAAIAAAQIAlAAIAAARgAmpAqIgBhTIAnAAQAOAAAHAIQAIAIgBANQABAMgIAHQgIAIgOAAIgQAAIAAAbgAmUAAIALAAQANAAAAgMQAAgNgNAAIgLAAg");
	this.shape.setTransform(59.8,4.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,119.5,8.8);


(lib.txts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// txt3
	this.instance = new lib.Tween4("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(19.9,-263.4);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(158).to({_off:false},0).to({x:14.9,alpha:1},8).to({startPosition:0},71).to({x:9.9,alpha:0},8).wait(1));

	// txt2
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(12.9,-250.9);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(74).to({_off:false},0).to({x:7.9,alpha:1},8).to({startPosition:0},72).to({x:2.9,alpha:0},8).to({_off:true},1).wait(83));

	// txt1b
	this.instance_2 = new lib.Tween2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(12.4,-212.4);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({_off:false},0).to({x:7.4,alpha:1},8).to({startPosition:0},50).to({x:-112.6,alpha:0},8).to({_off:true},1).wait(167));

	// txt1
	this.instance_3 = new lib.Tween1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(14.4,-263);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:9.4,alpha:1},8).to({startPosition:0},62).to({x:-110.6,alpha:0},8).to({_off:true},1).wait(167));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.5,-289,171.8,28);


(lib.Call = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_10 = new cjs.Graphics().p("AFlGGIyAAAIAAsNISZAAIAVgBQCjAABzB0QBzByAACiQAACihzB0QhzByijAAQgXAAgXgCg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_graphics_10,x:120.2,y:-214.4}).wait(10).to({graphics:null,x:0,y:0}).wait(60));

	// Layer 4
	this.instance = new lib.Tween6("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(242,-214.4);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).to({x:137},7).to({x:142},3).to({startPosition:0},51).to({x:162,alpha:0},8).wait(1));

	// Layer 5
	this.instance_1 = new lib.Tween5("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(160.5,-214.4,0.051,0.051);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.11,scaleY:1.11},6).to({scaleX:1,scaleY:1},4).to({startPosition:0},27).to({startPosition:0},34).to({scaleX:0.11,scaleY:0.11},8).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(158.5,-216.4,4,4);


(lib.смоке = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween8("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-64.7,231.2,0.074,0.074);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,scaleX:1.64,scaleY:1.64,x:-187.5,y:89.2,alpha:0},94).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.4,226.5,9.5,9.5);


// stage content:
(lib.Fireman_300x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_184 = function() {
		if(!this.alreadyExecuted){
		
		this.alreadyExecuted=true;
		
		this.loopNum=1;
		
		} else {
		
		this.loopNum++;
		
		if(this.loopNum==3){
		
		this.stop();
		
		}
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(184).call(this.frame_184).wait(62));

	// Logo
	this.instance = new lib.Symbol1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(212.7,232.7,1.184,1.184,0,0,0,60.3,4.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(246));

	// TXTS
	this.instance_1 = new lib.txts("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(17.7,62.3,0.996,0.996,0,0,0,-40.9,-237.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(246));

	// BUTT
	this.instance_2 = new lib.Call("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(249.8,172.6,1.069,1.069,0,0,0,162.9,-214.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(166).to({_off:false},0).wait(80));

	// shadow
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],0,-64.5,0,64.5).s().p("A36JnIAAzNMAv1AAAIAATNg");
	this.shape.setTransform(152.1,208);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(246));

	// People
	this.instance_3 = new lib.Tween7("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(135,351);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:0.99,scaleY:0.99,x:130.6,y:348.1},39).to({scaleX:0.97,scaleY:0.97,x:120.8,y:341.6},85).to({scaleX:1,scaleY:1,x:135,y:351},60).to({startPosition:0},61).wait(1));

	// smoke
	this.instance_4 = new lib.смоке("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(414,202.5,1,1,0,0,0,-64.7,231.2);

	this.instance_5 = new lib.смоке("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(389,208,1,1,0,0,0,-64.7,231.2);

	this.instance_6 = new lib.смоке("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(345.1,222.3,1,1,0,0,0,-64.7,231.2);

	this.instance_7 = new lib.смоке("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(452.1,218.5,1,1,0,0,0,-64.7,231.2);

	this.instance_8 = new lib.смоке("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(330.5,205.5,1,1,0,0,0,-64.7,231.2);

	this.instance_9 = new lib.смоке("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(305.5,225.5,1,1,0,0,0,-64.7,231.2);

	this.instance_10 = new lib.смоке("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(305.5,200.5,1,1,0,0,0,-64.7,231.2);

	this.instance_11 = new lib.смоке("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(237.1,208,1,1,0,0,0,-64.7,231.2);

	this.instance_12 = new lib.смоке("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(414,232.5,1,1,0,0,0,-64.7,231.2);

	this.instance_13 = new lib.смоке("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(389,238,1,1,0,0,0,-64.7,231.2);

	this.instance_14 = new lib.смоке("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(370.1,232.5,1,1,0,0,0,-64.7,231.2);

	this.instance_15 = new lib.смоке("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(452.1,248.5,1,1,0,0,0,-64.7,231.2);

	this.instance_16 = new lib.смоке("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(355.5,215.7,1,1,0,0,0,-64.7,231.2);

	this.instance_17 = new lib.смоке("synched",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(330.5,235.7,1,1,0,0,0,-64.7,231.2);

	this.instance_18 = new lib.смоке("synched",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(330.5,210.7,1,1,0,0,0,-64.7,231.2);

	this.instance_19 = new lib.смоке("synched",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(393.6,246.3,1,1,0,0,0,-64.7,231.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},53).to({state:[]},191).wait(2));

	// smoke
	this.instance_20 = new lib.смоке("synched",0);
	this.instance_20.parent = this;
	this.instance_20.setTransform(414,202.5,1,1,0,0,0,-64.7,231.2);

	this.instance_21 = new lib.смоке("synched",0);
	this.instance_21.parent = this;
	this.instance_21.setTransform(389,208,1,1,0,0,0,-64.7,231.2);

	this.instance_22 = new lib.смоке("synched",0);
	this.instance_22.parent = this;
	this.instance_22.setTransform(345.1,222.3,1,1,0,0,0,-64.7,231.2);

	this.instance_23 = new lib.смоке("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(452.1,218.5,1,1,0,0,0,-64.7,231.2);

	this.instance_24 = new lib.смоке("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(330.5,205.5,1,1,0,0,0,-64.7,231.2);

	this.instance_25 = new lib.смоке("synched",0);
	this.instance_25.parent = this;
	this.instance_25.setTransform(305.5,225.5,1,1,0,0,0,-64.7,231.2);

	this.instance_26 = new lib.смоке("synched",0);
	this.instance_26.parent = this;
	this.instance_26.setTransform(305.5,200.5,1,1,0,0,0,-64.7,231.2);

	this.instance_27 = new lib.смоке("synched",0);
	this.instance_27.parent = this;
	this.instance_27.setTransform(237.1,208,1,1,0,0,0,-64.7,231.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20}]},28).to({state:[]},190).wait(28));

	// smoke
	this.instance_28 = new lib.смоке("synched",0);
	this.instance_28.parent = this;
	this.instance_28.setTransform(304,162.5,1,1,0,0,0,-64.7,231.2);

	this.instance_29 = new lib.смоке("synched",0);
	this.instance_29.parent = this;
	this.instance_29.setTransform(279,168,1,1,0,0,0,-64.7,231.2);

	this.instance_30 = new lib.смоке("synched",0);
	this.instance_30.parent = this;
	this.instance_30.setTransform(260.1,162.5,1,1,0,0,0,-64.7,231.2);

	this.instance_31 = new lib.смоке("synched",0);
	this.instance_31.parent = this;
	this.instance_31.setTransform(342.1,178.5,1,1,0,0,0,-64.7,231.2);

	this.instance_32 = new lib.смоке("synched",0);
	this.instance_32.parent = this;
	this.instance_32.setTransform(245.5,145.7,1,1,0,0,0,-64.7,231.2);

	this.instance_33 = new lib.смоке("synched",0);
	this.instance_33.parent = this;
	this.instance_33.setTransform(220.5,165.7,1,1,0,0,0,-64.7,231.2);

	this.instance_34 = new lib.смоке("synched",0);
	this.instance_34.parent = this;
	this.instance_34.setTransform(220.5,140.7,1,1,0,0,0,-64.7,231.2);

	this.instance_35 = new lib.смоке("synched",0);
	this.instance_35.parent = this;
	this.instance_35.setTransform(283.6,176.3,1,1,0,0,0,-64.7,231.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28}]}).to({state:[]},190).wait(56));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FF3333","#660000"],[0,0.894],-301.7,-47.2,170,-14.1).s().p("A36T9MAAAgn5MAv1AAAMAAAAn5g");
	this.shape_1.setTransform(152.1,126.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(246));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(149,124,452.6,417.9);
// library properties:
lib.properties = {
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Fireman.png?1574234764418", id:"Fireman"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;