coremetrics.cmUpdateConfig({"at":false,"io":false,"ia":false,"ddx":{"version":3, "w3cEnabled":true}}); coremetrics.cmLoad();
