 /*!
 * Name: ibm.com v19a production file
 * Release: 1.1.0
 * Built: 2019-10-29 13:31:02
 * Owner: Michael Santelia, Vlad Saling
 * Copyright (c) 2019 IBM Corporation
 * Description: Official file for production use
 */
 IBMCore.v19aVersion = '1.1.0';
 !function(e,t){function i(){e.common.util.statshelper.fireEvent({ibmEV:"page load",ibmEvAction:"v19a page tracker",ibmEvFileSize:window.innerWidth||document.documentElement.clientWidth||document.body.clientWidth,ibmEvModule:e.common.util.config.get("masthead.type")})}jQuery(function(){setTimeout(i,2e3)})}(IBMCore);