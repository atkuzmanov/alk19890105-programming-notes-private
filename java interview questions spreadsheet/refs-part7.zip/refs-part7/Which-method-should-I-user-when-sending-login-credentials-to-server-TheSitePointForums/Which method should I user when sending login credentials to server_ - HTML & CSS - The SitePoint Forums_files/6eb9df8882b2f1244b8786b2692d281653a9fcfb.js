 
          propertag && propertag.cmd.push(function() { proper_display('sitepoint_main_1'); });
        
