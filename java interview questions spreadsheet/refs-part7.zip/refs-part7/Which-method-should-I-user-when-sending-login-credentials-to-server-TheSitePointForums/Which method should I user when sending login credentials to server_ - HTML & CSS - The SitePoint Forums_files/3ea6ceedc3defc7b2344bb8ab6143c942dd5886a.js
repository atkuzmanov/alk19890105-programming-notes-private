
    window.propertag = window.propertag || {};
    propertag.cmd = propertag.cmd || [];
    (function() {
        var pm = document.createElement('script');
        pm.async = true; pm.type = 'text/javascript';
        var is_ssl = 'https:' == document.location.protocol;
        pm.src = (is_ssl ? 'https:' : 'http:') + '//global.proper.io/sitepoint.min.js';
        var node = document.getElementsByTagName('script')[0];
        node.parentNode.insertBefore(pm, node);
    })();

